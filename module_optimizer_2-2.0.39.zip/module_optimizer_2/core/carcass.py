"""
Carcass conventions - every result lands in '<module>_car_01'
(Counter Tops go straight under the module root).

    Top Panel            auto-detected (built if missing), 4 modes
    Sides Panel          auto-detected LP/RP, sd-pnl numbering
    Carcass Internals    selection, With / Without OSL/BSL
    Bottom Panel         selection, With / Without OSL/BSL
    Back Panel           selection, With / Without OSL/BSL
    Visible Side Panels  L/R auto-detected, or Top / Bottom from
                         a selection, all inside car_vs_01

Selection-driven tools accept a Part group, or raw geometry
(separate faces, a joined panel or a welded box).
"""

import re

import bpy

from ..config import (
    OSL,
    BSL,
    CARCASS_INTERNAL,
    VISIBLE_SIDE_GROUP,
    VISIBLE_TOP,
    VISIBLE_BOTTOM,
    VISIBLE_SIDE_LEFT,
    VISIBLE_SIDE_RIGHT,
    SIDE_PANEL_GROUP,
    SIDE_PANEL,
    REMOVABLE_SHELF,
    FIXED_SHELF,
    TOP_PANEL_FACE,
    BOTTOM_PANEL_FACE,
    BACK_PANEL_FACE,
    TOP_PANEL_HEIGHT_MM,
    TOP_PANEL_MIN_WIDTH_RATIO,
    COUNTERTOP_GROUP,
    COUNTERTOP_FRONT,
    COUNTERTOP_EDGEBAND,
    COUNTERTOP_COMBINED,
)

from .common import (
    MOError,
    require_root,
    ensure_module_name,
    make_name,
    next_index,
    join_objects,
    parent_to,
    get_or_create_group,
    carcass_group,
    remove_if_empty,
    remove_empty_shutter_groups,
    refresh,
    selected_parts,
    selected_meshes,
    selected_meshes_expanded,
    structural_meshes,
    module_center,
    bounds_of,
    mm_to_native,
)

from .cleanup import raw_parts
from .shutter import spatial_order, build_combined_shutter

from .geometry import (
    part_faces,
    all_part_faces,
    resolve_panel,
    reclassify,
    split_objects,
    classify_pieces,
    pick_front_back,
    face_center,
    make_box_faces,
)


# =========================================================
# Shared Plumbing
# =========================================================

def _start(context, props):

    root = require_root(context)
    ensure_module_name(props, root)

    return root


def _finish(context, props, root, sources=()):
    """Drop emptied source / Part / Shutter groups, clear selection, redraw."""

    for source in sources:
        remove_if_empty(source)

    for part in raw_parts(root):
        if part.type == 'EMPTY':
            remove_if_empty(part)

    remove_empty_shutter_groups(props)

    # car_vs_01 / car_sd_01 left empty after switching a panel's option.
    _remove_empty_side_groups(props.module_name)

    bpy.ops.object.select_all(action='DESELECT')

    refresh(context)


def _safe_remove(obj):

    try:
        name = obj.name
    except ReferenceError:
        return

    if name in bpy.data.objects:
        bpy.data.objects.remove(obj, do_unlink=True)


def _clear_names(objects):
    """Park names so renumbering doesn't count the objects' old names."""

    for obj in objects:
        if obj is not None:
            obj.name = "mo2_renaming"


def _rename_fixed(module, front, back, edgeband, suffix):
    """Front -> <suffix>_OSL_01, Back -> _BSL_01, EdgeBand -> _OSL_02."""

    _clear_names([front, back, edgeband])

    if front is not None:
        front.name = make_name(module, f"{suffix}_{OSL}", 1)

    if back is not None:
        back.name = make_name(module, f"{suffix}_{BSL}", 1)

    if edgeband is not None:
        edgeband.name = make_name(module, f"{suffix}_{OSL}", 2)


def _rename_continuing(module, front, back, edgeband, suffix):
    """Same roles as _rename_fixed() but numbers continue module-wide."""

    osl = f"{suffix}_{OSL}"
    bsl = f"{suffix}_{BSL}"

    for obj, role in ((front, osl), (back, bsl), (edgeband, osl)):

        if obj is not None:
            obj.name = make_name(module, role, next_index(module, role))


def _panel_from_selection(context, root):
    """
    (front, back, edgeband, source_part): from the first selected
    Part group, else from the selected raw geometry.
    """

    parts = selected_parts(context)

    if parts:

        front, back, edgeband = part_faces(parts[0])

        if front is None and back is None:
            raise MOError(f"No Front/Back faces found on '{parts[0].name}'.")

        return front, back, edgeband, parts[0]

    meshes = selected_meshes(context)

    if not meshes:
        raise MOError("Select a Part group, or its faces, first.")

    front, back, edgeband = resolve_panel(context, meshes, root)

    return front, back, edgeband, None


# =========================================================
# Carcass Internals
# =========================================================

HORIZONTAL_RIPPER = re.compile(
    r"horizontal[\s_\-]*ripper[\s_\-]*(front|rear|raer)\D*(\d*)", re.I
)


def _ripper_pairs(root):
    """
    Horizontal Ripper Front N + Rear N pairs (a ripper with no
    partner of the same number stays alone), ordered left to
    right, top to bottom.
    """

    pairs = {}

    for obj in root.children_recursive:

        if obj.type != 'MESH':
            continue

        match = HORIZONTAL_RIPPER.search(obj.name)

        if match:
            number = int(match.group(2)) if match.group(2) else 0
            pairs.setdefault(number, []).append(obj)

    groups = list(pairs.values())

    first = {group[0]: group for group in groups}

    return [first[obj] for obj in spatial_order(list(first))]


VERTICAL_PANEL = re.compile(r"vertical[\s_\-]*panel[\s_\-]*(left|right)", re.I)


def _vertical_panels(root):
    """Vertical Panel Left / Right meshes, each on its own, left first."""

    panels = [
        obj for obj in root.children_recursive
        if obj.type == 'MESH' and VERTICAL_PANEL.search(obj.name)
    ]

    order = {"left": 0, "right": 1}

    panels.sort(key=lambda obj: (order[VERTICAL_PANEL.search(obj.name).group(1).lower()], obj.name))

    return [[obj] for obj in panels]


# Bed storage internals - every match joined into one car-in.
BED_STORAGE_PARTS = re.compile(
    r"bottom[\s_\-]*storage[\s_\-]*panel"
    r"|cent(?:er|re)[\s_\-]*vertical"
    r"|horizontal[\s_\-]*rippers?[\s_\-]*(?:left|right)"
    r"|side[\s_\-]*support"
    r"|top[\s_\-]*mat+r[ea]ss?[\s_\-]*panel",
    re.I,
)


def _bed_storage(root):
    """[[all bed storage parts]] (one car-in), or [] when there are none."""

    parts = [
        obj for obj in root.children_recursive
        if obj.type == 'MESH' and BED_STORAGE_PARTS.search(obj.name)
    ]

    return [spatial_order(parts)] if parts else []


def apply_ripper_pairs(context, props, root):
    """
    Nothing selected, Without OSL/BSL: each Horizontal Ripper Front/Rear
    pair joined into one '<module>_car-in_NN' (left to right), then
    Vertical Panel Left and Right, each its own car-in, then the bed
    storage parts (Bottom Storage Panels, Center Vertical, Horizontal
    Rippers Left / Right, Side Supports, Top Matress Panels) all joined
    into one car-in.
    """

    pairs = _ripper_pairs(root) + _vertical_panels(root) + _bed_storage(root)

    if not pairs:
        raise MOError(
            "No Horizontal Ripper, Vertical Panel or bed storage part found - "
            "select one or more Part groups, or their faces, first."
        )

    module = props.module_name
    group = carcass_group(context, props, root)

    named = []

    for meshes in pairs:

        sources = " + ".join(obj.name for obj in meshes) if len(meshes) <= 2 else f"{len(meshes)} bed storage parts"

        combined = join_objects(context, meshes)
        _clear_names([combined])
        combined.name = make_name(module, CARCASS_INTERNAL, next_index(module, CARCASS_INTERNAL))

        parent_to(group, [combined])

        named.append(f"{sources} -> {combined.name}")

    _finish(context, props, root)

    return f"{len(named)} Carcass Internal(s): " + ", ".join(named) + "."


def apply_carcass_internals(context, props, with_osl):
    """
    With OSL/BSL: one panel, car-in_OSL / car-in_BSL numbering.
    Without: every selected panel joined into one car-in_NN; with
    nothing selected, Horizontal Ripper Front/Rear pairs instead.
    """

    root = _start(context, props)
    module = props.module_name

    parts = selected_parts(context)
    meshes = selected_meshes(context)

    if not with_osl and not parts and not meshes:
        return apply_ripper_pairs(context, props, root)

    if not parts and not meshes:
        raise MOError("Select one or more Part groups, or their faces, first.")

    if with_osl and len(parts) > 1:
        raise MOError(
            "With OSL/BSL takes a single panel - select one Part group, "
            "or use Without OSL/BSL to combine several."
        )

    group = carcass_group(context, props, root)

    if with_osl:

        front, back, edgeband, part = _panel_from_selection(context, root)

        _clear_names([front, back, edgeband])
        _rename_continuing(module, front, back, edgeband, CARCASS_INTERNAL)

        parent_to(group, [front, back, edgeband])

        _finish(context, props, root, [part])

        return "Carcass Internal (With OSL/BSL) applied."

    if parts:
        faces = [face for part in parts for face in all_part_faces(part)]
    else:
        faces = meshes

    if not faces:
        raise MOError("No Front/Back/EdgeBand faces found on the selected group(s).")

    combined = join_objects(context, faces)

    _clear_names([combined])
    combined.name = make_name(module, CARCASS_INTERNAL, next_index(module, CARCASS_INTERNAL))

    parent_to(group, [combined])

    _finish(context, props, root, parts)

    return "Carcass Internal (Without OSL/BSL) applied."


# =========================================================
# Back / Bottom Panel
# =========================================================

NAMED_BOTTOM_PANEL = re.compile(r"bottom[\s_\-]*panel", re.I)


def _lowest_named(root, pattern):
    """Lowest raw mesh whose name matches pattern, or None."""

    matches = [
        obj for obj in root.children_recursive
        if obj.type == 'MESH' and pattern.search(obj.name)
    ]

    if not matches:
        return None

    return min(matches, key=lambda obj: sum(c.z for c in bounds_of([obj])))


# =========================================================
# Panel Options Shared By Top / Bottom Panel
# =========================================================

ROLE_TAG = "mo2_role"


def _tagged(role):
    """Meshes an earlier Top / Bottom Panel run produced, in any option."""

    return [o for o in bpy.data.objects if o.type == 'MESH' and o.get(ROLE_TAG) == role]


def _place_panel(context, props, root, mode, front, back, edgeband, suffix, role, visible_suffix):
    """
    Name and parent one panel for the chosen option, tag the
    result with its role so the next run finds it again.

        VISIBLE    <visible_suffix>_OSL_01 / _BSL_01 / _OSL_02 in car_vs_01
        WITH       <suffix>_OSL_01 / _BSL_01 / _OSL_02 in car_01
        WITHOUT    one <suffix>_01 in car_01
        SHUTTER    new sh_NN group: sh-ft (Front + Back), sh-eb
        CARCASS    one car-in_NN in car_01
        CARCASS_OSL  car-in_OSL / car-in_BSL, numbers continuing, in car_01
        COUNTERTOP / WOOD_COUNTERTOP   (Top Panel only)
    """

    module = props.module_name

    if mode == 'CARCASS_OSL':

        _clear_names([front, back, edgeband])
        _rename_continuing(module, front, back, edgeband, CARCASS_INTERNAL)
        parent_to(carcass_group(context, props, root), [front, back, edgeband])

        results = [front, back, edgeband]

    elif mode == 'WITH':

        _rename_fixed(module, front, back, edgeband, suffix)
        parent_to(carcass_group(context, props, root), [front, back, edgeband])

        results = [front, back, edgeband]

    elif mode == 'VISIBLE':

        _rename_fixed(module, front, back, edgeband, visible_suffix)

        group = get_or_create_group(
            context,
            make_name(module, VISIBLE_SIDE_GROUP, 1),
            carcass_group(context, props, root),
            root,
        )

        parent_to(group, [front, back, edgeband])

        results = [front, back, edgeband]

    elif mode == 'SHUTTER':

        results = build_combined_shutter(context, props, root, front, back, edgeband)

    elif mode == 'WOOD_COUNTERTOP':

        face = join_objects(context, [front, back])
        _clear_names([face, edgeband])

        if face is not None:
            face.name = make_name(module, COUNTERTOP_FRONT, 1)

        if edgeband is not None:
            edgeband.name = make_name(module, COUNTERTOP_EDGEBAND, 1)

        wrapper = get_or_create_group(context, make_name(module, COUNTERTOP_GROUP, 1), root, root)
        parent_to(wrapper, [face, edgeband])

        results = [face, edgeband]

    else:

        combined = join_objects(context, [front, back, edgeband])
        _clear_names([combined])

        if mode == 'WITHOUT':
            combined.name = make_name(module, suffix, 1)
            parent_to(carcass_group(context, props, root), [combined])
        elif mode == 'CARCASS':
            combined.name = make_name(module, CARCASS_INTERNAL, next_index(module, CARCASS_INTERNAL))
            parent_to(carcass_group(context, props, root), [combined])
        else:
            combined.name = make_name(module, COUNTERTOP_COMBINED, 1)
            parent_to(root, [combined])

        results = [combined]

    for obj in results:
        if obj is not None:
            obj[ROLE_TAG] = role


PANEL_MODES = [
    ('VISIBLE', "{} Visible Side", "Visible OSL/BSL naming (car_vs-t / car_vs-b) in car_vs_01"),
    ('WITH', "{} Panel With OSL/BSL", "Outer face OSL, inner face BSL, EdgeBand OSL"),
    ('WITHOUT', "{} Panel Without OSL/BSL", "Join everything into one plain-named object"),
    ('SHUTTER', "Shutter", "Shutter convention with Front and Back combined"),
    ('CARCASS', "Carcass", "Carcass Internal (car-in) - then choose With / Without OSL/BSL"),
]


def panel_modes(side, extra=()):
    """Popup items for 'Top' / 'Bottom', e.g. 'Top Panel With OSL/BSL'."""

    return [(key, name.format(side), tip) for key, name, tip in PANEL_MODES] + list(extra)


CARCASS_OSL_LABEL = "Carcass With OSL/BSL"


def _label(items, mode, title):
    """'Top Panel With OSL/BSL', or 'Top Panel (Shutter)'."""

    names = dict((key, name) for key, name, _tip in items)
    names['CARCASS_OSL'] = CARCASS_OSL_LABEL

    name = names[mode]

    return name if title in name else f"{title} ({name})"


# =========================================================
# Bottom Panel
# =========================================================

BOTTOM_PANEL_LABELS = {
    'VISIBLE': "car_vs-b_OSL/BSL (Visible Side)",
    'WITH': "bt-pnl_OSL/BSL (Bottom Panel)",
    'WITHOUT': "bt-pnl (Bottom Panel)",
}

BOTTOM_PANEL_MODES = [
    (key, BOTTOM_PANEL_LABELS.get(key, name), tip) for key, name, tip in panel_modes("Bottom")
]


def apply_bottom_panel(context, props, mode):
    """
    Bottom panel from, in order: an earlier Bottom Panel run (to
    switch option), the selection, or the mesh named 'Bottom
    Panel'.
    """

    root = _start(context, props)

    previous = _tagged("bottom_panel")
    part = None

    if previous:
        front, back, edgeband = reclassify(context, previous, root)
    elif selected_parts(context) or selected_meshes(context):
        front, back, edgeband, part = _panel_from_selection(context, root)
    else:
        mesh = _lowest_named(root, NAMED_BOTTOM_PANEL)

        if mesh is None:
            raise MOError("No 'Bottom Panel' found - select its Part group or faces first.")

        front, back, edgeband = resolve_panel(context, [mesh], root)

    _place_panel(context, props, root, mode, front, back, edgeband, BOTTOM_PANEL_FACE, "bottom_panel", VISIBLE_BOTTOM)

    _finish(context, props, root, [part])

    return f"{_label(BOTTOM_PANEL_MODES, mode, 'Bottom Panel')} applied."


# =========================================================
# Back Panel
# =========================================================

NAMED_BACK_PANEL = re.compile(r"back[\s_\-]*panel", re.I)

PANEL_INDEX_TAG = "mo2_panel"


def _back_panel_sources(context, root):
    """
    [(front, back, edgeband, part), ...] - the selection (one
    panel), else every raw 'Back Panel…' mesh left to right, else
    the panels an earlier Back Panel run produced (to switch option).
    """

    if selected_parts(context) or selected_meshes(context):
        return [_panel_from_selection(context, root)]

    named = [
        obj for obj in root.children_recursive
        if obj.type == 'MESH' and NAMED_BACK_PANEL.search(obj.name)
    ]

    if named:
        return [(*resolve_panel(context, [mesh], root), None) for mesh in spatial_order(named)]

    previous = {}

    for obj in _tagged("back_panel"):
        previous.setdefault(obj.get(PANEL_INDEX_TAG, 0), []).append(obj)

    if previous:
        return [(*reclassify(context, previous[key], root), None) for key in sorted(previous)]

    raise MOError("No 'Back Panel' found - select its Part group or faces first.")


BACK_PANEL_MODES = [
    ('WITH', "bk-pnl_OSL/BSL (Back Panel)", "Outer face OSL, inner face BSL, EdgeBand OSL, numbers continuing"),
    ('WITHOUT', "bk-pnl (Back Panel)", "Each panel joined into one bk-pnl_NN"),
    ('SHUTTER', "Shutter", "Each panel its own Shutter group, Front and Back combined"),
    ('CARCASS', "Carcass", "Carcass Internal (car-in) in car_01 - then choose With / Without OSL/BSL"),
]


def apply_back_panels(context, props, mode):
    """
    Each back panel, numbered left to right, top to bottom:
        WITH      bk-pnl_OSL_01 / _BSL_01 / _OSL_02, then _OSL_03 / _BSL_02 / ... in car_01
        WITHOUT   bk-pnl_01, bk-pnl_02, ... in car_01
        SHUTTER   own sh_NN group per panel: sh-ft (Front + Back), sh-eb
        CARCASS   whole panel as car-in_NN in car_01
        CARCASS_OSL  car-in_OSL / car-in_BSL, numbers continuing, in car_01
    """

    root = _start(context, props)
    module = props.module_name

    panels = _back_panel_sources(context, root)

    current = [obj for panel in panels for obj in panel[:3] if obj is not None]

    # Panel numbers already used by back panels this run doesn't touch.
    others = [obj for obj in _tagged("back_panel") if obj not in current]
    base = max((obj.get(PANEL_INDEX_TAG, 0) for obj in others), default=0)

    # Lift out of old groups first so emptied Shutter groups are gone
    # before new numbers are handed out.
    parent_to(root, current)
    _clear_names(current)
    remove_empty_shutter_groups(props)

    named = []

    for number, (front, back, edgeband, _part) in enumerate(panels, start=base + 1):

        if mode == 'SHUTTER':

            results = build_combined_shutter(context, props, root, front, back, edgeband)
            named.append(results[0].parent.name)

        else:

            if mode in ('WITH', 'CARCASS_OSL'):
                suffix = BACK_PANEL_FACE if mode == 'WITH' else CARCASS_INTERNAL
                _rename_continuing(module, front, back, edgeband, suffix)
                results = [obj for obj in (front, back, edgeband) if obj is not None]
            else:
                combined = join_objects(context, [front, back, edgeband])
                suffix = BACK_PANEL_FACE if mode == 'WITHOUT' else CARCASS_INTERNAL
                combined.name = make_name(module, suffix, next_index(module, suffix))
                results = [combined]

            parent_to(carcass_group(context, props, root), results)
            named.append(results[0].name)

        for obj in results:
            obj[ROLE_TAG] = "back_panel"
            obj[PANEL_INDEX_TAG] = number

    _finish(context, props, root, [panel[3] for panel in panels])

    return f"{len(panels)} Back Panel(s), {_label(BACK_PANEL_MODES, mode, 'Back Panel')}: " + ", ".join(named) + "."


# =========================================================
# Visible Top / Bottom
# =========================================================

def apply_visible_top_bottom(context, props, suffix, label):

    root = _start(context, props)
    module = props.module_name

    osl_name = make_name(module, f"{suffix}_{OSL}", 1)

    if osl_name in bpy.data.objects:
        raise MOError(f"'{osl_name}' already exists (one {label} Visible per module).")

    front, back, edgeband, part = _panel_from_selection(context, root)

    _rename_fixed(module, front, back, edgeband, suffix)

    group = get_or_create_group(
        context,
        make_name(module, VISIBLE_SIDE_GROUP, 1),
        carcass_group(context, props, root),
        root,
    )

    parent_to(group, [front, back, edgeband])

    _finish(context, props, root, [part])

    return f"{label} Visible OSL/BSL assigned into '{group.name}'."


# =========================================================
# Left / Right Panel Detection (LP / RP)
# =========================================================

def _side(front, back, edgeband, part=None):

    return {"front": front, "back": back, "edgeband": edgeband, "part": part}


def _side_objects(side):

    return [obj for obj in (side["front"], side["back"], side["edgeband"]) if obj]


def _left_right_from_parts(root):
    """Outermost raw Parts along X that still have Front/Back."""

    candidates = []

    for part in raw_parts(root):

        front, back, edgeband = part_faces(part)

        reference = front or back

        if reference is None:
            continue

        center = face_center(reference)

        if center is not None:
            candidates.append((center.x, _side(front, back, edgeband, part)))

    if len(candidates) < 2:
        return None, None

    candidates.sort(key=lambda pair: pair[0])

    return candidates[0][1], candidates[-1][1]


def _left_right_from_objects(context, root, objects):
    """Re-derive both sides purely from geometry, split at the centre X."""

    center = module_center(root)

    if center is None or not objects:
        return None, None

    surfaces, edges = classify_pieces(split_objects(context, objects))

    def is_left(obj):
        position = face_center(obj)
        return position is not None and position.x < center.x

    def build(side_surfaces, side_edges):

        front, back = pick_front_back(side_surfaces, center)

        if front is None:
            return None

        return _side(front, back, join_objects(context, side_edges))

    # Partition before building - building joins (and deletes) edges.
    left_surfaces = [o for o in surfaces if is_left(o)]
    right_surfaces = [o for o in surfaces if not is_left(o)]
    left_edges = [o for o in edges if is_left(o)]
    right_edges = [o for o in edges if not is_left(o)]

    return build(left_surfaces, left_edges), build(right_surfaces, right_edges)


def _lr_prefixes(module):

    return (f"{module}_{VISIBLE_SIDE_LEFT}_", f"{module}_{VISIBLE_SIDE_RIGHT}_")


def _existing_side_objects(module):
    """LP/RP meshes a previous Sides / L-R Visible run produced."""

    objects = []

    vs_group = bpy.data.objects.get(make_name(module, VISIBLE_SIDE_GROUP, 1))

    if vs_group is not None:
        objects.extend(
            child for child in vs_group.children
            if child.type == 'MESH' and child.name.startswith(_lr_prefixes(module))
        )

    sd_group = bpy.data.objects.get(make_name(module, SIDE_PANEL_GROUP, 1))

    if sd_group is not None:
        objects.extend(child for child in sd_group.children if child.type == 'MESH')

    return objects


NAMED_SIDE_PANELS = {
    "left": re.compile(r"side[\s_\-]*panel.*left", re.I),
    "right": re.compile(r"side[\s_\-]*panel.*right", re.I),
}


def _left_right_from_names(context, root):
    """
    'Side Panel Left' / 'Side Panel Right' raw meshes, each split
    into its own Front / Back / EdgeBand. (None, None) if either
    is missing.
    """

    found = {}

    for obj in root.children_recursive:

        if obj.type != 'MESH':
            continue

        for side, pattern in NAMED_SIDE_PANELS.items():
            if side not in found and pattern.search(obj.name):
                found[side] = obj

    if len(found) < 2:
        return None, None

    return tuple(
        _side(*resolve_panel(context, [found[side]], root)) for side in ("left", "right")
    )


def find_left_right(context, props, root):
    """
    LP/RP from, in order: a previous Sides run (so switching
    naming reuses the same panels), the current selection, meshes
    named 'Side Panel Left' / 'Right', or a scan of raw Parts. A
    selection is never second-guessed.
    """

    # Any earlier Side Panels run (every option tags its output).
    previous = {}

    for obj in _tagged("side_panels"):
        previous.setdefault(obj.get(PANEL_INDEX_TAG, 0), []).append(obj)

    if 1 in previous and 2 in previous:
        return tuple(_side(*reclassify(context, previous[key], root)) for key in (1, 2))

    existing = _existing_side_objects(props.module_name)

    if existing:

        left, right = _left_right_from_objects(context, root, existing)

        if left and right:
            return left, right

    selection = selected_meshes_expanded(context)

    if selection:
        return _left_right_from_objects(context, root, selection)

    left, right = _left_right_from_names(context, root)

    if left and right:
        return left, right

    return _left_right_from_parts(root)


def _remove_empty_side_groups(module):

    for suffix in (VISIBLE_SIDE_GROUP, SIDE_PANEL_GROUP):
        remove_if_empty(bpy.data.objects.get(make_name(module, suffix, 1)))


def _tag_sides(results_by_side):
    """Tag each side's objects (1 = left, 2 = right) so the next run finds them."""

    for number, objects in enumerate(results_by_side, start=1):
        for obj in objects:
            obj[ROLE_TAG] = "side_panels"
            obj[PANEL_INDEX_TAG] = number


def _place_sides(context, props, root, left, right, group_suffix):

    _tag_sides([_side_objects(left), _side_objects(right)])

    group = get_or_create_group(
        context,
        make_name(props.module_name, group_suffix, 1),
        carcass_group(context, props, root),
        root,
    )

    for side in (left, right):
        parent_to(group, _side_objects(side))

    _finish(context, props, root, [left["part"], right["part"]])

    _remove_empty_side_groups(props.module_name)

    return group


_NOT_FOUND = (
    "Could not find 2 distinct side panels (need 2 Parts with Front/Back "
    "faces, or a selection that splits into a left and right panel)."
)


# =========================================================
# Sides Panel
# =========================================================

def apply_sides_panel(context, props):
    """LP/RP named sd-pnl_OSL/BSL_NN, grouped in car_sd_01."""

    root = _start(context, props)

    left, right = find_left_right(context, props, root)

    if not left or not right:
        raise MOError(_NOT_FOUND)

    _clear_names(_side_objects(left) + _side_objects(right))

    for side in (left, right):
        _rename_continuing(
            props.module_name, side["front"], side["back"], side["edgeband"], SIDE_PANEL
        )

    group = _place_sides(context, props, root, left, right, SIDE_PANEL_GROUP)

    return f"Side panels assigned into '{group.name}'."


def apply_sides_panel_whole(context, props):
    """Each whole LP/RP joined into one sd-pnl_NN, grouped in car_sd_01."""

    root = _start(context, props)
    module = props.module_name

    left, right = find_left_right(context, props, root)

    if not left or not right:
        raise MOError(_NOT_FOUND)

    _clear_names(_side_objects(left) + _side_objects(right))

    whole = []

    for side in (left, right):
        combined = join_objects(context, _side_objects(side))
        combined.name = make_name(module, SIDE_PANEL, next_index(module, SIDE_PANEL))
        whole.append(_side(combined, None, None, side["part"]))

    group = _place_sides(context, props, root, whole[0], whole[1], SIDE_PANEL_GROUP)

    return f"Side panels assigned into '{group.name}'."


# =========================================================
# Side Panels as Shutter / Carcass
# =========================================================

def apply_sides_as(context, props, mode):
    """
    Each side panel (left first) as:
        SHUTTER   its own sh_NN group: sh-ft (Front + Back), sh-eb
        CARCASS   one whole car-in_NN in car_01
        CARCASS_OSL  car-in_OSL / car-in_BSL, numbers continuing, in car_01
    """

    root = _start(context, props)
    module = props.module_name

    left, right = find_left_right(context, props, root)

    if not left or not right:
        raise MOError(_NOT_FOUND)

    # Lift both panels out of their old groups first so emptied
    # groups are gone before new numbers are handed out.
    current = _side_objects(left) + _side_objects(right)
    parent_to(root, current)
    _clear_names(current)
    remove_empty_shutter_groups(props)
    _remove_empty_side_groups(module)

    results_by_side = []
    named = []

    for side in (left, right):

        if mode == 'SHUTTER':
            results = build_combined_shutter(
                context, props, root, side["front"], side["back"], side["edgeband"]
            )
            named.append(results[0].parent.name)
        elif mode == 'CARCASS_OSL':
            _rename_continuing(module, side["front"], side["back"], side["edgeband"], CARCASS_INTERNAL)
            results = _side_objects(side)
            parent_to(carcass_group(context, props, root), results)
            named.append(results[0].name)
        else:
            combined = join_objects(context, _side_objects(side))
            combined.name = make_name(module, CARCASS_INTERNAL, next_index(module, CARCASS_INTERNAL))
            parent_to(carcass_group(context, props, root), [combined])
            results = [combined]
            named.append(combined.name)

        results_by_side.append(results)

    _tag_sides(results_by_side)

    _finish(context, props, root, [left["part"], right["part"]])

    title = {'SHUTTER': "Shutter", 'CARCASS': "Carcass", 'CARCASS_OSL': CARCASS_OSL_LABEL}[mode]

    return f"Side Panels ({title}): " + ", ".join(named) + "."


# =========================================================
# L/R Visible Side
# =========================================================

def apply_visible_sides(context, props):
    """LP/RP named car_vs-l / car_vs-r (fixed numbers) in car_vs_01."""

    root = _start(context, props)
    module = props.module_name

    vs_group = bpy.data.objects.get(make_name(module, VISIBLE_SIDE_GROUP, 1))

    previous = []

    if vs_group is not None:
        previous = [c for c in vs_group.children if c.name.startswith(_lr_prefixes(module))]

    if previous and not selected_meshes_expanded(context):
        raise MOError(
            f"L/R Visible Sides already applied in '{vs_group.name}' - select "
            "new side faces to replace them."
        )

    left, right = find_left_right(context, props, root)

    if not left or not right:
        raise MOError(_NOT_FOUND)

    # Only now that the new pair resolved, drop what it replaces.
    keep = set(_side_objects(left) + _side_objects(right))

    for obj in previous:

        try:
            reused = obj in keep
        except ReferenceError:
            continue

        if not reused:
            _safe_remove(obj)

    _rename_fixed(module, left["front"], left["back"], left["edgeband"], VISIBLE_SIDE_LEFT)
    _rename_fixed(module, right["front"], right["back"], right["edgeband"], VISIBLE_SIDE_RIGHT)

    group = _place_sides(context, props, root, left, right, VISIBLE_SIDE_GROUP)

    return f"L/R Visible Sides assigned into '{group.name}'."


# =========================================================
# Top Panel - Detection
# =========================================================

def _part_bounds(part):

    return bounds_of([obj for obj in part.children_recursive if obj.type == 'MESH'])


def _find_top_part(root):
    """Raw Part with the highest bounding-box centre Z."""

    best = None
    best_z = None

    for part in raw_parts(root):

        bounds = _part_bounds(part)

        if bounds is None:
            continue

        z = (bounds[0].z + bounds[1].z) / 2.0

        if best_z is None or z > best_z:
            best, best_z = part, z

    return best


def _spans_module(part, module_lo, module_hi):
    """A real top panel covers most of the module's width."""

    bounds = _part_bounds(part)
    width = module_hi.x - module_lo.x

    if bounds is None or width <= 0:
        return False

    return (bounds[1].x - bounds[0].x) >= TOP_PANEL_MIN_WIDTH_RATIO * width


def _existing_top_panel(module):
    """(objects, wrapper) from an earlier Top Panel run in any mode."""

    def get(suffix, index):
        return bpy.data.objects.get(make_name(module, suffix, index))

    tagged = _tagged("top_panel")

    if tagged:
        return tagged, get(COUNTERTOP_GROUP, 1)

    found = [
        obj for obj in (
            get(f"{TOP_PANEL_FACE}_{OSL}", 1),
            get(f"{TOP_PANEL_FACE}_{BSL}", 1),
            get(f"{TOP_PANEL_FACE}_{OSL}", 2),
        )
        if obj is not None
    ]

    if found:
        return found, None

    combined = get(TOP_PANEL_FACE, 1) or get(COUNTERTOP_COMBINED, 1)

    if combined is not None:
        return [combined], None

    wrapper = get(COUNTERTOP_GROUP, 1)

    if wrapper is not None:

        found = [o for o in (get(COUNTERTOP_FRONT, 1), get(COUNTERTOP_EDGEBAND, 1)) if o]

        if found:
            return found, wrapper

    return None, None


def _y_span_at_x(meshes, target_x, tolerance):
    """Real depth of whatever geometry touches world X == target_x."""

    min_y = max_y = None

    for obj in meshes:

        bounds = bounds_of([obj])

        if bounds is None:
            continue

        if not (bounds[0].x - tolerance <= target_x <= bounds[1].x + tolerance):
            continue

        matrix = obj.matrix_world

        for vertex in obj.data.vertices:

            world = matrix @ vertex.co

            if abs(world.x - target_x) > tolerance:
                continue

            min_y = world.y if min_y is None else min(min_y, world.y)
            max_y = world.y if max_y is None else max(max_y, world.y)

    if min_y is None:
        return None

    return min_y, max_y


def build_top_panel(context, root):
    """
    New 18mm top panel resting on the module: X spans LP to RP,
    depth matches LP. Returns (top face, underside, EdgeBand).
    """

    meshes = structural_meshes(root)

    bounds = bounds_of(meshes)

    if bounds is None:
        raise MOError("Module has no mesh geometry to measure.")

    lo, hi = bounds

    tolerance = max((hi.x - lo.x) * 1e-4, 1e-6)

    depth = _y_span_at_x(meshes, lo.x, tolerance)

    if depth is None:
        raise MOError("Could not measure the left panel's depth.")

    y0, y1 = depth

    height = mm_to_native([hi.x - lo.x, y1 - y0, hi.z - lo.z], TOP_PANEL_HEIGHT_MM)

    collection = root.users_collection[0] if root.users_collection else context.collection

    faces = make_box_faces("TopPanel", lo.x, hi.x, y0, y1, hi.z, hi.z + height, collection)

    edgeband = join_objects(context, [faces["-X"], faces["+X"], faces["-Y"], faces["+Y"]])

    return faces["+Z"], faces["-Z"], edgeband


SHELF_PATTERNS = {
    REMOVABLE_SHELF: re.compile(r"removable[\s_\-]*shel", re.I),
    FIXED_SHELF: re.compile(r"fixed[\s_\-]*shel", re.I),
}


# =========================================================
# Removable / Fixed Shelf
# =========================================================

SHELF_MODES = [
    ('SHELF', "{}", "Whole shelf as one object directly in the main group"),
    ('SHUTTER', "Shutter", "Shutter convention with Front and Back combined, one group per shelf"),
    ('CARCASS', "Carcass", "Whole shelf as one Carcass Internal (car-in) in car_01"),
]


def shelf_modes(label):

    return [(key, name.format(label), tip) for key, name, tip in SHELF_MODES]


def _shelf_sources(context, root, suffix):
    """
    [[meshes of one shelf], ...]: raw meshes named like the shelf
    type, else the selection, else the shelves an earlier run of
    this button produced (to switch option). Plus Part groups the
    selection used, for cleanup.
    """

    pattern = SHELF_PATTERNS[suffix]

    found = [
        obj for obj in root.children_recursive
        if obj.type == 'MESH' and pattern.search(obj.name)
    ]

    if found:
        return [[obj] for obj in spatial_order(found)], []

    parts = selected_parts(context)

    shelves = [[c for c in part.children if c.type == 'MESH'] for part in spatial_order(parts)]
    shelves += [[obj] for obj in spatial_order(selected_meshes(context))]
    shelves = [meshes for meshes in shelves if meshes]

    if shelves:
        return shelves, parts

    previous = {}

    for obj in _tagged(suffix):
        previous.setdefault(obj.get(PANEL_INDEX_TAG, 0), []).append(obj)

    return [previous[key] for key in sorted(previous)], []


def apply_shelves(context, props, suffix, label, mode='SHELF'):
    """
    Removable / Fixed shelves, numbered left to right, top to bottom:

        SHELF     whole shelf as <suffix>_NN in the main group
        SHUTTER   new sh_NN group per shelf: sh-ft (Front + Back), sh-eb
        CARCASS   whole shelf as car-in_NN in car_01
    """

    root = _start(context, props)
    module = props.module_name

    shelves, parts = _shelf_sources(context, root, suffix)

    if not shelves:
        raise MOError(f"No '{label}' found - select its Part group or faces first.")

    # Lift everything out of its old groups first, so emptied Shutter
    # groups are gone before any new number is handed out.
    current = [obj for meshes in shelves for obj in meshes]
    parent_to(root, current)
    _clear_names(current)
    remove_empty_shutter_groups(props)

    named = []

    for number, meshes in enumerate(shelves, start=1):

        if mode == 'SHUTTER':
            front, back, edgeband = reclassify(context, meshes, root)
            results = build_combined_shutter(context, props, root, front, back, edgeband)
            named.append(results[0].parent.name)
        else:
            shelf = join_objects(context, meshes)

            if mode == 'CARCASS':
                shelf.name = make_name(module, CARCASS_INTERNAL, next_index(module, CARCASS_INTERNAL))
                parent_to(carcass_group(context, props, root), [shelf])
            else:
                shelf.name = make_name(module, suffix, next_index(module, suffix))

            results = [shelf]
            named.append(shelf.name)

        for obj in results:
            obj[ROLE_TAG] = suffix
            obj[PANEL_INDEX_TAG] = number

    _finish(context, props, root, parts)

    title = _label(shelf_modes(label), mode, label)

    return f"{len(shelves)} {title}: " + ", ".join(named) + "."


NAMED_TOP_PANEL = re.compile(r"top[\s_\-]*panel", re.I)


def _named_top_panel(root):
    """Highest raw mesh with 'Top Panel' in its name, e.g. 'Curved Top Panel Both Side'."""

    best = None
    best_z = None

    for obj in root.children_recursive:

        if obj.type != 'MESH' or not NAMED_TOP_PANEL.search(obj.name):
            continue

        lo, hi = bounds_of([obj])
        z = lo.z + hi.z

        if best_z is None or z > best_z:
            best, best_z = obj, z

    return best


def _top_panel_source(context, props, root):
    """
    (front, back, edgeband, leftover): an earlier Top Panel run's
    output, else the selection, else a mesh named 'Top Panel',
    else the highest full-width Part, else a newly built panel.
    """

    objects, wrapper = _existing_top_panel(props.module_name)

    if objects:
        return (*reclassify(context, objects, root), wrapper)

    selection = selected_meshes_expanded(context)

    if selection:
        return (*reclassify(context, selection, root), None)

    named = _named_top_panel(root)

    if named is not None:
        return (*reclassify(context, [named], root), None)

    part = _find_top_part(root)

    if part is not None:

        bounds = bounds_of(structural_meshes(root))

        if bounds is not None and _spans_module(part, *bounds):
            return (*part_faces(part), part)

    return (*build_top_panel(context, root), None)


# =========================================================
# Top Panel - Apply
# =========================================================

TOP_PANEL_LABELS = {
    'VISIBLE': "car_vs-t_OSL/BSL (Visible Side)",
    'WITH': "tp-pnl_OSL/BSL (Top Panel)",
    'WITHOUT': "tp-pnl (Top Panel)",
}

TOP_PANEL_MODES = [
    ('COUNTERTOP', "Counter Top", "Join everything into one Counter Top object"),
    ('WOOD_COUNTERTOP', "Wood Counter Top",
     "Join top + underside, keep EdgeBand separate, grouped together"),
] + [(key, TOP_PANEL_LABELS.get(key, name), tip) for key, name, tip in panel_modes("Top")]


def apply_top_panel(context, props, mode):

    root = _start(context, props)

    front, back, edgeband, leftover = _top_panel_source(context, props, root)

    if front is None and back is None and edgeband is None:
        raise MOError("Could not determine the top panel.")

    _place_panel(context, props, root, mode, front, back, edgeband, TOP_PANEL_FACE, "top_panel", VISIBLE_TOP)

    _finish(context, props, root, [leftover])

    return f"{_label(TOP_PANEL_MODES, mode, 'Top Panel')} applied."

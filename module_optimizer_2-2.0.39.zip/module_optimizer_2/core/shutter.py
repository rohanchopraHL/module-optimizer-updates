"""
Shutter convention.

Select Part group(s), already-converted Shutter groups, their
faces, or faces from another convention, then pick Combine /
Without Combine:

    <module>_sh_NN      group
    <module>_sh-ft_NN   Front (Front + Back when combined)
    <module>_sh-bk_NN   Back
    <module>_sh-eb_NN   EdgeBand

A group that is already '<module>_sh_NN' keeps its number, so
toggling Combine on the same door never shifts it. Loose faces
become a brand-new Shutter group.

Without Combine also finds raw import meshes by name - Drawer
Fascias and Plain Shutters - and gives each its own new group,
no selection needed. Once none are left it works on the
selection as above.

All Combine finds Curved End Panel Left / Right (else uses the
selection) and keeps each whole panel as one '<module>_sh-ft_NN'
in its own group.

New groups are numbered by position: columns left (-X) to
right (+X), top to bottom within a column.
"""

import re

import bpy

from ..config import (
    PART_PREFIX,
    SHUTTER_GROUP,
    SHUTTER_FRONT,
    SHUTTER_BACK,
    SHUTTER_EDGEBAND,
)

from .common import (
    MOError,
    require_root,
    ensure_module_name,
    make_name,
    next_index,
    existing_index,
    join_objects,
    parent_to,
    link_like,
    refresh,
    bounds_of,
    remove_empty_shutter_groups,
)

from .geometry import part_faces, resolve_panel


# =========================================================
# Selection
# =========================================================

def _is_shutter_source(obj):

    if obj.type != 'EMPTY':
        return False

    return obj.name.startswith(PART_PREFIX) or f"_{SHUTTER_GROUP}_" in obj.name


def classify_selection(context):
    """
    (groups, loose): groups picked directly or via one of their
    faces, and meshes that belong to no Part / Shutter group.
    """

    groups = []
    loose = []

    for obj in context.selected_objects:

        if _is_shutter_source(obj):
            target = obj
        elif obj.type == 'MESH' and obj.parent is not None and _is_shutter_source(obj.parent):
            target = obj.parent
        elif obj.type == 'MESH':
            loose.append(obj)
            continue
        else:
            continue

        if target not in groups:
            groups.append(target)

    return groups, loose


# =========================================================
# Naming
# =========================================================

def _name_group(context, props, group, front, back, edgeband, combine, index):

    if combine and front is not None and back is not None:
        front = join_objects(context, [front, back])
        back = None

    parent_to(group, [front, back, edgeband])

    module = props.module_name

    if front is not None:
        front.name = make_name(module, SHUTTER_FRONT, index)

    if back is not None:
        back.name = make_name(module, SHUTTER_BACK, index)

    if edgeband is not None:
        edgeband.name = make_name(module, SHUTTER_EDGEBAND, index)

    group.name = make_name(module, SHUTTER_GROUP, index)


def _group_faces(context, root, group):
    """Front/Back/EdgeBand by name, else re-derived from geometry."""

    front, back, edgeband = part_faces(group)

    if front is not None or back is not None:
        return front, back, edgeband

    meshes = [child for child in group.children if child.type == 'MESH']

    if not meshes:
        raise MOError(f"'{group.name}' has no panel geometry to convert.")

    return resolve_panel(context, meshes, root)


def _new_group(context, root):

    group = bpy.data.objects.new("Shutter Group", None)
    group.empty_display_type = 'PLAIN_AXES'

    link_like(group, root, context)

    group.matrix_world = root.matrix_world.copy()
    parent_to(root, [group])

    return group


def build_combined_shutter(context, props, root, front, back, edgeband):
    """
    One panel as a new Shutter group with Front + Back combined -
    used by Top / Bottom Panel's 'Shutter' option. Returns the
    resulting objects.
    """

    group = _new_group(context, root)

    face = join_objects(context, [front, back])

    parent_to(group, [face, edgeband])

    # A previous Shutter run on this panel leaves its group empty
    # now - drop it first so its number is reused.
    remove_empty_shutter_groups(props)

    for obj in (face, edgeband):
        if obj is not None:
            obj.name = "mo2_renaming"

    index = next_index(props.module_name, SHUTTER_GROUP)

    _name_group(context, props, group, face, None, edgeband, False, index)

    return [obj for obj in (face, edgeband) if obj is not None]


# =========================================================
# Named Shutters (raw import names)
# =========================================================

NAMED_SHUTTERS = re.compile(
    r"drawer[\s_\-]*fa(scia|sica|cia)|plain[\s_\-]*shutter", re.I
)

# Wardrobes > Shutter: Hinged Wardrobe Plain Left / Right 1, 2 ...
WARDROBE_SHUTTERS = re.compile(r"hinged[\s_\-]*wardrobe[\s_\-]*plain", re.I)


def _extent(obj):
    """World bounds of a mesh, or of a group's meshes."""

    meshes = [obj] if obj.type == 'MESH' else [
        child for child in obj.children_recursive if child.type == 'MESH'
    ]

    return bounds_of(meshes)


def spatial_order(objects):
    """
    Left (-X) to right (+X) by column, top to bottom inside a
    column. Panels share a column when their X ranges overlap by
    at least half of the narrower one.
    """

    placed = []
    unplaced = []

    for obj in objects:

        bounds = _extent(obj)

        if bounds is None:
            unplaced.append(obj)
        else:
            placed.append((bounds[0], bounds[1], obj))

    placed.sort(key=lambda item: (item[0].x + item[1].x) / 2.0)

    columns = []

    for lo, hi, obj in placed:

        if columns:

            column = columns[-1]

            overlap = min(hi.x, column["hi"]) - max(lo.x, column["lo"])
            narrower = min(hi.x - lo.x, column["hi"] - column["lo"])

            if narrower > 0 and overlap >= 0.5 * narrower:
                column["items"].append((hi.z + lo.z, obj))
                column["lo"] = min(column["lo"], lo.x)
                column["hi"] = max(column["hi"], hi.x)
                continue

        columns.append({"lo": lo.x, "hi": hi.x, "items": [(hi.z + lo.z, obj)]})

    ordered = []

    for column in columns:
        column["items"].sort(key=lambda item: -item[0])
        ordered.extend(obj for _z, obj in column["items"])

    return ordered + unplaced


def find_named_shutters(root, pattern=NAMED_SHUTTERS):
    """Meshes in the module whose names match pattern, in numbering order."""

    return spatial_order([
        obj for obj in root.children_recursive
        if obj.type == 'MESH' and pattern.search(obj.name)
    ])


def _convert_named(context, props, root, meshes):

    index = next_index(props.module_name, SHUTTER_GROUP)

    converted = []
    skipped = []

    for mesh in meshes:

        source = mesh.name

        try:
            front, back, edgeband = resolve_panel(context, [mesh], root)
        except MOError as error:
            skipped.append(f"'{source}': {error}")
            continue

        group = _new_group(context, root)
        _name_group(context, props, group, front, back, edgeband, False, index)

        converted.append(f"{source} -> {group.name}")
        index += 1

    bpy.ops.object.select_all(action='DESELECT')
    refresh(context)

    if not converted:
        raise MOError(" ".join(skipped))

    message = f"{len(converted)} Shutter group(s): " + ", ".join(converted) + "."

    if skipped:
        message += " Skipped " + " ".join(skipped)

    return message


# =========================================================
# All Combine (whole panel -> one sh-ft object)
# =========================================================

# Each kept whole on its own: Curved End Panel Left / Right,
# Bed Side Panel Left / Right, Bed Footboard.
ALL_COMBINE_PANELS = re.compile(
    r"curved[\s_\-]*end[\s_\-]*panel|bed[\s_\-]*(side[\s_\-]*panel|foot[\s_\-]*board)", re.I
)

# Every Headboard part (Head board, back rippers, side / top frames)
# joined into one panel.
HEADBOARD_PARTS = re.compile(r"head[\s_\-]*board", re.I)


def find_curved_end_panels(context, root):
    """
    All Combine with nothing selected: whole panels to convert, in
    numbering order. The Headboard parts are joined into one first.
    """

    meshes = [obj for obj in root.children_recursive if obj.type == 'MESH']

    panels = [obj for obj in meshes if ALL_COMBINE_PANELS.search(obj.name)]

    headboard = [obj for obj in meshes if HEADBOARD_PARTS.search(obj.name) and obj not in panels]

    if headboard:
        source = next((obj for obj in headboard if re.fullmatch(r"\s*head[\s_\-]*board[\s.\d]*", obj.name, re.I)), headboard[0])
        joined = join_objects(context, [source] + [obj for obj in headboard if obj is not source])
        joined.name = "Headboard"
        panels.append(joined)

    return spatial_order(panels)


def _all_combined(context, props, group, meshes, index):
    """Every mesh of the panel joined into '<module>_sh-ft_NN' in group."""

    face = join_objects(context, meshes)

    parent_to(group, [face])

    face.name = make_name(props.module_name, SHUTTER_FRONT, index)
    group.name = make_name(props.module_name, SHUTTER_GROUP, index)


def apply_all_combine(context, props, root):
    """
    Found by name (left first): Curved End Panel Left / Right, Bed Side
    Panel Left / Right, Bed Footboard, and the Headboard (all its parts
    joined) - or else the selection. Each panel kept whole as one sh-ft.
    """

    index = next_index(props.module_name, SHUTTER_GROUP)

    converted = []

    panels = find_curved_end_panels(context, root)

    if panels:

        for mesh in panels:

            source = mesh.name

            _all_combined(context, props, _new_group(context, root), [mesh], index)

            converted.append(f"{source} -> {make_name(props.module_name, SHUTTER_GROUP, index)}")
            index += 1

    else:

        groups, loose = classify_selection(context)

        if not groups and not loose:
            raise MOError(
                "No Curved End Panel, Bed Side Panel, Bed Footboard or Headboard "
                "found - select a Part group, a Shutter "
                "group, or panel faces first."
            )

        for group in spatial_order(groups):

            meshes = [child for child in group.children if child.type == 'MESH']

            if not meshes:
                continue

            own = existing_index(props.module_name, SHUTTER_GROUP, group)

            if own is None:
                own, index = index, index + 1

            _all_combined(context, props, group, meshes, own)
            converted.append(group.name)

        if loose:
            _all_combined(context, props, _new_group(context, root), loose, index)
            converted.append(make_name(props.module_name, SHUTTER_GROUP, index))

    bpy.ops.object.select_all(action='DESELECT')
    refresh(context)

    if not converted:
        raise MOError("Nothing to convert.")

    return f"{len(converted)} Shutter group(s), All Combine: " + ", ".join(converted) + "."


# =========================================================
# Apply
# =========================================================

def apply_shutter(context, props, mode, named_pattern=NAMED_SHUTTERS, named_label="Drawer Fascia / Plain Shutter"):
    """
    mode: 'COMBINE', 'WITHOUT' or 'ALL'. Without Combine with nothing
    selected converts the meshes named like named_pattern (Cabinets:
    Drawer Fascia / Plain Shutter; Wardrobes: Hinged Wardrobe Plain).
    """

    root = require_root(context)
    ensure_module_name(props, root)

    if mode == 'ALL':
        return apply_all_combine(context, props, root)

    combine = mode == 'COMBINE'

    if not combine:

        named = find_named_shutters(root, named_pattern)

        if named:
            return _convert_named(context, props, root, named)

    groups, loose = classify_selection(context)

    groups = spatial_order(groups)

    if not groups and not loose:
        raise MOError(
            f"No {named_label} found - select a Part group, "
            "a Shutter group, or panel faces first."
        )

    next_free = next_index(props.module_name, SHUTTER_GROUP)

    processed = 0
    skipped = []

    for group in groups:

        try:
            front, back, edgeband = _group_faces(context, root, group)
        except MOError as error:
            skipped.append(str(error))
            continue

        index = existing_index(props.module_name, SHUTTER_GROUP, group)

        if index is None:
            index = next_free
            next_free += 1

        _name_group(context, props, group, front, back, edgeband, combine, index)

        processed += 1

    if loose:

        try:
            front, back, edgeband = resolve_panel(context, loose, root)
        except MOError as error:
            skipped.append(str(error))
        else:
            group = _new_group(context, root)
            _name_group(context, props, group, front, back, edgeband, combine, next_free)
            processed += 1

    refresh(context)

    if processed == 0:
        raise MOError(skipped[0] if skipped else "Nothing to convert.")

    message = f"{processed} Shutter group(s) converted."

    if skipped:
        message += " Skipped: " + " ".join(skipped)

    return message

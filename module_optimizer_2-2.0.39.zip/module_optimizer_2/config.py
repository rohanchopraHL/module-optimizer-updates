"""
Module Optimizer 2.0 - constants.

Every name, size and tolerance the add-on uses lives here.
"""

# =========================================================
# Categories
# =========================================================

# The panel's Category dropdown, "Select" until one is picked. Each
# category has its own Conventions; the rest of the panel is shared.
CATEGORIES = [
    ("NONE", "Select", "Choose what you're working on"),
    ("CABINETS", "Cabinets", "Kitchen and furniture cabinet modules"),
    ("WARDROBES", "Wardrobes", "Wardrobe modules"),
]

# Categories that hide the Handle Library and Skirting sections (none now).
CATEGORIES_WITHOUT_HANDLES_SKIRTING = set()

# Wardrobes Conventions buttons, in three framed groups. Buttons not set
# up yet only report that (mo2.wardrobe_tool).
WARDROBE_BUTTONS = [
    [("CARCASS", "Carcass"), ("SHUTTER", "Shutter")],
    [("TOP_PANEL", "Top Panel"), ("BACK_PANEL", "Back Panel"), ("SIDE_PANELS", "Side Panels"), ("BOTTOM_PANEL", "Bottom Panel")],
    [("REMOVABLE_SHELF", "Removable Shelf"), ("FIXED_SHELF", "Fixed Shelf"), ("VERTICAL_PANEL", "Vertical Panel")],
]

# =========================================================
# Geometry
# =========================================================

ZERO_TOLERANCE = 0.001

# A face whose smallest non-zero side (in mm) falls in this
# range is an edge strip (EdgeBand), anything wider is a
# surface (Front / Back).
EDGE_MIN_MM = 5.0
EDGE_MAX_MM = 25.0

# Largest bounding-box side below this reads as metres,
# at or above it as millimetres.
METER_THRESHOLD = 10.0

# =========================================================
# Raw Import Naming
# =========================================================

NAME_SEPARATOR = "_"

PART_PREFIX = "Part"
FACE_PREFIX = "Face"

FRONT_NAME = "Front"
BACK_NAME = "Back"
EDGEBAND_NAME = "EdgeBand"

OSL = "OSL"
BSL = "BSL"

# =========================================================
# Carcass Naming
# =========================================================

CARCASS_GROUP = "car"
CARCASS_INTERNAL = "car-in"

VISIBLE_SIDE_GROUP = "car_vs"
VISIBLE_SIDE_LEFT = "car_vs-l"
VISIBLE_SIDE_RIGHT = "car_vs-r"
VISIBLE_TOP = "car_vs-t"
VISIBLE_BOTTOM = "car_vs-b"

SIDE_PANEL_GROUP = "car_sd"
SIDE_PANEL = "sd-pnl"

REMOVABLE_SHELF = "var-shlf"
FIXED_SHELF = "fxd-shlf"

TOP_PANEL_FACE = "tp-pnl"
BACK_PANEL_FACE = "bk-pnl"
BOTTOM_PANEL_FACE = "bt-pnl"
VERTICAL_PANEL_FACE = "vt-pnl"     # Wardrobes: Centre Vertical Panel

# =========================================================
# Counter Top Naming
# =========================================================

COUNTERTOP_GROUP = "c-top_sh"
COUNTERTOP_FRONT = "c-top_sh-ft"
COUNTERTOP_EDGEBAND = "c-top_sh-eb"
COUNTERTOP_COMBINED = "c-top"

# =========================================================
# Shutter Naming
# =========================================================

SHUTTER_GROUP = "sh"
SHUTTER_FRONT = "sh-ft"
SHUTTER_BACK = "sh-bk"
SHUTTER_EDGEBAND = "sh-eb"

# =========================================================
# Top Panel (auto-built when the module has none)
# =========================================================

TOP_PANEL_HEIGHT_MM = 18.0

# The highest Part only counts as the top panel if it spans
# at least this fraction of the module's width.
TOP_PANEL_MIN_WIDTH_RATIO = 0.6

# =========================================================
# Skirting
# =========================================================

SKIRTING_GROUP = "skr_sh"
SKIRTING_FRONT = "skr_sh-ft"
SKIRTING_EDGEBAND = "skr_sh-eb"

# Typed in the Skirting panel; these are the starting values.
SKIRTING_HEIGHT_DEFAULT_MM = 100.0
SKIRTING_DEPTH_DEFAULT_MM = 18.0

SKIRTING_POSITIONS = [
    ("INSET", "Inset", "Inside the module: front face flush with the front edge, between the side panels"),
    ("INLINE", "Inline", "In front of the module's front-bottom edge, full width"),
]

# Side panels thinner than this count as side panels when Inset
# looks for their inner faces.
SKIRTING_SIDE_PANEL_MAX_MM = 60.0

# Used for Inset when no side panel is found at an edge.
SKIRTING_SIDE_PANEL_DEFAULT_MM = 18.0

# =========================================================
# Handles
# =========================================================

HANDLE_SUFFIX = "han"

# Custom property stamped on every placed handle so bounds
# calculations can skip it.
HANDLE_TAG = "mo2_handle"

HANDLE_EDGE_MARGIN_MM = 40.0

# Wardrobes, one shutter at a time: optional lock (assets/locks/Lock.fbx)
# under the handle, this much empty space between the handle's bottom
# and the lock's top. Add Handle to Selected never adds locks.
LOCK_SUFFIX = "lck"
LOCK_FILE = "Lock.fbx"
LOCK_GAP_MM = 35.0

HANDLE_LOCK_OPTIONS = [
    ("WITHOUT", "Without Lock", "Only the handle"),
    ("WITH", "With Lock", "A lock 35mm under each handle, named <module>_lck_NN"),
]

# Handles (both orientations): centre this far up the shutter
# (percent of its height, from the bottom) unless another value is typed.
HANDLE_HEIGHT_PERCENT_DEFAULT = 50.0

HANDLE_ORIENTATIONS = [
    ("HORIZONTAL", "Horizontal", "Handle lies flat, left to right (drawers)"),
    ("VERTICAL", "Vertical", "Handle stands upright, top to bottom (shutters)"),
]

HANDLE_SIDES = [
    ("LEFT", "Left", "40mm in from the shutter's left edge"),
    ("RIGHT", "Right", "40mm in from the shutter's right edge"),
]

# =========================================================
# UV Checker
# =========================================================

UNWRAP_BOX_SIZE = 1.03
CHECKER_MATERIAL_NAME = "Checker"

# =========================================================
# Collada Export
# =========================================================

COLLADA_EXPORT_SCALE = 1000.0
COLLADA_FORWARD_AXIS = '-Z'
COLLADA_UP_AXIS = 'Y'

bl_info = {
    "name": "Module Optimizer 2.0",
    "author": "Rohan Chopra",
    "version": (2, 0, 30),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Module Optimizer 2.0",
    "description": "Furniture module cleanup, EdgeBand generation, Carcass/Shutter "
    "naming conventions, handles, skirting, UV checker and Collada export.",
    "category": "Object",
}

import bpy

from bpy.props import PointerProperty

from .properties import MO2_Properties
from . import operators, ui, updates


classes = (MO2_Properties,) + operators.classes + ui.classes


def register():

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.mo2 = PointerProperty(type=MO2_Properties)

    updates.register()


def unregister():

    updates.unregister()

    del bpy.types.Scene.mo2

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

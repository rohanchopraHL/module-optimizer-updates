"""
Update messages - the team never has to check for updates.

Updates come from GitHub (REMOTE_INDEX_URL): when Blender starts, and
every few minutes while it runs, the add-on downloads index.json in a
background thread and, if a newer version is there, opens the What's
new popup (mo2.whats_new) with that version's notes and Update now.
Notes come from changelog.txt (bundled with the add-on, and published
next to index.json by build_zip.py).

Blenders first set up from the Google Drive folder (a file:// repo)
are switched to GitHub by themselves (switch_to_github), so Drive
sync no longer matters. A file:// repo that isn't the team one is
still read directly from disk.

Only active when installed as an extension and Blender has a window;
otherwise every function quietly does nothing.
"""

import functools
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request

import bpy

PACKAGE_ID = "module_optimizer_2"

REMOTE_INDEX_URL = "https://raw.githubusercontent.com/rohanchopraHL/module-optimizer-updates/main/test/index.json"

# Repository module the team installer creates.
TEAM_REPO_MODULE = "module_optimizer_team"

HERE = os.path.dirname(os.path.abspath(__file__))

CHECK_EVERY_SECONDS = 300
FIRST_CHECK_SECONDS = 5

# Versions already announced in this Blender session (Cancel means
# ask again next time Blender starts).
_asked = set()

# Last download from GitHub; written by the background thread.
_remote = {"url": None, "latest": None, "sections": [], "busy": False}

# check() started a download and should look at its result next.
_awaiting = [False]


# =========================================================
# Versions and Notes
# =========================================================

def version_key(version):

    return tuple(int(n) for n in re.findall(r"\d+", version or "0"))


@functools.lru_cache(maxsize=1)
def installed_version():
    """Read once - an update reloads this module."""

    return _manifest_version(os.path.join(HERE, "blender_manifest.toml")) or "0"


def _manifest_version(path):

    try:
        with open(path, encoding="utf-8") as handle:
            return re.search(r'^version = "([^"]+)"', handle.read(), re.M).group(1)
    except (OSError, AttributeError):
        return None


def parse_changelog(text):
    """[(version, [note, ...]), ...] as written, newest first."""

    sections = []

    for line in text.splitlines():

        line = line.strip()

        if not line or line.startswith("#"):
            continue

        if re.fullmatch(r"\d+\.\d+\.\d+|next", line, re.I):
            sections.append((line, []))
        elif sections:
            sections[-1][1].append(line.lstrip("-* ").strip())

    return sections


def read_changelog(path):

    try:
        with open(path, encoding="utf-8") as handle:
            return parse_changelog(handle.read())
    except OSError:
        return []


def notes_between(sections, after, up_to):
    """Sections newer than `after`, up to and including `up_to`."""

    return [
        (version, notes) for version, notes in sections
        if version_key(after) < version_key(version) <= version_key(up_to)
    ]


def bundled_changelog():

    return read_changelog(os.path.join(HERE, "changelog.txt"))


def _version_in_index(data):

    for item in data.get("data", []):
        if item.get("id") == PACKAGE_ID:
            return item.get("version")

    return None


# =========================================================
# The Repository This Add-on Came From
# =========================================================

def own_repo():
    """(index, repo) of the extensions repository holding this add-on, or (None, None)."""

    parts = (__package__ or "").split(".")

    if len(parts) < 3 or parts[0] != "bl_ext":
        return None, None

    for index, repo in enumerate(bpy.context.preferences.extensions.repos):
        if repo.module == parts[1]:
            return index, repo

    return None, None


def is_remote(url):

    return (url or "").startswith(("https://", "http://"))


def repo_folder(repo):
    """Local folder of a file:// repository, else None."""

    url = repo.remote_url if repo is not None else ""

    if not url.startswith("file:"):
        return None

    path = urllib.parse.unquote(urllib.parse.urlparse(url).path)

    # file:///G:/My Drive/... -> /G:/My Drive/...
    if re.match(r"^/[A-Za-z]:", path):
        path = path[1:]

    return os.path.dirname(os.path.normpath(path))


def available_version(folder):
    """Version of this add-on listed in the folder's index.json, or None."""

    try:
        with open(os.path.join(folder, "index.json"), encoding="utf-8") as handle:
            return _version_in_index(json.load(handle))
    except (OSError, ValueError):
        return None


# =========================================================
# GitHub
# =========================================================

def _download(url, timeout=15):
    """Text at url, past any cache (GitHub caches raw files for minutes)."""

    separator = "&" if "?" in url else "?"

    request = urllib.request.Request(
        f"{url}{separator}t={int(time.time())}",
        headers={"User-Agent": "Module-Optimizer", "Cache-Control": "no-cache"},
    )

    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read().decode("utf-8")


def _fetch(index_url):
    """Background thread: newest version and notes from GitHub. No bpy here."""

    latest, sections = None, []

    try:
        latest = _version_in_index(json.loads(_download(index_url)))

        try:
            sections = parse_changelog(_download(index_url.rsplit("/", 1)[0] + "/changelog.txt"))
        except Exception:
            pass

    except Exception as error:
        print(f"Module Optimizer update check: couldn't reach GitHub ({error})")

    _remote.update(url=index_url, latest=latest, sections=sections, busy=False)


def refresh_remote():
    """Start a background download if this add-on comes from GitHub; True if started."""

    _index, repo = own_repo()

    if repo is None or not is_remote(repo.remote_url) or _remote["busy"]:
        return False

    if not getattr(bpy.app, "online_access", True):
        return False

    _remote["busy"] = True
    threading.Thread(target=_fetch, args=(repo.remote_url,), daemon=True).start()

    return True


def switch_to_github():
    """Point a team Blender still reading the Drive folder at GitHub; True if switched."""

    _index, repo = own_repo()

    if repo is None or repo.module != TEAM_REPO_MODULE or not repo.remote_url.startswith("file:"):
        return False

    if not getattr(bpy.app, "online_access", True):
        return False  # keep the Drive folder - Blender may not go online

    repo.remote_url = REMOTE_INDEX_URL
    repo.use_sync_on_startup = True

    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        pass

    print("Module Optimizer: updates now come from GitHub.")

    return True


# =========================================================
# Update Check and Install
# =========================================================

def update_info():
    """(new_version, [(version, notes), ...]) if a newer version is ready, else None."""

    _index, repo = own_repo()

    if repo is None:
        return None

    current = installed_version()

    if is_remote(repo.remote_url):

        if _remote["url"] != repo.remote_url:
            return None

        latest, sections = _remote["latest"], _remote["sections"]

    else:

        folder = repo_folder(repo)

        if not folder:
            return None

        latest = available_version(folder)
        sections = read_changelog(os.path.join(folder, "changelog.txt"))

    if not latest or version_key(latest) <= version_key(current):
        return None

    return latest, notes_between(sections, current, latest)


def install_update(version):
    """Sync this add-on's repository and install `version`; raises if it didn't arrive."""

    index, repo = own_repo()

    if index is None:
        raise RuntimeError("Module Optimizer isn't installed from the team repository.")

    directory = repo.directory

    bpy.ops.extensions.repo_sync(repo_index=index)
    bpy.ops.extensions.package_install(repo_index=index, pkg_id=PACKAGE_ID, enable_on_install=True)

    installed = _manifest_version(os.path.join(directory, PACKAGE_ID, "blender_manifest.toml"))

    if version_key(installed) < version_key(version):
        raise RuntimeError(
            f"GitHub is still publishing {version} - try again in a few minutes"
        )


# =========================================================
# Timer
# =========================================================

def _show_whats_new():
    """Open the What's new popup in the first window; False if none."""

    window_manager = bpy.context.window_manager

    if window_manager is None or not window_manager.windows:
        return False

    window = window_manager.windows[0]

    with bpy.context.temp_override(window=window, screen=window.screen):
        bpy.ops.mo2.whats_new('INVOKE_DEFAULT')

    return True


def check():
    """
    Timer: start a GitHub download, look at it a few seconds later, and
    open What's new (with Update now) when a newer version is ready.
    """

    try:

        if _remote["busy"]:
            return 5

        if not _awaiting[0]:

            switch_to_github()

            if refresh_remote():
                _awaiting[0] = True
                return 5

        _awaiting[0] = False

        info = update_info()

        if info and info[0] not in _asked:
            if _show_whats_new():
                _asked.add(info[0])

    except Exception as error:  # never let a timer error spam the console
        print(f"Module Optimizer update check: {error}")

    return CHECK_EVERY_SECONDS


def register():

    if bpy.app.background:
        return

    if not bpy.app.timers.is_registered(check):
        bpy.app.timers.register(check, first_interval=FIRST_CHECK_SECONDS, persistent=True)


def unregister():

    if bpy.app.timers.is_registered(check):
        bpy.app.timers.unregister(check)

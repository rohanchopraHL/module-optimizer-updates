"""
Module Optimizer 2.0 - constants.

Every name, size and tolerance the add-on uses lives here.
"""

# =========================================================
# Geometry
# =========================================================

ZERO_TOLERANCE = 0.001

# A face whose smallest non-zero side (in mm) falls in this
# range is an edge strip (EdgeBand), anything wider is a
# surface (Front / Back).
EDGE_MIN_MM = 5.0
EDGE_MAX_MM = 25.0

# Largest bounding-box side below this reads as metres,
# at or above it as millimetres.
METER_THRESHOLD = 10.0

# =========================================================
# Raw Import Naming
# =========================================================

NAME_SEPARATOR = "_"

PART_PREFIX = "Part"
FACE_PREFIX = "Face"

FRONT_NAME = "Front"
BACK_NAME = "Back"
EDGEBAND_NAME = "EdgeBand"

OSL = "OSL"
BSL = "BSL"

# =========================================================
# Carcass Naming
# =========================================================

CARCASS_GROUP = "car"
CARCASS_INTERNAL = "car-in"

VISIBLE_SIDE_GROUP = "car_vs"
VISIBLE_SIDE_LEFT = "car_vs-l"
VISIBLE_SIDE_RIGHT = "car_vs-r"
VISIBLE_TOP = "car_vs-t"
VISIBLE_BOTTOM = "car_vs-b"

SIDE_PANEL_GROUP = "car_sd"
SIDE_PANEL = "sd-pnl"

REMOVABLE_SHELF = "var-shlf"
FIXED_SHELF = "fxd-shlf"

TOP_PANEL_FACE = "tp-pnl"
BACK_PANEL_FACE = "bk-pnl"
BOTTOM_PANEL_FACE = "bt-pnl"

# =========================================================
# Counter Top Naming
# =========================================================

COUNTERTOP_GROUP = "c-top_sh"
COUNTERTOP_FRONT = "c-top_sh-ft"
COUNTERTOP_EDGEBAND = "c-top_sh-eb"
COUNTERTOP_COMBINED = "c-top"

# =========================================================
# Shutter Naming
# =========================================================

SHUTTER_GROUP = "sh"
SHUTTER_FRONT = "sh-ft"
SHUTTER_BACK = "sh-bk"
SHUTTER_EDGEBAND = "sh-eb"

# =========================================================
# Top Panel (auto-built when the module has none)
# =========================================================

TOP_PANEL_HEIGHT_MM = 18.0

# The highest Part only counts as the top panel if it spans
# at least this fraction of the module's width.
TOP_PANEL_MIN_WIDTH_RATIO = 0.6

# =========================================================
# Skirting
# =========================================================

SKIRTING_GROUP = "skr_sh"
SKIRTING_FRONT = "skr_sh-ft"
SKIRTING_EDGEBAND = "skr_sh-eb"

SKIRTING_HEIGHTS = [
    ("100", "100mm", ""),
    ("110", "110mm", ""),
]

SKIRTING_DEPTHS = [
    ("18", "18mm", ""),
    ("20", "20mm", ""),
]

SKIRTING_POSITIONS = [
    ("INSET", "Inset", "Inside the module: front face flush with the front edge, between the side panels"),
    ("INLINE", "Inline", "In front of the module's front-bottom edge, full width"),
]

# Side panels thinner than this count as side panels when Inset
# looks for their inner faces.
SKIRTING_SIDE_PANEL_MAX_MM = 60.0

# Used for Inset when no side panel is found at an edge.
SKIRTING_SIDE_PANEL_DEFAULT_MM = 18.0

# =========================================================
# Handles
# =========================================================

HANDLE_SUFFIX = "han"

# Custom property stamped on every placed handle so bounds
# calculations can skip it.
HANDLE_TAG = "mo2_handle"

HANDLE_EDGE_MARGIN_MM = 40.0
HANDLE_VERTICAL_Z_MM = 152.553
HANDLE_HORIZONTAL_Z_OFFSET_MM = 100.0

HANDLE_ORIENTATIONS = [
    ("HORIZONTAL", "Horizontal", "Handle lies flat, left to right (drawers)"),
    ("VERTICAL", "Vertical", "Handle stands upright, top to bottom (shutters)"),
]

HANDLE_VERTICAL_POSITIONS = [
    ("TOP_LEFT", "Top Left", ""),
    ("TOP_RIGHT", "Top Right", ""),
    ("BOTTOM_LEFT", "Bottom Left", ""),
    ("BOTTOM_RIGHT", "Bottom Right", ""),
]

HANDLE_HORIZONTAL_POSITIONS = [
    ("TOP", "Top", ""),
    ("CENTER", "Center", ""),
    ("BOTTOM", "Bottom", ""),
]

# =========================================================
# UV Checker
# =========================================================

UNWRAP_BOX_SIZE = 1.03
CHECKER_MATERIAL_NAME = "Checker"

# =========================================================
# Collada Export
# =========================================================

COLLADA_EXPORT_SCALE = 1000.0
COLLADA_FORWARD_AXIS = '-Z'
COLLADA_UP_AXIS = 'Y'

"""Scene settings, stored on bpy.types.Scene.mo2."""

import bpy

from bpy.props import (
    StringProperty,
    EnumProperty,
    FloatProperty,
    PointerProperty,
    BoolProperty,
)

from .config import (
    HANDLE_ORIENTATIONS,
    HANDLE_SIDES,
    HANDLE_HEIGHT_PERCENT_DEFAULT,
    HANDLE_HORIZONTAL_POSITIONS,
    SKIRTING_HEIGHTS,
    SKIRTING_DEPTHS,
    SKIRTING_POSITIONS,
)

from .core.handles import handle_enum_items


class MO2_Properties(bpy.types.PropertyGroup):

    # Name every convention uses - set by Apply Module Name, or
    # taken from the module root when blank.
    module_name: StringProperty(name="Module Name", default="")

    # Step 2's text box; cleared after Apply.
    module_name_input: StringProperty(
        name="Module Name",
        default="",
        description="New name for the module root and everything named after it",
    )

    # Handle Library

    handles_expanded: BoolProperty(default=False)

    handle_asset: EnumProperty(name="Handle", items=handle_enum_items)

    handle_orientation: EnumProperty(
        name="Orientation",
        items=HANDLE_ORIENTATIONS,
        default="HORIZONTAL",
    )

    handle_side: EnumProperty(
        name="Side",
        items=HANDLE_SIDES,
        default="LEFT",
    )

    handle_height_percent: FloatProperty(
        name="Height Position",
        description="Handle centre, as a percentage of the shutter's height measured from its bottom edge",
        default=HANDLE_HEIGHT_PERCENT_DEFAULT,
        min=0.0,
        max=100.0,
        precision=0,
        subtype='PERCENTAGE',
    )

    handle_horizontal_position: EnumProperty(
        name="Position",
        items=HANDLE_HORIZONTAL_POSITIONS,
        default="CENTER",
    )

    handle_target: PointerProperty(name="Place On", type=bpy.types.Object)

    # Skirting

    skirting_expanded: BoolProperty(default=False)

    skirting_height: EnumProperty(
        name="Height",
        items=SKIRTING_HEIGHTS,
        default="100",
    )

    skirting_depth: EnumProperty(
        name="Depth",
        items=SKIRTING_DEPTHS,
        default="18",
    )

    skirting_position: EnumProperty(
        name="Position",
        items=SKIRTING_POSITIONS,
        default="INLINE",
    )

"""Scene settings, stored on bpy.types.Scene.mo2."""

import bpy

from bpy.props import (
    StringProperty,
    EnumProperty,
    PointerProperty,
    BoolProperty,
)

from .config import (
    HANDLE_ORIENTATIONS,
    HANDLE_VERTICAL_POSITIONS,
    HANDLE_HORIZONTAL_POSITIONS,
    SKIRTING_HEIGHTS,
)

from .core.handles import handle_enum_items


class MO2_Properties(bpy.types.PropertyGroup):

    # Name every convention uses - set by Apply Module Name, or
    # taken from the module root when blank.
    module_name: StringProperty(name="Module Name", default="")

    # Step 2's text box; cleared after Apply.
    module_name_input: StringProperty(
        name="Module Name",
        default="",
        description="New name for the module root and everything named after it",
    )

    # Handle Library

    handles_expanded: BoolProperty(default=False)

    handle_asset: EnumProperty(name="Handle", items=handle_enum_items)

    handle_orientation: EnumProperty(
        name="Orientation",
        items=HANDLE_ORIENTATIONS,
        default="HORIZONTAL",
    )

    handle_vertical_position: EnumProperty(
        name="Position",
        items=HANDLE_VERTICAL_POSITIONS,
        default="TOP_LEFT",
    )

    handle_horizontal_position: EnumProperty(
        name="Position",
        items=HANDLE_HORIZONTAL_POSITIONS,
        default="CENTER",
    )

    handle_target: PointerProperty(name="Place On", type=bpy.types.Object)

    # Skirting

    skirting_expanded: BoolProperty(default=False)

    skirting_height: EnumProperty(
        name="Height",
        items=SKIRTING_HEIGHTS,
        default="100",
    )

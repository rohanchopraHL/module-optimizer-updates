"""
UV Checker: box-map every mesh in the module (same projection
Magic UV's Box Map gives at Size 1.03 with default settings)
and assign the bundled Checker material.
"""

import os

import bmesh
import bpy

from ..config import UNWRAP_BOX_SIZE, CHECKER_MATERIAL_NAME

from .common import MOError, require_root, module_meshes


CHECKER_IMAGE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets",
    "textures",
    "checker.jpg",
)


def box_map(mesh, size=UNWRAP_BOX_SIZE):
    """Project each face onto the box side its normal points at."""

    scale = 1.0 / size

    bm = bmesh.new()
    bm.from_mesh(mesh)

    uv_layer = bm.loops.layers.uv.verify()

    for face in bm.faces:

        n = face.normal
        ax, ay, az = abs(n.x), abs(n.y), abs(n.z)

        for loop in face.loops:

            x, y, z = (c * scale for c in loop.vert.co)

            if ax >= ay and ax >= az:
                uv = (y, z) if n.x >= 0.0 else (-y, z)
            elif ay >= ax and ay >= az:
                uv = (-x, z) if n.y >= 0.0 else (x, z)
            else:
                uv = (x, y) if n.z >= 0.0 else (-x, y)

            loop[uv_layer].uv = uv

    bm.to_mesh(mesh)
    bm.free()

    mesh.update()


def checker_material():

    material = bpy.data.materials.get(CHECKER_MATERIAL_NAME)

    if material is not None:

        # A .blend saved with an older add-on keeps the old picture until reloaded.
        for node in material.node_tree.nodes if material.node_tree else ():
            image = getattr(node, "image", None)
            if image is not None and os.path.normcase(bpy.path.abspath(image.filepath)) == os.path.normcase(CHECKER_IMAGE):
                image.reload()

        return material

    if not os.path.isfile(CHECKER_IMAGE):
        return None

    material = bpy.data.materials.new(CHECKER_MATERIAL_NAME)
    material.use_nodes = True

    nodes = material.node_tree.nodes

    image_node = nodes.new("ShaderNodeTexImage")
    image_node.image = bpy.data.images.load(CHECKER_IMAGE, check_existing=True)
    image_node.location = (-300, 300)

    bsdf = nodes.get("Principled BSDF")

    if bsdf is not None:
        material.node_tree.links.new(image_node.outputs["Color"], bsdf.inputs["Base Color"])

    return material


def unwrap_module(context):

    root = require_root(context)

    meshes = module_meshes(root)

    if not meshes:
        raise MOError("No mesh objects found in the module.")

    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    for mesh in {obj.data for obj in meshes}:
        box_map(mesh)

    material = checker_material()

    if material is None:
        raise MOError(
            f"{len(meshes)} mesh(es) unwrapped, but the Checker texture "
            "is missing from the add-on's assets."
        )

    for obj in meshes:
        obj.data.materials.clear()
        obj.data.materials.append(material)

    return f"{len(meshes)} mesh(es) unwrapped and given the Checker material."

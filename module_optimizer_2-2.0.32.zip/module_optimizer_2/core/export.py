"""
Collada export at mm scale (root temporarily scaled x1000),
Forward -Z / Up Y, followed by saving the .blend next to the
.dae under the same name.

Uses Blender's own Collada exporter when it exists; Blender 5.0
dropped it, so a pure-Python writer (positions, normals, UVs,
triangles, base-colour / image materials) covers that case.
"""

import datetime
import math
import os

from xml.dom import minidom
from xml.etree import ElementTree as ET

import bpy

from mathutils import Matrix

from ..config import (
    COLLADA_EXPORT_SCALE,
    COLLADA_FORWARD_AXIS,
    COLLADA_UP_AXIS,
)

from .common import MOError, require_root
from .cleanup import select_module


# =========================================================
# Native Exporter
# =========================================================

def _export_native(filepath):
    """True on success, False when this Blender has no Collada."""

    try:
        result = bpy.ops.wm.collada_export(
            filepath=filepath,
            selected=True,
            include_children=False,
            include_armatures=False,
            include_shapekeys=False,
            apply_global_orientation=True,
            export_global_forward_selection=COLLADA_FORWARD_AXIS,
            export_global_up_selection=COLLADA_UP_AXIS,
            use_texture_copies=False,
            active_uv_only=False,
            include_animations=False,
        )
    except AttributeError:
        return False

    if 'FINISHED' not in result:
        raise MOError("Blender's Collada exporter did not finish.")

    return True


# =========================================================
# Fallback Writer
# =========================================================

def _safe_id(name, used):

    out = "".join(c if (c.isalnum() or c == "_") else "_" for c in name)

    if not out or out[0].isdigit():
        out = "_" + out

    base = out
    i = 1

    while out in used:
        out = f"{base}_{i}"
        i += 1

    used.add(out)

    return out


def _floats(values):

    return " ".join(f"{v:.6f}" for v in values)


def _sub(parent, tag, text=None, **attrib):

    el = ET.SubElement(parent, tag, {k: str(v) for k, v in attrib.items()})

    if text is not None:
        el.text = text

    return el


def _source(mesh_el, src_id, values, count, params):

    src = _sub(mesh_el, "source", id=src_id)

    _sub(src, "float_array", _floats(values), id=src_id + "-array", count=len(values))

    accessor = _sub(
        _sub(src, "technique_common"),
        "accessor",
        source=f"#{src_id}-array",
        count=count,
        stride=len(params),
    )

    for param in params:
        _sub(accessor, "param", name=param, type="float")


def _base_color(material):
    """(rgba, image or None) from the Principled BSDF."""

    rgba = (0.8, 0.8, 0.8, 1.0)

    if not material.use_nodes:
        return (*material.diffuse_color[:3], 1.0), None

    for node in material.node_tree.nodes:

        if node.type != 'BSDF_PRINCIPLED':
            continue

        socket = node.inputs.get("Base Color")

        if socket is None:
            break

        if socket.is_linked:
            source = socket.links[0].from_node
            if source.type == 'TEX_IMAGE' and source.image:
                return rgba, source.image
            break

        return tuple(socket.default_value), None

    return rgba, None


class DaeWriter:

    def __init__(self, context, filepath):

        self.context = context
        self.filepath = filepath
        self.used = set()
        self.geometry_ids = {}
        self.material_ids = {}
        self.symbols = {}
        self.depsgraph = context.evaluated_depsgraph_get()
        self.conversion = Matrix.Rotation(-math.pi / 2.0, 4, 'X')

    def _geometry(self, library, obj):

        mesh_data = obj.data
        geom_id = _safe_id("geom_" + mesh_data.name, self.used)
        self.geometry_ids[mesh_data] = geom_id

        evaluated = obj.evaluated_get(self.depsgraph)
        mesh = evaluated.to_mesh()
        mesh.calc_loop_triangles()

        geometry_el = _sub(library, "geometry", id=geom_id, name=mesh_data.name)
        mesh_el = _sub(geometry_el, "mesh")

        positions = [c for v in mesh.vertices for c in v.co]
        normals = [c for v in mesh.vertices for c in v.normal]

        _source(mesh_el, geom_id + "-positions", positions, len(mesh.vertices), "XYZ")
        _source(mesh_el, geom_id + "-normals", normals, len(mesh.vertices), "XYZ")

        has_uv = len(mesh.uv_layers) > 0

        if has_uv:
            uv_data = mesh.uv_layers.active.data
            uvs = [c for loop in uv_data for c in loop.uv]
            _source(mesh_el, geom_id + "-uv", uvs, len(mesh.loops), "ST")

        vertices_el = _sub(mesh_el, "vertices", id=geom_id + "-vertices")
        _sub(vertices_el, "input", semantic="POSITION", source=f"#{geom_id}-positions")
        _sub(vertices_el, "input", semantic="NORMAL", source=f"#{geom_id}-normals")

        slots = max(1, len(mesh.materials))
        by_slot = {i: [] for i in range(slots)}

        for tri in mesh.loop_triangles:
            by_slot[tri.material_index if tri.material_index < slots else 0].append(tri)

        symbols = {}

        for slot, tris in by_slot.items():

            if not tris:
                continue

            material = mesh.materials[slot] if slot < len(mesh.materials) else None

            symbol = _safe_id("sym_" + (material.name if material else "default"), set())
            symbol = f"{symbol}_{slot}"
            symbols[slot] = (symbol, material)

            tri_el = _sub(mesh_el, "triangles", count=len(tris), material=symbol)
            _sub(tri_el, "input", semantic="VERTEX", source=f"#{geom_id}-vertices", offset=0)

            if has_uv:
                _sub(tri_el, "input", semantic="TEXCOORD", source=f"#{geom_id}-uv", offset=1, set=0)

            indices = []

            for tri in tris:
                for loop_index in tri.loops:
                    indices.append(mesh.loops[loop_index].vertex_index)
                    if has_uv:
                        indices.append(loop_index)

            _sub(tri_el, "p", " ".join(map(str, indices)))

        self.symbols[mesh_data] = symbols

        evaluated.to_mesh_clear()

    def _materials(self, root, images, effects, materials):

        used = {
            material
            for mesh_data in self.geometry_ids
            for material in mesh_data.materials
            if material
        }

        for material in used:

            mat_id = _safe_id("mat_" + material.name, self.used)
            self.material_ids[material] = mat_id

            rgba, image = _base_color(material)

            profile = _sub(_sub(effects, "effect", id=mat_id + "-effect"), "profile_COMMON")

            if image is not None:

                img_id = _safe_id("img_" + image.name, self.used)
                path = bpy.path.abspath(image.filepath) if image.filepath else image.name

                image_el = _sub(images, "image", id=img_id, name=img_id)
                _sub(image_el, "init_from", path.replace("\\", "/"))

                surface = _sub(_sub(profile, "newparam", sid=mat_id + "-surface"), "surface", type="2D")
                _sub(surface, "init_from", img_id)

                sampler = _sub(_sub(profile, "newparam", sid=mat_id + "-sampler"), "sampler2D")
                _sub(sampler, "source", mat_id + "-surface")

            phong = _sub(_sub(profile, "technique", sid="common"), "phong")

            diffuse = _sub(phong, "diffuse")

            if image is not None:
                _sub(diffuse, "texture", texture=mat_id + "-sampler", texcoord="UVMap")
            else:
                _sub(diffuse, "color", _floats(rgba))

            _sub(_sub(phong, "specular"), "color", _floats((0.2, 0.2, 0.2, 1.0)))
            _sub(_sub(phong, "shininess"), "float", "20.0")

            material_el = _sub(materials, "material", id=mat_id, name=material.name)
            _sub(material_el, "instance_effect", url=f"#{mat_id}-effect")

        if len(images) == 0:
            root.remove(images)

    def _scene(self, root, objects):
        """Only root nodes get the Z-up -> Y-up rotation."""

        scene_el = _sub(_sub(root, "library_visual_scenes"), "visual_scene", id="Scene", name="Scene")

        exported = set(objects)
        nodes = {}

        for obj in objects:

            matrix = obj.matrix_local

            if obj.parent not in exported:
                matrix = self.conversion @ matrix

            node = ET.Element("node", {
                "id": _safe_id("node_" + obj.name, self.used),
                "name": obj.name,
                "type": "NODE",
            })

            _sub(node, "matrix", _floats([v for row in matrix for v in row]), sid="transform")

            geom_id = self.geometry_ids.get(obj.data) if obj.type == 'MESH' else None

            if geom_id:

                instance = _sub(node, "instance_geometry", url="#" + geom_id)
                symbols = self.symbols.get(obj.data, {})
                bound = [(s, self.material_ids.get(m)) for s, m in symbols.values()]
                bound = [(s, m) for s, m in bound if m]

                if bound:
                    technique = _sub(_sub(instance, "bind_material"), "technique_common")
                    for symbol, mat_id in bound:
                        inst = _sub(technique, "instance_material", symbol=symbol, target="#" + mat_id)
                        _sub(inst, "bind_vertex_input", semantic="UVMap",
                             input_semantic="TEXCOORD", input_set=0)

            nodes[obj] = node

        for obj in objects:

            if obj.parent in nodes:
                nodes[obj.parent].append(nodes[obj])
            else:
                scene_el.append(nodes[obj])

    def write(self):

        objects = [o for o in self.context.selected_objects if o.type in ('MESH', 'EMPTY')]

        if not objects:
            raise MOError("Nothing selected to export.")

        root = ET.Element("COLLADA", {
            "xmlns": "http://www.collada.org/2005/11/COLLADASchema",
            "version": "1.4.1",
        })

        asset = _sub(root, "asset")
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        _sub(asset, "created", now)
        _sub(asset, "modified", now)
        _sub(asset, "unit", name="meter", meter="1")
        _sub(asset, "up_axis", "Y_UP")

        images = _sub(root, "library_images")
        effects = _sub(root, "library_effects")
        materials = _sub(root, "library_materials")
        geometries = _sub(root, "library_geometries")

        for obj in objects:
            if obj.type == 'MESH' and obj.data not in self.geometry_ids:
                self._geometry(geometries, obj)

        self._materials(root, images, effects, materials)
        self._scene(root, objects)

        _sub(_sub(root, "scene"), "instance_visual_scene", url="#Scene")

        pretty = minidom.parseString(ET.tostring(root, encoding="unicode")).toprettyxml(indent="  ")

        with open(self.filepath, "w", encoding="utf-8") as handle:
            handle.write("\n".join(line for line in pretty.split("\n") if line.strip()))


# =========================================================
# Export
# =========================================================

def export_module(context, filepath, save_blend=True):

    root = require_root(context)

    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    select_module(context, root)

    original_scale = tuple(root.scale)

    root.scale = (COLLADA_EXPORT_SCALE,) * 3
    context.view_layer.update()

    try:
        used_fallback = not _export_native(filepath)

        if used_fallback:
            DaeWriter(context, filepath).write()

    finally:
        root.scale = original_scale
        context.view_layer.update()

    message = f"Exported '{filepath}'."

    if used_fallback:
        message += " (built-in writer - this Blender has no Collada exporter)"

    if save_blend:

        blend_path = os.path.splitext(filepath)[0] + ".blend"

        bpy.ops.wm.save_as_mainfile(filepath=blend_path)

        message += f" Saved '{os.path.basename(blend_path)}'."

    return message

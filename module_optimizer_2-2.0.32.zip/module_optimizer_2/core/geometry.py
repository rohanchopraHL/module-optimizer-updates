"""
Panel geometry: classify faces as surface or edge strip, tell
Front (outward) from Back (inward), split joined panels back
into faces, and build new box panels from scratch.
"""

import bmesh
import bpy

from ..config import (
    ZERO_TOLERANCE,
    EDGE_MIN_MM,
    EDGE_MAX_MM,
    FRONT_NAME,
    BACK_NAME,
    EDGEBAND_NAME,
)

from .common import (
    MOError,
    is_meter_scale,
    join_objects,
    module_center,
    select_only,
    ensure_object_mode,
)


# =========================================================
# Surface / Edge Classification
# =========================================================

def dimensions_mm(obj):

    dims = list(obj.dimensions)

    if is_meter_scale(dims):
        return [d * 1000.0 for d in dims]

    return dims


def small_dimension_mm(obj):
    """Smaller of the two non-zero sides of a flat face, in mm."""

    dims = sorted(d for d in dimensions_mm(obj) if d > ZERO_TOLERANCE)

    if len(dims) < 2:
        return 0.0

    return dims[0]


def is_edge_face(obj):

    return EDGE_MIN_MM <= small_dimension_mm(obj) <= EDGE_MAX_MM


def classify_pieces(pieces):
    """Split face objects into (surfaces, edges)."""

    surfaces = []
    edges = []

    for obj in pieces:

        if obj.type != 'MESH' or not obj.data.polygons:
            continue

        if is_edge_face(obj):
            edges.append(obj)
        else:
            surfaces.append(obj)

    return surfaces, edges


# =========================================================
# Front / Back
# =========================================================

def face_center(obj):

    polygons = obj.data.polygons

    if not polygons:
        return None

    return obj.matrix_world @ polygons[0].center


def face_normal(obj):

    polygons = obj.data.polygons

    if not polygons:
        return None

    normal_matrix = obj.matrix_world.to_3x3().inverted_safe().transposed()

    normal = normal_matrix @ polygons[0].normal
    normal.normalize()

    return normal


def outwardness(obj, center):
    """How far the face points away from center (>= 0 means outward)."""

    position = face_center(obj)
    normal = face_normal(obj)

    if position is None or normal is None:
        return None

    return (position - center).dot(normal)


def orientation(obj, center):
    """FRONT_NAME if the face points away from center, else BACK_NAME."""

    score = outwardness(obj, center)

    if score is None:
        return None

    return FRONT_NAME if score >= 0 else BACK_NAME


def split_front_back(surfaces, center):
    """(fronts, backs) - any number of faces either way."""

    fronts = []
    backs = []

    for face in surfaces:

        if orientation(face, center) == FRONT_NAME:
            fronts.append(face)
        else:
            backs.append(face)

    return fronts, backs


def pick_front_back(surfaces, center):
    """
    Exactly 2 surfaces -> (front, back), else (None, None). The
    two faces are compared with each other, so a panel straddling
    the module centre (e.g. a mid-height shelf) still gets one
    Front and one Back.
    """

    if len(surfaces) != 2:
        return None, None

    a, b = surfaces

    score_a = outwardness(a, center)
    score_b = outwardness(b, center)

    if score_a is None or score_b is None:
        return None, None

    return (a, b) if score_a >= score_b else (b, a)


# =========================================================
# Raw Part Children
# =========================================================

def part_faces(part):
    """First Front / Back / EdgeBand child of a group, by name."""

    front = back = edgeband = None

    for child in part.children:

        if front is None and child.name.startswith(FRONT_NAME):
            front = child
        elif back is None and child.name.startswith(BACK_NAME):
            back = child
        elif edgeband is None and child.name.startswith(EDGEBAND_NAME):
            edgeband = child

    return front, back, edgeband


def all_part_faces(part):
    """Every Front / Back / EdgeBand child of a group."""

    prefixes = (FRONT_NAME, BACK_NAME, EDGEBAND_NAME)

    return [child for child in part.children if child.name.startswith(prefixes)]


# =========================================================
# Splitting Joined Panels
# =========================================================

def _is_flat(obj):

    return any(d <= ZERO_TOLERANCE for d in obj.dimensions)


def _separate(context, obj, splitter):

    ensure_object_mode(context)

    select_only(context, [obj])

    before = set(bpy.data.objects)

    bpy.ops.object.mode_set(mode='EDIT')

    splitter(obj)

    bpy.ops.object.mode_set(mode='OBJECT')

    return [obj] + [o for o in bpy.data.objects if o not in before]


def _split_loose(obj):

    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.separate(type='LOOSE')


def _split_planes(obj):
    """One piece per flat plane (normal + offset), for welded boxes."""

    while True:

        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()

        planes = {}

        for face in bm.faces:

            key = (
                tuple(round(c, 4) for c in face.normal),
                round(face.normal.dot(face.calc_center_median()), 4),
            )

            planes.setdefault(key, []).append(face.index)

        if len(planes) <= 1:
            return

        bpy.ops.mesh.select_all(action='DESELECT')

        for index in next(iter(planes.values())):
            bm.faces[index].select = True

        bmesh.update_edit_mesh(obj.data)

        bpy.ops.mesh.separate(type='SELECTED')


def split_object(context, obj):
    """
    Break one mesh into flat face pieces: loose islands first,
    and if it is one welded solid, one piece per plane.
    """

    pieces = _separate(context, obj, _split_loose)

    if len(pieces) > 1 or _is_flat(obj):
        return pieces

    return _separate(context, obj, _split_planes)


def split_objects(context, objects):

    pieces = []

    for obj in objects:

        if obj.type == 'MESH':
            pieces.extend(split_object(context, obj))

    return pieces


# =========================================================
# Resolve A Panel From Any Geometry
# =========================================================

def resolve_panel(context, objects, root):
    """
    Front / Back / EdgeBand from any selection - a joined panel,
    a welded box, or already-separate faces. Front faces away
    from the module centre. Raises MOError if it isn't exactly
    one panel (2 surfaces).
    """

    pieces = split_objects(context, objects)

    if not pieces:
        raise MOError(
            "No mesh objects selected. Select a panel or its faces."
        )

    surfaces, edges = classify_pieces(pieces)

    if len(surfaces) != 2:
        raise MOError(
            f"Expected 2 surface faces, found {len(surfaces)}. Select "
            "one full panel (2 surfaces + edges) or its faces."
        )

    center = module_center(root)

    if center is None:
        raise MOError("Module has no mesh geometry.")

    front, back = pick_front_back(surfaces, center)

    if front is None:
        raise MOError("Could not tell Front from Back.")

    return front, back, join_objects(context, edges)


def reclassify(context, objects, root):
    """
    Like resolve_panel() but tolerant: any number of faces per
    role, each role joined into one object. Used to switch a
    panel that was already converted into a different shape.
    """

    center = module_center(root)

    surfaces, edges = classify_pieces(split_objects(context, objects))

    fronts, backs = split_front_back(surfaces, center)

    return (
        join_objects(context, fronts),
        join_objects(context, backs),
        join_objects(context, edges),
    )


# =========================================================
# Building New Boxes
# =========================================================

def make_quad(name, verts, collection):
    """One-face mesh object; vertex order sets the normal."""

    mesh = bpy.data.meshes.new(name)

    bm = bmesh.new()
    bm.faces.new([bm.verts.new(v) for v in verts])
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)

    return obj


def make_box_faces(prefix, x0, x1, y0, y1, z0, z1, collection):
    """
    Six outward-facing quads of an axis-aligned box, keyed
    '-X', '+X', '-Y', '+Y', '-Z', '+Z'.
    """

    quads = {
        "-X": [(x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0)],
        "+X": [(x1, y0, z0), (x1, y1, z0), (x1, y1, z1), (x1, y0, z1)],
        "-Y": [(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)],
        "+Y": [(x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0)],
        "-Z": [(x0, y0, z0), (x0, y1, z0), (x1, y1, z0), (x1, y0, z0)],
        "+Z": [(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)],
    }

    return {
        side: make_quad(f"{prefix}{side}", verts, collection)
        for side, verts in quads.items()
    }

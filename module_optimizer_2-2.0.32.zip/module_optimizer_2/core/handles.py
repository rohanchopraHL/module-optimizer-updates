"""
Handle Library: bundled .fbx handles (assets/handles - drop
more files in and they appear in the list), placed on a target
face and named '<module>_han_NN'.

Horizontal: centred in X, at the face's Top / Center / Bottom
(Top/Bottom inset 100mm). Vertical: rotated upright, near a
corner (40mm in from the side, 152.553mm in from top/bottom).
"""

import os

from math import radians

import bpy

from mathutils import Vector

from ..config import (
    HANDLE_SUFFIX,
    HANDLE_TAG,
    HANDLE_EDGE_MARGIN_MM,
    HANDLE_VERTICAL_Z_MM,
    HANDLE_HORIZONTAL_Z_OFFSET_MM,
)

from .common import (
    MOError,
    make_name,
    next_index,
    join_objects,
    parent_to,
    topmost,
    world_corners,
    mm_to_native,
    select_only,
    ensure_object_mode,
)


# =========================================================
# Library
# =========================================================

HANDLE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets",
    "handles",
)


def list_handles():

    if not os.path.isdir(HANDLE_DIR):
        return []

    return sorted(f for f in os.listdir(HANDLE_DIR) if f.lower().endswith(".fbx"))


# Blender needs dynamic enum strings kept alive.
_enum_cache = []


def handle_enum_items(self, context):

    global _enum_cache

    files = list_handles()

    if not files:
        _enum_cache = [("NONE", "No Handles Found", f"Add .fbx files to {HANDLE_DIR}")]
    else:
        _enum_cache = [("NONE", "Select", "Choose a handle")] + [
            (f, os.path.splitext(f)[0], os.path.join(HANDLE_DIR, f)) for f in files
        ]

    return _enum_cache


# =========================================================
# Placement
# =========================================================

def _target_frame(target):
    """(min_x, max_x, mid_y, min_z, max_z) of the target in world space."""

    corners = world_corners(target)

    xs = [c.x for c in corners]
    ys = [c.y for c in corners]
    zs = [c.z for c in corners]

    return min(xs), max(xs), sum(ys) / len(ys), min(zs), max(zs)


def placement_point(target, orientation, position):

    if target.type != 'MESH':
        return target.matrix_world.translation.copy()

    min_x, max_x, mid_y, min_z, max_z = _target_frame(target)

    dims = list(target.dimensions)

    if orientation == 'VERTICAL':

        margin_x = mm_to_native(dims, HANDLE_EDGE_MARGIN_MM)
        margin_z = mm_to_native(dims, HANDLE_VERTICAL_Z_MM)

        x = max_x - margin_x if position.endswith("RIGHT") else min_x + margin_x
        z = max_z - margin_z if position.startswith("TOP") else min_z + margin_z

        return Vector((x, mid_y, z))

    center_x = (min_x + max_x) / 2.0

    if position == 'CENTER':
        return Vector((center_x, mid_y, (min_z + max_z) / 2.0))

    offset = mm_to_native(dims, HANDLE_HORIZONTAL_Z_OFFSET_MM)

    z = max_z - offset if position == 'TOP' else min_z + offset

    return Vector((center_x, mid_y, z))


def _module_name_for(props, target):

    name = props.module_name.strip()

    if name:
        return name

    top = topmost(target)

    if top is not None and top is not target:
        return top.name

    return ""


# =========================================================
# Add Handle
# =========================================================

def add_handle(context, props):

    target = props.handle_target

    if target is None:
        raise MOError("Pick the face the handle goes on (Place On).")

    module = _module_name_for(props, target)

    if not module:
        raise MOError("Please enter a Module Name.")

    if props.handle_asset in ("", "NONE"):
        raise MOError("Please select a Handle.")

    filepath = os.path.join(HANDLE_DIR, props.handle_asset)

    if not os.path.isfile(filepath):
        raise MOError(f"Handle file not found: {filepath}")

    vertical = props.handle_orientation == 'VERTICAL'

    position = props.handle_vertical_position if vertical else props.handle_horizontal_position

    ensure_object_mode(context)

    before = set(bpy.data.objects)

    bpy.ops.import_scene.fbx(filepath=filepath)

    imported = [obj for obj in bpy.data.objects if obj not in before]

    if not imported:
        raise MOError("Handle import produced no objects.")

    roots = [obj for obj in imported if obj.parent not in imported]

    if len(roots) == 1:
        handle = roots[0]
    else:
        meshes = [obj for obj in imported if obj.type == 'MESH']
        handle = join_objects(context, meshes) if meshes else roots[0]

    if vertical:
        handle.rotation_mode = 'XYZ'
        handle.rotation_euler.y += radians(90)

    handle.location = placement_point(target, props.handle_orientation, position)

    module_root = topmost(target)

    parent_to(module_root if module_root.type == 'EMPTY' else target, [handle])

    handle.name = make_name(module, HANDLE_SUFFIX, next_index(module, HANDLE_SUFFIX))
    handle[HANDLE_TAG] = True

    select_only(context, [handle])

    props.handle_target = None
    props.handle_asset = "NONE"

    return f"Placed handle '{handle.name}'."

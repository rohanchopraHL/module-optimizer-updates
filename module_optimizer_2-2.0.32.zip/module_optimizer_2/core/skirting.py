"""
Skirting: a new toe-kick box spanning the module's full width
(LP to RP), 18mm deep, standing just in front of the side
panels' front-bottom edge, from the floor up to the chosen
height.

    <module>_skr_sh_NN      group (under the module root)
    <module>_skr_sh-ft_NN   Front + Back joined
    <module>_skr_sh-eb_NN   the 4 edge faces joined
"""

import bpy

from ..config import (
    SKIRTING_GROUP,
    SKIRTING_FRONT,
    SKIRTING_EDGEBAND,
    SKIRTING_DEPTH_MM,
)

from .common import (
    MOError,
    require_root,
    ensure_module_name,
    make_name,
    next_index,
    join_objects,
    parent_to,
    structural_meshes,
    bounds_of,
    mm_to_native,
    native_to_mm,
    refresh,
)

from .geometry import make_box_faces


def _front_bottom_y(meshes, target_x, tolerance):
    """
    Y of the real vertex at world X == target_x that is lowest,
    then frontmost - read off geometry, not off whichever object
    happens to own the X extreme.
    """

    candidates = []

    for obj in meshes:

        bounds = bounds_of([obj])

        if bounds is None:
            continue

        if not (bounds[0].x - tolerance <= target_x <= bounds[1].x + tolerance):
            continue

        matrix = obj.matrix_world

        for vertex in obj.data.vertices:

            world = matrix @ vertex.co

            if abs(world.x - target_x) <= tolerance:
                candidates.append(world)

    if not candidates:
        return None

    floor = min(point.z for point in candidates)

    return min(point.y for point in candidates if point.z - floor <= tolerance)


def module_bounds(root):
    """(lo, hi) of the module without handles, lo.y = front line."""

    meshes = structural_meshes(root)

    bounds = bounds_of(meshes)

    if bounds is None:
        return None

    lo, hi = bounds

    tolerance = max((hi.x - lo.x) * 1e-4, 1e-6)

    fronts = [
        y for y in (
            _front_bottom_y(meshes, lo.x, tolerance),
            _front_bottom_y(meshes, hi.x, tolerance),
        )
        if y is not None
    ]

    if fronts:
        lo.y = min(fronts)

    return lo, hi


def add_skirting(context, props, height_mm):

    root = require_root(context)
    module = ensure_module_name(props, root)

    bounds = module_bounds(root)

    if bounds is None:
        raise MOError("No mesh geometry found in module.")

    lo, hi = bounds

    size = list(hi - lo)

    depth = mm_to_native(size, SKIRTING_DEPTH_MM)
    height = mm_to_native(size, height_mm)

    collection = root.users_collection[0] if root.users_collection else context.collection

    faces = make_box_faces(
        "Skirting",
        lo.x, hi.x,
        lo.y - depth, lo.y,
        lo.z, lo.z + height,
        collection,
    )

    front = join_objects(context, [faces["-Y"], faces["+Y"]])
    edgeband = join_objects(context, [faces["-X"], faces["+X"], faces["-Z"], faces["+Z"]])

    index = next_index(module, SKIRTING_GROUP)

    front.name = make_name(module, SKIRTING_FRONT, index)
    edgeband.name = make_name(module, SKIRTING_EDGEBAND, index)

    group = bpy.data.objects.new(make_name(module, SKIRTING_GROUP, index), None)
    collection.objects.link(group)

    parent_to(group, [front, edgeband])
    parent_to(root, [group])

    bpy.ops.object.select_all(action='DESELECT')

    refresh(context)

    def mm(value):
        return f"{native_to_mm(size, value):.0f}"

    return (
        f"Skirting '{group.name}' built. Module bounds used (mm): "
        f"X[{mm(lo.x)},{mm(hi.x)}] Y[{mm(lo.y)},{mm(hi.y)}] Z[{mm(lo.z)},{mm(hi.z)}]"
    )

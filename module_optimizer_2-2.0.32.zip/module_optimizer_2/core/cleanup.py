"""
Module Cleanup and Module Name: clean up a raw module import, build each
Part's EdgeBand and Front / Back, set the pivot, delete empty
groups, and (re)name the module.
"""

from math import radians

import bmesh
import bpy

from mathutils import Vector

from ..config import (
    PART_PREFIX,
    FACE_PREFIX,
    FRONT_NAME,
    BACK_NAME,
    EDGEBAND_NAME,
    METER_THRESHOLD,
)

from .common import (
    MOError,
    module_meshes,
    bounds_of,
    module_center,
    ensure_object_mode,
    parent_to,
    join_objects,
    find_scene_root,
)

from .geometry import classify_pieces, pick_front_back


# =========================================================
# Clean Up Steps
# =========================================================

def set_scene_units_mm(context):

    units = context.scene.unit_settings

    units.system = 'METRIC'
    units.length_unit = 'MILLIMETERS'


def scale_down_if_raw(root):
    """
    Scale the module by 0.001 once - only while its geometry is
    still millimetre-sized, so repeat runs never shrink it again.
    """

    bounds = bounds_of(module_meshes(root))

    if bounds is None:
        return False

    lo, hi = bounds

    if max(hi - lo) < METER_THRESHOLD:
        return False

    root.scale = (0.001, 0.001, 0.001)

    return True


def select_module(context, root):
    """Select the root and every descendant; returns names skipped."""

    bpy.ops.object.select_all(action='DESELECT')

    in_layer = context.view_layer.objects

    skipped = []

    for obj in [root] + list(root.children_recursive):

        if obj.name in in_layer:
            obj.select_set(True)
        else:
            skipped.append(obj.name)

    context.view_layer.objects.active = root

    return skipped


def apply_transforms(context, root):

    ensure_object_mode(context)

    skipped = select_module(context, root)

    bpy.ops.object.transform_apply(
        location=True,
        rotation=True,
        scale=True,
        isolate_users=True,
    )

    return skipped


def tris_to_quads(root):

    for obj in module_meshes(root):

        bm = bmesh.new()
        bm.from_mesh(obj.data)

        bmesh.ops.join_triangles(
            bm,
            faces=bm.faces,
            angle_face_threshold=radians(40),
            angle_shape_threshold=radians(40),
            cmp_seam=True,
            cmp_sharp=True,
            cmp_uvs=True,
            cmp_materials=True,
        )

        bm.to_mesh(obj.data)
        bm.free()

        obj.data.update()


def remove_materials(root):

    for obj in module_meshes(root):
        obj.data.materials.clear()


def remove_empty_parts(root):

    empty = [
        obj for obj in root.children
        if obj.name.startswith(PART_PREFIX)
        and obj.type == 'EMPTY'
        and not obj.children
    ]

    for obj in empty:
        bpy.data.objects.remove(obj, do_unlink=True)

    return len(empty)


def purge_orphans():

    bpy.ops.outliner.orphans_purge(
        do_local_ids=True,
        do_linked_ids=True,
        do_recursive=True,
    )


# =========================================================
# EdgeBand + Front / Back
# =========================================================

def raw_parts(root):

    return [obj for obj in root.children if obj.name.startswith(PART_PREFIX)]


def raw_faces(part):

    return [child for child in part.children if child.name.startswith(FACE_PREFIX)]


def build_edgebands(context, parts):
    """
    For every Part with exactly 2 surface + 4 edge Face objects,
    join the 4 edges into one 'EdgeBand' under the Part.
    """

    built = 0

    for part in parts:

        surfaces, edges = classify_pieces(raw_faces(part))

        if len(surfaces) != 2 or len(edges) != 4:
            continue

        edgeband = join_objects(context, edges)
        edgeband.name = EDGEBAND_NAME

        parent_to(part, [edgeband])

        built += 1

    return built


def assign_front_back(parts, root):
    """Rename each Part's 2 surface Faces to Front (outward) / Back."""

    center = module_center(root)

    if center is None:
        return 0

    assigned = 0

    for part in parts:

        surfaces, _edges = classify_pieces(raw_faces(part))

        front, back = pick_front_back(surfaces, center)

        if front is None:
            continue

        front.name = FRONT_NAME
        back.name = BACK_NAME

        assigned += 2

    return assigned


# =========================================================
# CleanUp Module
# =========================================================

def cleanup_module(context, root):
    """Run every Module Cleanup action; returns a report string."""

    set_scene_units_mm(context)

    scaled = scale_down_if_raw(root)

    skipped = apply_transforms(context, root)

    tris_to_quads(root)
    remove_materials(root)

    removed = remove_empty_parts(root)

    purge_orphans()

    parts = raw_parts(root)

    edgebands = build_edgebands(context, parts)
    faces = assign_front_back(parts, root)

    message = (
        f"CleanUp done: {removed} empty Part(s) removed, "
        f"{edgebands} EdgeBand(s) built, {faces} face(s) set Front/Back."
    )

    if not scaled:
        message += " Scale was already applied."

    if skipped:
        message += f" {len(skipped)} object(s) outside the View Layer skipped."

    return message


# =========================================================
# Set Pivot Point
# =========================================================

def set_pivot_bottom_center(context, root):
    """Move the module so its bottom-centre sits at the origin."""

    bounds = bounds_of(module_meshes(root))

    if bounds is None:
        raise MOError("No mesh geometry found in module.")

    lo, hi = bounds

    bottom_center = Vector(((lo.x + hi.x) / 2.0, (lo.y + hi.y) / 2.0, lo.z))

    root.location -= bottom_center

    context.view_layer.update()

    skipped = apply_transforms(context, root)

    message = "Pivot set to bottom center."

    if skipped:
        message += f" {len(skipped)} object(s) outside the View Layer skipped."

    return message


# =========================================================
# Delete Empty Groups
# =========================================================

def delete_empty_groups(scene):
    """
    Delete every childless Empty in the scene. Reads live parent
    links, since obj.children can lag behind a fresh reparent.
    """

    parents = {obj.parent for obj in scene.objects if obj.parent is not None}

    empty = [
        obj for obj in scene.objects
        if obj.type == 'EMPTY' and obj not in parents
    ]

    for obj in empty:
        bpy.data.objects.remove(obj, do_unlink=True)

    return len(empty)


# =========================================================
# Module Name
# =========================================================

def rename_module(context, props, new_name):
    """
    Rename the module root and carry the new name onto every
    object that used the old '<old>_' prefix, plus any stray
    descendant still carrying another module's prefix.
    """

    new_name = new_name.strip()

    if not new_name:
        raise MOError("Please enter a module name.")

    root = find_scene_root(context)

    if root is None:
        raise MOError(
            "Could not find the module root - expected exactly one "
            "top-level object in the scene."
        )

    old_name = root.name
    old_prefix = old_name + "_"
    new_prefix = new_name + "_"

    descendants = set(root.children_recursive)

    renamed = 0

    for obj in list(bpy.data.objects):

        if obj is root:
            continue

        if old_name != new_name and obj.name.startswith(old_prefix):

            obj.name = new_name + obj.name[len(old_name):]
            renamed += 1

            continue

        if obj not in descendants or obj.name.startswith(new_prefix):
            continue

        if "_" not in obj.name:
            continue

        obj.name = new_prefix + obj.name.split("_", 1)[1]
        renamed += 1

    root.name = new_name
    props.module_name = new_name

    if old_name == new_name:
        return f"Module already named '{new_name}' ({renamed} stray object(s) fixed)."

    return f"Renamed '{old_name}' to '{new_name}' ({renamed} object(s) updated)."

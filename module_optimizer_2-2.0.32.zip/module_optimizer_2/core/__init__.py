"""Module Optimizer 2.0 - workflow logic, independent of the UI."""

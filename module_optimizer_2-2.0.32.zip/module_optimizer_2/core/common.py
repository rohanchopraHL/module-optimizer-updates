"""
Shared helpers: errors, naming, module-root lookup, object
plumbing (join / parent / group) and bounding boxes.
"""

import bpy

from mathutils import Vector

from ..config import (
    NAME_SEPARATOR,
    METER_THRESHOLD,
    PART_PREFIX,
    SHUTTER_GROUP,
    CARCASS_GROUP,
    HANDLE_TAG,
    HANDLE_SUFFIX,
)


# =========================================================
# Errors
# =========================================================

class MOError(Exception):
    """Raised by core functions; operators report the message."""


# =========================================================
# Naming
# =========================================================

def make_name(module_name, suffix, index):
    """Kitchen01 + sh-ft + 1 -> 'Kitchen01_sh-ft_01'."""

    return NAME_SEPARATOR.join([module_name, suffix, f"{index:02d}"])


def next_index(module_name, suffix):
    """Next free 2-digit number for '<module>_<suffix>_NN'."""

    prefix = NAME_SEPARATOR.join([module_name, suffix, ""])

    highest = 0

    for obj in bpy.data.objects:

        if not obj.name.startswith(prefix):
            continue

        digits = obj.name[len(prefix):len(prefix) + 2]

        if digits.isdigit():
            highest = max(highest, int(digits))

    return highest + 1


def existing_index(module_name, suffix, obj):
    """NN if obj is already named '<module>_<suffix>_NN', else None."""

    prefix = NAME_SEPARATOR.join([module_name, suffix, ""])

    if not obj.name.startswith(prefix):
        return None

    digits = obj.name[len(prefix):len(prefix) + 2]

    return int(digits) if digits.isdigit() else None


# =========================================================
# Module Root
# =========================================================

def find_scene_root(context):
    """
    The scene's single top-level object (Empty or raw Mesh), so
    tools work with nothing selected. If several are top-level,
    childless leftovers are ignored. None when still ambiguous.
    """

    candidates = [obj for obj in context.scene.objects if obj.parent is None]

    if len(candidates) == 1:
        return candidates[0]

    with_children = [obj for obj in candidates if obj.children]

    if len(with_children) == 1:
        return with_children[0]

    return None


def topmost(obj):

    while obj is not None and obj.parent is not None:
        obj = obj.parent

    return obj


def find_root(context):
    """
    Module root: the scene's only top-level object, or - when
    several modules are loaded - the top-level Empty above the
    active object.
    """

    root = find_scene_root(context)

    if root is not None:
        return root

    top = topmost(context.active_object)

    if top is not None and top.type == 'EMPTY':
        return top

    return None


def require_root(context):

    root = find_root(context)

    if root is None:
        raise MOError(
            "Module root not found - with more than one module in "
            "the scene, select something inside the module first."
        )

    return root


def ensure_module_name(props, root):
    """Fall back to the root's own name when no Module Name was applied."""

    if not props.module_name.strip():
        props.module_name = root.name

    return props.module_name


# =========================================================
# Object Plumbing
# =========================================================

def ensure_object_mode(context):

    if context.mode != 'OBJECT' and context.view_layer.objects.active:
        bpy.ops.object.mode_set(mode='OBJECT')


def select_only(context, objects):

    bpy.ops.object.select_all(action='DESELECT')

    first = None

    for obj in objects:

        if obj is None or obj.name not in context.view_layer.objects:
            continue

        obj.select_set(True)

        if first is None:
            first = obj

    if first is not None:
        context.view_layer.objects.active = first

    return first


def join_objects(context, objects):
    """Join meshes into the first one; returns the survivor."""

    objects = [obj for obj in objects if obj is not None]

    if not objects:
        return None

    if len(objects) == 1:
        return objects[0]

    ensure_object_mode(context)

    survivor = objects[0]

    select_only(context, objects)
    context.view_layer.objects.active = survivor

    bpy.ops.object.join()

    return survivor


def parent_to(parent, objects):
    """Parent while keeping the current world placement."""

    for child in objects:

        if child is None or child is parent:
            continue

        child.parent = parent
        child.matrix_parent_inverse = parent.matrix_world.inverted()


def link_like(obj, reference, context):
    """Link obj into the same collection(s) as reference."""

    collections = reference.users_collection if reference else ()

    if collections:
        for collection in collections:
            collection.objects.link(obj)
    else:
        context.collection.objects.link(obj)


def get_or_create_group(context, name, parent, root):
    """
    Plain-axes Empty called `name` under `parent`, reused if it
    already exists (avoids Blender's '.001' duplicates).
    """

    group = bpy.data.objects.get(name)

    if group is None:

        group = bpy.data.objects.new(name, None)
        group.empty_display_type = 'PLAIN_AXES'

        link_like(group, root, context)

        group.matrix_world = root.matrix_world.copy()

    parent_to(parent, [group])

    return group


def carcass_group(context, props, root):
    """Get-or-create '<module>_car_01' under the module root."""

    return get_or_create_group(
        context,
        make_name(props.module_name, CARCASS_GROUP, 1),
        root,
        root,
    )


def remove_if_empty(obj):

    if obj is None:
        return

    try:
        name = obj.name
    except ReferenceError:
        return

    if name in bpy.data.objects and not obj.children:
        bpy.data.objects.remove(obj, do_unlink=True)


def remove_empty_shutter_groups(props):
    """Drop '<module>_sh_NN' Empties left childless by a convention."""

    prefix = NAME_SEPARATOR.join([props.module_name, SHUTTER_GROUP, ""])

    for obj in list(bpy.data.objects):

        if obj.type == 'EMPTY' and obj.name.startswith(prefix) and not obj.children:
            bpy.data.objects.remove(obj, do_unlink=True)


def refresh(context):

    context.view_layer.update()

    screen = getattr(context, "screen", None)

    if screen is None:
        return

    for area in screen.areas:

        if area.type == 'VIEW_3D':
            area.tag_redraw()


# =========================================================
# Selection Queries
# =========================================================

def is_part(obj):

    return obj.name.startswith(PART_PREFIX)


def selected_parts(context):

    return [obj for obj in context.selected_objects if is_part(obj)]


def selected_meshes(context):

    return [obj for obj in context.selected_objects if obj.type == 'MESH']


def selected_meshes_expanded(context):
    """Selected meshes plus the mesh children of selected Empties."""

    meshes = []

    for obj in context.selected_objects:

        if obj.type == 'MESH':
            candidates = [obj]
        elif obj.type == 'EMPTY':
            candidates = [c for c in obj.children if c.type == 'MESH']
        else:
            candidates = []

        for mesh in candidates:
            if mesh not in meshes:
                meshes.append(mesh)

    return meshes


def module_meshes(root, include_root=True):
    """Every mesh in the module (the root itself if it is a mesh)."""

    meshes = [obj for obj in root.children_recursive if obj.type == 'MESH']

    if include_root and root.type == 'MESH':
        meshes.insert(0, root)

    return meshes


# =========================================================
# Handles
# =========================================================

def is_handle(obj):
    """True for a placed handle or anything parented under one."""

    tag = f"{NAME_SEPARATOR}{HANDLE_SUFFIX}{NAME_SEPARATOR}"

    while obj is not None:

        if obj.get(HANDLE_TAG) or tag in obj.name:
            return True

        obj = obj.parent

    return False


def structural_meshes(root):
    """Module meshes minus handles (handles stick out of panels)."""

    return [obj for obj in module_meshes(root) if not is_handle(obj)]


# =========================================================
# Bounds
# =========================================================

def world_corners(obj):

    return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]


def bounds_of(objects):
    """(min Vector, max Vector) over objects' world bounding boxes."""

    lo = hi = None

    for obj in objects:

        for corner in world_corners(obj):

            if lo is None:
                lo = corner.copy()
                hi = corner.copy()
                continue

            lo.x = min(lo.x, corner.x)
            lo.y = min(lo.y, corner.y)
            lo.z = min(lo.z, corner.z)
            hi.x = max(hi.x, corner.x)
            hi.y = max(hi.y, corner.y)
            hi.z = max(hi.z, corner.z)

    if lo is None:
        return None

    return lo, hi


def module_center(root):

    bounds = bounds_of(module_meshes(root))

    if bounds is None:
        return None

    lo, hi = bounds

    return (lo + hi) / 2.0


# =========================================================
# Units
# =========================================================

def is_meter_scale(dimensions):

    return max(dimensions, default=0.0) < METER_THRESHOLD


def mm_to_native(reference_dimensions, value_mm):

    if is_meter_scale(reference_dimensions):
        return value_mm / 1000.0

    return value_mm


def native_to_mm(reference_dimensions, value):

    if is_meter_scale(reference_dimensions):
        return value * 1000.0

    return value

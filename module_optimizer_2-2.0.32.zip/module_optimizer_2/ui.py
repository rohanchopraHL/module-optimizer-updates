"""Sidebar panel: View3D > Sidebar > Module Optimizer 2.0. Text only, no icons."""

import bpy

from . import updates


def _collapsible(layout, props, attr, title):
    """Box with an expand arrow; returns (box, is_open)."""

    box = layout.box()

    is_open = getattr(props, attr)

    row = box.row(align=True)
    row.prop(props, attr, text=title, icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=False)

    return box, is_open


class MO2_PT_Main(bpy.types.Panel):

    bl_label = "Module Optimizer 2.0"
    bl_idname = "MO2_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Module Optimizer 2.0"

    def draw(self, context):

        layout = self.layout
        props = context.scene.mo2

        # -------------------------------------------------
        # Module Cleanup
        # -------------------------------------------------

        box = layout.box()
        box.label(text="Module Cleanup")

        col = box.column(align=True)
        col.operator("mo2.cleanup_module")
        col.operator("mo2.delete_empty_groups")
        col.operator("mo2.set_pivot")

        # -------------------------------------------------
        # Module Name
        # -------------------------------------------------

        box = layout.box()
        box.label(text="Module Name")

        if props.module_name:
            box.label(text=f"Current: {props.module_name}")

        box.prop(props, "module_name_input", text="")
        box.operator("mo2.apply_module_name")

        # -------------------------------------------------
        # Conventions
        # -------------------------------------------------

        box = layout.box()
        box.label(text="Conventions")

        # Three framed groups: groups / panels / shelves.

        col = box.box().column(align=True)
        col.operator("mo2.carcass_internals", text="Carcass")
        col.operator("mo2.shutter", text="Shutter")

        col = box.box().column(align=True)
        col.operator("mo2.top_panel")
        col.operator("mo2.bottom_panel")
        col.operator("mo2.sides_panel")
        col.operator("mo2.back_panel")
        # Visible Side Panels hidden for now (operator still registered);
        # re-add: col.operator("mo2.visible_side_panels")

        col = box.box().column(align=True)
        col.operator("mo2.removable_shelf")
        col.operator("mo2.fixed_shelf")

        # -------------------------------------------------
        # Handle Library
        # -------------------------------------------------

        box, is_open = _collapsible(layout, props, "handles_expanded", "Handle Library")

        if is_open:

            box.prop(props, "handle_asset", text="Handle")

            if props.handle_asset not in ("", "NONE"):

                box.row().prop(props, "handle_orientation", expand=True)

                if props.handle_orientation == 'VERTICAL':
                    box.grid_flow(columns=2, even_columns=True, align=True).prop(
                        props, "handle_vertical_position", expand=True
                    )
                else:
                    box.row(align=True).prop(props, "handle_horizontal_position", expand=True)

            row = box.row(align=True)
            row.prop(props, "handle_target", text="")
            row.operator("mo2.pick_handle_target", text="Pick")

            box.operator("mo2.add_handle")

        # -------------------------------------------------
        # Skirting
        # -------------------------------------------------

        box, is_open = _collapsible(layout, props, "skirting_expanded", "Skirting")

        if is_open:
            box.row().prop(props, "skirting_height", expand=True)
            box.operator("mo2.add_skirting")

        # -------------------------------------------------
        # UV Checker / Export
        # -------------------------------------------------

        box = layout.box()
        box.label(text="UV Checker")
        box.operator("mo2.unwrap")

        box = layout.box()
        box.label(text="Export")
        box.operator("mo2.export_collada", text="Export")

        # -------------------------------------------------
        # Version / What's new
        # -------------------------------------------------

        row = layout.box().row()
        row.label(text=f"Version {updates.installed_version()}")
        row.operator("mo2.whats_new", text="What's new")


classes = (MO2_PT_Main,)

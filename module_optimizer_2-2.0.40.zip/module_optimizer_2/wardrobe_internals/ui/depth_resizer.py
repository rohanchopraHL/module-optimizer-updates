import bpy

from .common import draw_separator, draw_section


# =========================================================
# Row
# =========================================================

def draw_rescale_row(box, owner, cabinet_prop, shelf_prop, index, apply_op, remove_op):
    """
    [ Cabinet ] [ Shelf / Floor ] [apply] [x]
    """

    row = box.row()

    row.prop(owner, cabinet_prop, text="")
    row.prop(owner, shelf_prop, text="")

    buttons = row.row(align=True)

    apply = buttons.operator(
        apply_op,
        text="",
        icon='MOD_LENGTH'
    )
    apply.index = index

    remove = buttons.operator(
        remove_op,
        text="",
        icon='X'
    )
    remove.index = index


# =========================================================
# Section (shared by Depth Resizer and Width Rescale)
# =========================================================

def draw_rescale_section(
        layout, props, *, title, what, prefix,
        item_cabinet, item_shelf, ops, options, export_label,
):
    """
    prefix "depth" -> props.depth_cabinet / depth_shelf (first
    row), props.depth_rows (added rows, item_cabinet /
    item_shelf on each); ops = (add, remove, apply, export_all).
    """

    add_op, remove_op, apply_op, export_op = ops

    box = draw_section(
        layout,
        title,
        'MOD_LENGTH'
    )

    # -------------------------------------------------
    # Column Headings
    # -------------------------------------------------

    header = box.row()

    header.label(text=f"Cabinet {what} (mm)")
    header.label(text=f"Shelf / Floor {what} (mm)")

    spacer = header.row(align=True)
    spacer.label(text="", icon='BLANK1')
    spacer.label(text="", icon='BLANK1')

    # -------------------------------------------------
    # Rows - the first one is always there, empty
    # -------------------------------------------------

    draw_rescale_row(
        box, props, f"{prefix}_cabinet", f"{prefix}_shelf", 0,
        apply_op, remove_op,
    )

    for i, item in enumerate(getattr(props, f"{prefix}_rows"), start=1):
        draw_rescale_row(
            box, item, item_cabinet, item_shelf, i,
            apply_op, remove_op,
        )

    add_row = box.row()
    add_row.alignment = 'LEFT'

    add_row.operator(
        add_op,
        text=f"Add {what.lower()}",
        icon='ADD'
    )

    box.separator()

    # -------------------------------------------------
    # Options + Batch
    # -------------------------------------------------

    for name in options:
        box.prop(props, name)

    box.operator(
        export_op,
        text=export_label,
        icon='EXPORT'
    )


# =========================================================
# Draw Depth Resizer UI
# =========================================================

def draw_depth_resizer(layout, context):

    draw_rescale_section(
        layout,
        context.scene.mo2wi,
        title="Depth Resizer",
        what="Depth",
        prefix="depth",
        item_cabinet="cabinet_depth",
        item_shelf="shelf_depth",
        ops=(
            "mo2wi.depth_add",
            "mo2wi.depth_remove",
            "mo2wi.resize_depth",
            "mo2wi.resize_depth_export_all",
        ),
        options=(
            "depth_exclude",
            "depth_axis",
            "depth_output_dir",
            "depth_rename",
            "depth_selected_only",
        ),
        export_label="Resize + Export All",
    )

    draw_separator(layout)


# =========================================================
# Draw Width Rescale UI
# =========================================================

def draw_width_rescale(layout, context):

    draw_rescale_section(
        layout,
        context.scene.mo2wi,
        title="Width Rescale",
        what="Width",
        prefix="width",
        item_cabinet="cabinet_width",
        item_shelf="shelf_width",
        ops=(
            "mo2wi.width_add",
            "mo2wi.width_remove",
            "mo2wi.rescale_width",
            "mo2wi.rescale_width_export_all",
        ),
        options=(
            "width_exclude",
            "width_output_dir",
            "width_rename",
            "width_selected_only",
        ),
        export_label="Rescale + Export All",
    )

    draw_separator(layout)

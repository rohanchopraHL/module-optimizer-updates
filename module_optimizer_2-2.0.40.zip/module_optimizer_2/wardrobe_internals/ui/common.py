import bpy


# =========================================================
# Separator
# =========================================================

def draw_separator(layout):

    layout.separator(factor=0.8)


# =========================================================
# Section Title
# =========================================================

def draw_section(layout, title, icon='NONE'):

    box = layout.box()

    box.label(
        text=title,
        icon=icon
    )

    return box


# =========================================================
# Picker Row
# =========================================================

def draw_picker_row(
        box,
        props,
        property_name,
        set_operator,
        clear_operator,
):

    row = box.row(align=True)

    row.prop(
        props,
        property_name,
        text=""
    )

    row.operator(
        set_operator,
        text="",
        icon='EYEDROPPER'
    )

    row.operator(
        clear_operator,
        text="",
        icon='X'
    )


# =========================================================
# Message Box
# =========================================================

def draw_message(
        box,
        message,
        icon='INFO',
):

    box.label(
        text=message,
        icon=icon
    )

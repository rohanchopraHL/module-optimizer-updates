"""
============================================================
Wardrobe Internals

UI Package

No panel of its own: Module Optimizer 2.0 draws draw_panel()
in its own sidebar tab when Category is "Wardrobe Internals".
============================================================
"""

from .panel import draw_panel


def register():
    pass


def unregister():
    pass

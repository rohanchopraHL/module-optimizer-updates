import bpy

from ..core.hanger_rod import is_hanger_rod

from .common import (
    draw_separator,
    draw_section,
    draw_picker_row,
    draw_message,
)


# =========================================================
# Draw Hardware Library UI
# =========================================================

def draw_handle(layout, context):

    props = context.scene.mo2wi

    box = draw_section(
        layout,
        "Hardware Library",
        'MESH_CAPSULE'
    )

    # =====================================================
    # Handle Asset
    # =====================================================

    box.prop(
        props,
        "handle_asset",
        text="Item"
    )

    has_asset = props.handle_asset not in ("", "NONE")

    if has_asset and is_hanger_rod(props.handle_asset):

        # =================================================
        # Hanger Rod - no Place On needed, module root +
        # Fixed Shelf are both found automatically. One
        # button pops up Height / Full Rod / Half Rod (+
        # Left/Right if Half) in a single dialog.
        # =================================================

        box.operator(
            "mo2wi.add_hanger_rod",
            text="Add Hanger Rod",
        )

    else:

        # =================================================
        # Place On (Target)
        # =================================================

        draw_picker_row(
            box,
            props,
            "handle_target",
            "mo2wi.set_handle_target",
            "mo2wi.clear_handle_target",
        )

        # =================================================
        # Left / Center / Right - only once both an Item and
        # a Place On target are picked. All three drop the
        # handle on the target's front (-Y) face at Z centre;
        # they differ only in X (Center / 10% inset from an
        # edge).
        # =================================================

        has_target = props.handle_target is not None

        if has_asset and has_target:

            row = box.row(align=True)

            for value, label in (
                ('LEFT', "Left"),
                ('CENTER', "Center"),
                ('RIGHT', "Right"),
            ):

                op = row.operator(
                    "mo2wi.add_handle",
                    text=label,
                )

                op.position = value

        else:

            draw_message(
                box,
                "Select an Item and Place On target, then:",
            )

    # =====================================================
    # Placed Handles
    # =====================================================

    if len(props.handle_objects) == 0:

        draw_message(
            box,
            "No Hardware Placed",
        )

        draw_separator(layout)

        return

    for index, item in enumerate(props.handle_objects):

        row = box.row(align=True)

        row.prop(
            item,
            "object",
            text=""
        )

        remove = row.operator(
            "mo2wi.remove_handle",
            text="",
            icon='X'
        )

        remove.index = index

    draw_separator(layout)

import bpy

from ..config import NUDGE_UP_MM

from .common import draw_separator, draw_section


# =========================================================
# Draw Nudge UI
# =========================================================

def draw_nudge(layout, context):

    box = draw_section(
        layout,
        "Nudge",
        'SORT_ASC'
    )

    box.label(
        text="Select faces (Edit Mode) or objects, then:",
        icon='INFO'
    )

    box.operator(
        "mo2wi.nudge_up",
        text=f"Nudge Up ({NUDGE_UP_MM:g}mm)",
    )

    draw_separator(layout)

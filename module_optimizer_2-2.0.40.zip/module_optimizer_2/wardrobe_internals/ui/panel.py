from .common import (
    draw_separator,
    draw_section,
)

from .panel_conventions import (
    draw_panel_conventions,
)

from .flip import (
    draw_flip,
)

from .depth_resizer import (
    draw_depth_resizer,
    draw_width_rescale,
)


# =========================================================
# Main Panel - drawn inside Module Optimizer 2.0's tab
# (Category: Wardrobe Internals)
# =========================================================

def draw_panel(layout, context):

    # =================================================
    # Module Cleanup / Module Name - first, laid out
    # like Cabinets and Wardrobes (text only)
    # =================================================

    # Laid out as in the team's sketch: cleanup box, name + Optimize Internal
    # box, then everything else folded into "Convention".

    box = layout.box()
    col = box.column(align=True)
    col.operator("mo2wi.optimise_module", text="CleanUp Module")
    col.operator("mo2wi.delete_empty_groups", text="Delete Empty Groups/Remove Shell")
    col.operator("mo2wi.set_pivot_point", text="Set Pivot Point")

    # Module name (main group only, no selection needed - Optimize
    # Internal also names the module from it), then Optimize Internal
    # (the former Internal Optimizer v1.0).
    box = layout.box()
    box.prop(context.scene.mo2wi, "module_name", text="")
    box.operator("mo2wi.module_name", text="Apply Module Name")

    from ..auto_optimizer import draw_auto_optimize

    box.separator()
    draw_auto_optimize(box, context)

    # Convention: Panel Conventions only, collapsible. Nudge and Hardware
    # Library removed; Flip and everything after it are outside it,
    # always visible.
    auto = context.scene.mo2wi_auto
    conv_box = layout.box()
    conv_box.prop(auto, "conventions_expanded", text="Convention",
                   icon='TRIA_DOWN' if auto.conventions_expanded else 'TRIA_RIGHT', emboss=False)

    if auto.conventions_expanded:
        draw_panel_conventions(
            conv_box,
            context,
        )

    # =================================================
    # Flip
    # =================================================

    draw_flip(
        layout,
        context,
    )

    # =================================================
    # UV Checker
    # =================================================

    box = draw_section(
        layout,
        "UV Checker",
        'UV'
    )

    box.operator(
        "mo2wi.unwrap",
        text="Unwrap",
        icon='MOD_UVPROJECT'
    )

    draw_separator(layout)

    # =================================================
    # Resizer - collapsible, like Convention; opens to a
    # choice of Depth (Depth Resizer) or Width (Width
    # Rescale), each collapsible in turn.
    # =================================================

    resizer_box = layout.box()
    resizer_box.prop(
        auto, "resizer_expanded", text="Resizer",
        icon='TRIA_DOWN' if auto.resizer_expanded else 'TRIA_RIGHT', emboss=False,
    )

    if auto.resizer_expanded:

        depth_box = resizer_box.box()
        depth_box.prop(
            auto, "resizer_depth_expanded", text="Depth",
            icon='TRIA_DOWN' if auto.resizer_depth_expanded else 'TRIA_RIGHT', emboss=False,
        )

        if auto.resizer_depth_expanded:
            draw_depth_resizer(
                depth_box,
                context,
            )

        width_box = resizer_box.box()
        width_box.prop(
            auto, "resizer_width_expanded", text="Width",
            icon='TRIA_DOWN' if auto.resizer_width_expanded else 'TRIA_RIGHT', emboss=False,
        )

        if auto.resizer_width_expanded:
            draw_width_rescale(
                width_box,
                context,
            )

    draw_separator(layout)

    # =================================================
    # Export
    # =================================================

    box = draw_section(
        layout,
        "Export",
        'EXPORT'
    )

    box.operator(
        "mo2wi.export_collada",
        text="Collada (.DAE) Export...",
        icon='EXPORT'
    )

import bpy

from .common import draw_separator, draw_section


# =========================================================
# Draw Flip UI
# =========================================================

def draw_flip(layout, context):

    box = draw_section(
        layout,
        "Flip",
        'MOD_MIRROR'
    )

    box.operator(
        "mo2wi.flip",
        text="Flip Module",
    )

    box.operator(
        "mo2wi.flip_drawer_filler",
        text="Flip Drawer Filler",
    )

    draw_separator(layout)

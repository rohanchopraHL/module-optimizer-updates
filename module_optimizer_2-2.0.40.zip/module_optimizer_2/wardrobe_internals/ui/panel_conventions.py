import bpy

from ..config import (
    FIXED_SHELF_SUFFIX,
    REMOVABLE_SHELF_SUFFIX,
    DRAWER_FILLER_SUFFIX,
    INTERNAL_DRAWER_SUFFIX,
    INTERNAL_GLASS_DRAWER_SUFFIX,
    CARCASS_INTERNAL,
    VERTICAL_PANEL_SUFFIX,
)

from .common import draw_separator, draw_section


# =========================================================
# Button Definitions
# =========================================================
# (label, suffix, combine) - combine=True joins every selected
# face into ONE object even if the selection spans several
# disconnected islands (Drawer Filler, Internal Drawer,
# Internal Glass Drawer, Carcass Internal); the others split
# multi-island selections into one object per island instead.
# All 7 share the one BUTTON_ICON below (same icon CleanUp
# Module uses) instead of a different icon each.

BUTTON_ICON = 'MOD_SOLIDIFY'

PANEL_CONVENTION_BUTTONS = (
    ("Fixed Shelf", FIXED_SHELF_SUFFIX, False),
    ("Removable Shelf", REMOVABLE_SHELF_SUFFIX, False),
    ("Drawer Filler", DRAWER_FILLER_SUFFIX, True),
    ("Internal Drawer", INTERNAL_DRAWER_SUFFIX, True),
    ("Internal Glass Drawer", INTERNAL_GLASS_DRAWER_SUFFIX, True),
    ("Carcass Internal", CARCASS_INTERNAL, True),
    ("Vertical Panel", VERTICAL_PANEL_SUFFIX, False),
)


# =========================================================
# Draw Panel Conventions UI
# =========================================================

def draw_panel_conventions(layout, context):

    box = draw_section(
        layout,
        "Panel Conventions",
        'MOD_BUILD'
    )

    box.label(
        text="Select faces (Edit Mode) or objects, then:",
        icon='INFO'
    )

    col = box.column(align=True)

    for label, suffix, combine in PANEL_CONVENTION_BUTTONS:

        op = col.operator(
            "mo2wi.panel_convention",
            text=label,
            icon=BUTTON_ICON,
        )

        op.suffix = suffix
        op.label = label
        op.combine = combine

    draw_separator(layout)

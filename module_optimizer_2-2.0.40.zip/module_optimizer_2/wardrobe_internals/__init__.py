bl_info = {
    "name": "Wardrobe Internals",
    "author": "Rohan Chopra",
    "version": (1, 0, 6),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Wardrobe Internals",
    "description": "Wardrobe internals prep: CleanUp Module strips the outer "
    "carcass and combines the internal geometry; plus pivot, Handle Library, "
    "UV Checker and Collada export.",
    "category": "Object",
}

import bpy

from bpy.props import PointerProperty

from .properties import (
    MO2WI_ObjectItem,
    MO2WI_ShutterGroupItem,
    MO2WI_CarcassInternalOSLItem,
    MO2WI_InternalSet,
    MO2WI_DepthItem,
    MO2WI_WidthItem,
    MO2WI_Properties,
)

from .core.uv_checker import (
    register_box_map,
    unregister_box_map,
)

from . import ui
from . import ops
from . import auto_optimizer


# =========================================================
# Classes
# =========================================================

classes = (
    MO2WI_ObjectItem,
    MO2WI_ShutterGroupItem,
    MO2WI_CarcassInternalOSLItem,
    MO2WI_InternalSet,
    MO2WI_DepthItem,
    MO2WI_WidthItem,
    MO2WI_Properties,
)


# =========================================================
# Register
# =========================================================

def register():

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.mo2wi = PointerProperty(
        type=MO2WI_Properties
    )

    register_box_map()

    ui.register()
    ops.register()
    auto_optimizer.register()


# =========================================================
# Unregister
# =========================================================

def unregister():

    auto_optimizer.unregister()
    ops.unregister()
    ui.unregister()

    unregister_box_map()

    del bpy.types.Scene.mo2wi

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

import bpy

from bpy.types import PropertyGroup

from bpy.props import (
    StringProperty,
    EnumProperty,
    PointerProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
)

from .config import (
    GROUP_CONVENTIONS,
    EDIT_CONVENTION_ACTIONS,
    MODULE_TYPES,
    HANDLE_ORIENTATIONS,
    HANDLE_POSITIONS,
    HANDLE_HORIZONTAL_POSITIONS,
    SKIRTING_HEIGHTS,
    DEPTH_RESIZE_EXCLUDE,
    DEPTH_AXES,
    WIDTH_RESCALE_EXCLUDE,
)

from .core.handle_library import get_handle_enum_items


# =========================================================
# Object Item
# =========================================================

class MO2WI_ObjectItem(PropertyGroup):

    object: PointerProperty(
        name="Object",
        type=bpy.types.Object,
    )


# =========================================================
# Shutter Group Item
# =========================================================

class MO2WI_ShutterGroupItem(PropertyGroup):

    object: PointerProperty(
        name="Object",
        type=bpy.types.Object,
    )

    combine_front_back: BoolProperty(
        name="Combine Front & Back",
        default=False,
    )


# =========================================================
# Carcass Internal OSL/BSL Item
# =========================================================

class MO2WI_CarcassInternalOSLItem(PropertyGroup):

    object: PointerProperty(
        name="Object",
        type=bpy.types.Object,
    )

    combine_faces: BoolProperty(
        name="Combine Faces",
        default=False,
    )

    expanded: BoolProperty(
        default=True
    )


# =========================================================
# Internal Set
# =========================================================

class MO2WI_InternalSet(PropertyGroup):

    name: StringProperty(
        name="Name",
        default="Internal"
    )

    objects: CollectionProperty(
        type=MO2WI_ObjectItem
    )

    active_index: IntProperty(
        default=0
    )

    expanded: BoolProperty(
        default=True
    )


# =========================================================
# Depth Resizer Row
# =========================================================

CABINET_DEPTH_DESCRIPTION = (
    "Used for renaming: -450-DC in the module / object names "
    "becomes -<this>-DC"
)

SHELF_DEPTH_DESCRIPTION = (
    "Depth (mm) the shelves / floor are rescaled to"
)


class MO2WI_DepthItem(PropertyGroup):
    """
    An extra Depth Resizer row (the first row lives directly on
    MO2WI_Properties). Text fields so a new row really starts
    empty - the operators check the values are numbers.
    """

    cabinet_depth: StringProperty(
        name="Cabinet Depth (mm)",
        description=CABINET_DEPTH_DESCRIPTION,
        default="",
    )

    shelf_depth: StringProperty(
        name="Shelf / Floor Depth (mm)",
        description=SHELF_DEPTH_DESCRIPTION,
        default="",
    )


# =========================================================
# Width Rescale Row
# =========================================================

CABINET_WIDTH_DESCRIPTION = (
    "Added to the module / object names: -450-DC becomes "
    "-450-DC-<this>W"
)

SHELF_WIDTH_DESCRIPTION = (
    "Overall internal width (mm) the module is rescaled to, "
    "spread equally over its bays"
)


class MO2WI_WidthItem(PropertyGroup):
    """
    An extra Width Rescale row (the first row lives directly on
    MO2WI_Properties) - text fields, same as MO2WI_DepthItem.
    """

    cabinet_width: StringProperty(
        name="Cabinet Width (mm)",
        description=CABINET_WIDTH_DESCRIPTION,
        default="",
    )

    shelf_width: StringProperty(
        name="Shelf / Floor Width (mm)",
        description=SHELF_WIDTH_DESCRIPTION,
        default="",
    )


# =========================================================
# Group Convention Update
# =========================================================

def _on_group_convention_update(self, context):
    """
    Selecting "Shutter" is the complete "add group" action:
    it creates the next Shutter Group, assigns whatever object
    is currently active in the viewport to it, then immediately
    resets back to blank so picking "Shutter" again starts the
    next group. There is no manual "Add Group" button anymore.
    """

    if self.group_convention != "SHUTTER":
        return

    item = self.shutter_groups.add()

    if context.active_object is not None:
        item.object = context.active_object

    self.group_convention = 'NONE'


# =========================================================
# Visible Sides / Side Panels Update (Mutually Exclusive)
# =========================================================
# "L/R Visible Side OSL/BSL" and "Visible Side OSL/BSL" both
# auto-detect the same Left/Right Parts and both end up nested
# in the same "_car_vs_01" group - they only differ in naming
# (fixed "_car_vs-l/-r_" numbers vs continuing "_car_sd-pnl_"
# numbers), so only one can be active at a time.

def _on_carcass_visible_sides_update(self, context):

    if self.carcass_visible_sides:
        self.carcass_side_panels = False


def _on_carcass_side_panels_update(self, context):

    if self.carcass_side_panels:
        self.carcass_visible_sides = False


# =========================================================
# Main Properties
# =========================================================

class MO2WI_Properties(PropertyGroup):

    # =====================================================
    # Module
    # =====================================================

    module_type: EnumProperty(
        name="Module Type",
        items=MODULE_TYPES,
        default="NONE",
    )

    module_name: StringProperty(
        name="Module Name",
        default=""
    )

    # =====================================================
    # Rename Module (Existing Module)
    # =====================================================

    rename_module_name: StringProperty(
        name="New Module Name",
        default="",
        description=(
            "New name to rename the module to - updates the "
            "module's root Empty and every face/group under it "
            "that carries the old name, with no selection needed"
        ),
    )

    # =====================================================
    # Convention
    # =====================================================

    group_convention: EnumProperty(
        name="Group Convention",
        items=GROUP_CONVENTIONS,
        default="NONE",
        update=_on_group_convention_update,
    )

    # =====================================================
    # EDIT CONVENTION
    # =====================================================

    edit_convention_action: EnumProperty(
        name="Edit Convention",
        items=EDIT_CONVENTION_ACTIONS,
        default="NONE",
    )

    # =====================================================
    # SHUTTER
    # =====================================================

    shutter_groups: CollectionProperty(
        type=MO2WI_ShutterGroupItem
    )

    # =====================================================
    # COUNTER TOP
    # =====================================================

    countertop_group: PointerProperty(
        name="Counter Top Group",
        type=bpy.types.Object,
    )

    countertop_index: IntProperty(
        default=0
    )

    # =====================================================
    # CARCASS
    # =====================================================

    carcass_visible_sides: BoolProperty(
        name="L/R Visible Side OSL/BSL",
        description=(
            "Also find and label the Left/Right visible carcass "
            "side panels when Apply Convention runs. Mutually "
            "exclusive with Visible Side OSL/BSL"
        ),
        default=False,
        update=_on_carcass_visible_sides_update,
    )

    carcass_side_panels: BoolProperty(
        name="Visible Side OSL/BSL",
        description=(
            "Same Left/Right visible carcass side panel detection "
            "as L/R Visible Side OSL/BSL, but named like Edit/"
            "Existing Modules' Visible Side Panels ('_car_sd-pnl_', "
            "numbers continuing instead of fixed per side). "
            "Mutually exclusive with L/R Visible Side OSL/BSL"
        ),
        default=False,
        update=_on_carcass_side_panels_update,
    )

    carcass_osl_top: BoolProperty(
        name="OSL/BSL Top",
        description=(
            "Also auto-detect the module's top panel (same +Z "
            "detection as Counter Top) and label it OSL/BSL when "
            "Apply Convention runs. Mutually exclusive with "
            "Counter Top on the same panel - whichever runs first "
            "consumes its Front/Back/EdgeBand"
        ),
        default=False,
    )

    carcass_osl_bottom: BoolProperty(
        name="OSL/BSL Bottom",
        description=(
            "Also auto-detect the module's bottom panel (the Part "
            "sitting 100-150mm above the base) and label it "
            "OSL/BSL when Apply Convention runs"
        ),
        default=False,
    )

    carcass_internal_osl_parts: CollectionProperty(
        type=MO2WI_CarcassInternalOSLItem
    )

    internal_sets: CollectionProperty(
        type=MO2WI_InternalSet
    )

    active_internal_set: IntProperty(
        default=0
    )

    # =====================================================
    # HANDLE LIBRARY
    # =====================================================

    handle_asset: EnumProperty(
        name="Handle",
        items=get_handle_enum_items,
    )

    handle_orientation: EnumProperty(
        name="Orientation",
        items=HANDLE_ORIENTATIONS,
        default="HORIZONTAL",
    )

    handle_position: EnumProperty(
        name="Position",
        items=HANDLE_POSITIONS,
        default="NONE",
    )

    handle_horizontal_position: EnumProperty(
        name="Position",
        items=HANDLE_HORIZONTAL_POSITIONS,
        default="CENTER",
    )

    handle_target: PointerProperty(
        name="Place On",
        type=bpy.types.Object,
    )

    handle_objects: CollectionProperty(
        type=MO2WI_ObjectItem
    )

    handle_active: IntProperty(
        default=0
    )

    # =====================================================
    # SKIRTING
    # =====================================================

    skirting_height: EnumProperty(
        name="Height",
        items=SKIRTING_HEIGHTS,
        default="100",
    )

    # =====================================================
    # DEPTH RESIZER
    # =====================================================

    # First row (always shown) ...
    depth_cabinet: StringProperty(
        name="Cabinet Depth (mm)",
        description=CABINET_DEPTH_DESCRIPTION,
        default="",
    )

    depth_shelf: StringProperty(
        name="Shelf / Floor Depth (mm)",
        description=SHELF_DEPTH_DESCRIPTION,
        default="",
    )

    # ... plus any rows added with "Add depth"
    depth_rows: CollectionProperty(
        type=MO2WI_DepthItem
    )

    depth_exclude: StringProperty(
        name="Never Scale",
        description=(
            "Comma-separated; any object whose name contains one "
            "of these keeps its depth"
        ),
        default=DEPTH_RESIZE_EXCLUDE,
    )

    depth_axis: EnumProperty(
        name="Depth Axis",
        items=DEPTH_AXES,
        default="AUTO",
    )

    depth_rename: BoolProperty(
        name="Rename Objects (depth only)",
        description="Replace -<depth>-DC in the module / object names",
        default=True,
    )

    depth_selected_only: BoolProperty(
        name="Selected Objects Only",
        description="Resize only the selected meshes instead of the whole module",
        default=False,
    )

    depth_output_dir: StringProperty(
        name="Output",
        description="Folder Resize + Export All writes the .dae files to",
        default="//",
        subtype='DIR_PATH',
    )

    # =====================================================
    # WIDTH RESCALE
    # =====================================================

    # First row (always shown) ...
    width_cabinet: StringProperty(
        name="Cabinet Width (mm)",
        description=CABINET_WIDTH_DESCRIPTION,
        default="",
    )

    width_shelf: StringProperty(
        name="Shelf / Floor Width (mm)",
        description=SHELF_WIDTH_DESCRIPTION,
        default="",
    )

    # ... plus any rows added with "Add width"
    width_rows: CollectionProperty(
        type=MO2WI_WidthItem
    )

    width_exclude: StringProperty(
        name="Never Scale",
        description=(
            "Comma-separated; any object whose name contains one "
            "of these keeps its width (it still slides with its bay)"
        ),
        default=WIDTH_RESCALE_EXCLUDE,
    )

    width_rename: BoolProperty(
        name="Rename Objects (add width)",
        description="Add -<width>W to the module / object names",
        default=True,
    )

    width_selected_only: BoolProperty(
        name="Selected Objects Only",
        description="Rescale only the selected meshes instead of the whole module",
        default=False,
    )

    width_output_dir: StringProperty(
        name="Output",
        description="Folder Rescale + Export All writes the .dae files to",
        default="//",
        subtype='DIR_PATH',
    )

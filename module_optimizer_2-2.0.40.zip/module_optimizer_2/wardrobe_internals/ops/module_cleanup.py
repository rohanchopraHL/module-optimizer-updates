import bpy
import bmesh

from math import radians

from ..core.hierarchy import find_main_empty
from ..core.empty_part_finder import EmptyPartFinder


# =========================================================
# Scale Main Empty
# =========================================================

def scale_main_empty(main_empty):
    """
    Scale the module to 1 mm = 0.001, once only. The factor is
    measured from the module's height (250-3500 mm), so an FBX
    import at 0.01, a mm-authored module or one already in
    metres all come out right. Without meshes: the old fixed
    0.001 scale-down.

    apply_all_transforms() bakes this into the mesh and resets
    the object's scale field back to 1, so a plain scale-assign
    would silently re-shrink the geometry by 0.001x again on every
    repeat run. A custom property flag guards against that.

    Some modules' main group already sits at Scale X/Y/Z = 1,1,1
    (already correct, no mm-authoring correction needed) - skip
    the 0.001 scale-down for those instead of forcing it on.
    """

    if main_empty.get("wint_module_scaled"):
        return False

    # Measured (the former Scaling Reset): read the module's height and
    # rescale so 1 mm = 0.001, whatever scale the import left it at.
    from ..auto_optimizer import guess_scale

    meshes = [
        o for o in main_empty.children_recursive
        if o.type == 'MESH' and len(o.data.vertices)
    ]

    if meshes:

        factor = guess_scale(meshes) / 1000.0

        main_empty["wint_module_scaled"] = True

        if abs(factor - 1.0) < 1e-6:
            return False

        main_empty.scale = tuple(c * factor for c in main_empty.scale)

        return True

    if all(abs(component - 1.0) < 1e-6 for component in main_empty.scale):
        main_empty["wint_module_scaled"] = True
        return False

    main_empty.scale = (
        0.001,
        0.001,
        0.001,
    )

    main_empty["wint_module_scaled"] = True

    return True


# =========================================================
# Move Main Empty Out Of Import Collections
# =========================================================

def move_out_of_collections(context, main_empty):
    """
    Unlink the main group AND every one of its descendants
    from whatever import Collection(s) they're linked into
    (e.g. a SketchUp import's nested "SKP Mesh Objects"
    Collection under "SKP Imported Data") and relink them
    directly under the Scene Collection.

    A SketchUp-style import links every object in the
    hierarchy - not just the root Empty - into the same
    import Collection, so the whole hierarchy has to move
    out for that Collection to end up empty (and eligible
    for Delete Empty Groups' Collection cleanup). Blender
    parenting is independent of Collection membership, so
    this doesn't touch obj.parent at all.
    """

    scene_collection = context.scene.collection

    moved = False

    for obj in [main_empty] + main_empty.children_recursive:

        linked_collections = list(obj.users_collection)

        already_at_root = (
            len(linked_collections) == 1
            and linked_collections[0] is scene_collection
        )

        if already_at_root:
            continue

        moved = True

        for collection in linked_collections:

            if collection is not scene_collection:
                collection.objects.unlink(obj)

        if obj.name not in scene_collection.objects:
            scene_collection.objects.link(obj)

    return moved


# =========================================================
# Select Entire Module
# =========================================================

def select_module(context, main_empty):
    """
    Select main_empty and every recursive child, skipping
    any object not linked into the current View Layer
    (e.g. left behind in an excluded collection) instead of
    crashing the whole operator.

    Returns the names of any objects that were skipped.
    """

    bpy.ops.object.select_all(action='DESELECT')

    view_layer_objects = context.view_layer.objects

    skipped = []

    if main_empty.name in view_layer_objects:
        main_empty.select_set(True)
    else:
        skipped.append(main_empty.name)

    for obj in main_empty.children_recursive:

        if obj.name in view_layer_objects:
            obj.select_set(True)
        else:
            skipped.append(obj.name)

    context.view_layer.objects.active = main_empty

    return skipped


# =========================================================
# Apply All Transforms
# =========================================================

def apply_all_transforms():

    bpy.ops.object.transform_apply(
        location=True,
        rotation=True,
        scale=True
    )


# =========================================================
# Convert Triangles To Quads
# =========================================================

def convert_tris_to_quads(main_empty):
    """
    Merge triangulated faces back into quads on every
    mesh descendant of the module.
    """

    converted = 0

    for obj in main_empty.children_recursive:

        if obj.type != 'MESH':
            continue

        bm = bmesh.new()
        bm.from_mesh(obj.data)

        bmesh.ops.join_triangles(
            bm,
            faces=bm.faces,
            angle_face_threshold=radians(40),
            angle_shape_threshold=radians(40),
            cmp_seam=True,
            cmp_sharp=True,
            cmp_uvs=True,
            cmp_materials=True,
        )

        bm.to_mesh(obj.data)
        bm.free()

        obj.data.update()

        converted += 1

    return converted


# =========================================================
# Remove Materials
# =========================================================

def remove_materials(main_empty):

    for obj in main_empty.children_recursive:

        if obj.type != 'MESH':
            continue

        obj.data.materials.clear()


# =========================================================
# Remove Empty Parts
# =========================================================

def remove_empty_parts(main_empty):
    """
    Delete Part.xxx Empty objects that have
    no children (leftover placeholders).
    """

    empty_parts = EmptyPartFinder.find_empty_parts(
        main_empty
    )

    return EmptyPartFinder.delete_empty_parts(
        empty_parts
    )


# =========================================================
# Purge Orphan Data
# =========================================================

def purge_orphans():
    """
    Remove all unused data blocks
    from the Blender file.
    """

    bpy.ops.outliner.orphans_purge(
        do_local_ids=True,
        do_linked_ids=True,
        do_recursive=True,
    )


# =========================================================
# Module Cleanup
# =========================================================

class MO2WI_OT_ModuleCleanup(bpy.types.Operator):

    """Prepare Module"""

    bl_idname = "mo2wi.module_cleanup"

    bl_label = "Module Cleanup"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(context)

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Move Out Of Import Collections
        # -----------------------------------------

        move_out_of_collections(
            context,
            main_empty
        )

        # -----------------------------------------
        # Scale Main Empty
        # -----------------------------------------

        scaled = scale_main_empty(
            main_empty
        )

        # -----------------------------------------
        # Select Entire Module
        # -----------------------------------------

        skipped = select_module(
            context,
            main_empty
        )

        # -----------------------------------------
        # Apply All Transforms
        # -----------------------------------------

        apply_all_transforms()

        # -----------------------------------------
        # Convert Triangles to Quads
        # -----------------------------------------

        convert_tris_to_quads(
            main_empty
        )

        # -----------------------------------------
        # Remove Materials
        # -----------------------------------------

        remove_materials(
            main_empty
        )

        # -----------------------------------------
        # Remove Empty Parts
        # -----------------------------------------

        removed = remove_empty_parts(
            main_empty
        )

        # -----------------------------------------
        # Purge Orphan Data
        # -----------------------------------------

        purge_orphans()

        # -----------------------------------------
        # Success
        # -----------------------------------------

        message = (
            f"Module Cleanup Completed Successfully. "
            f"{removed} empty Part(s) removed."
        )

        if not scaled:

            message += (
                " Scale down skipped (already applied previously, "
                "or already at 1,1,1)."
            )

        if skipped:

            message += (
                f" {len(skipped)} object(s) skipped "
                f"(not in current View Layer)."
            )

        self.report(
            {'INFO'},
            message
        )

        return {'FINISHED'}

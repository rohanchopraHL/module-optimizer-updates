"""
============================================================
Wardrobe Internals

Hanger Rod

Import the bundled Hanger Rod asset - no Place On, no Module
Name selection needed (module root + reference face are both
found automatically, same "no selection needed" spirit as
Apply Module Name - the reference face is whichever mesh under
the root has the greatest X width, not a specifically-named
one). One click pops up a single dialog with Height, Full Rod /
Half Rod, and - only if Half Rod - which side (Left/Right) it's
flush with (invoke_props_dialog, same pattern as
hl_modules_optimizer's own Shutter/Countertop "Combine" dialogs)
- see core/hanger_rod.py for the placement math.
============================================================
"""

import os

import bpy

from ..config import HANGER_ROD_HEIGHTS

from ..core.common import make_name, next_index, parent_objects
from ..core.handle_library import get_handle_filepath
from ..core.hanger_rod import compute_rod_placement, find_widest_face

from .module_name import find_module_root

from .handle_library import (
    import_hardware_asset,
    resolve_asset_suffix,
)


# =========================================================
# Add Hanger Rod Operator
# =========================================================

class MO2WI_OT_AddHangerRod(bpy.types.Operator):
    """Import the Hanger Rod, sized against the module's widest face"""

    bl_idname = "mo2wi.add_hanger_rod"
    bl_label = "Add Hanger Rod"

    bl_options = {'REGISTER', 'UNDO'}

    height: bpy.props.EnumProperty(
        name="Height",
        items=[
            (str(height), f"{height}MM", "")
            for height in HANGER_ROD_HEIGHTS
        ],
        default=str(HANGER_ROD_HEIGHTS[0]),
    )

    rod_type: bpy.props.EnumProperty(
        name="Rod Type",
        items=[
            ('FULL', "Full Rod", "Width matches the module's widest face exactly"),
            ('HALF', "Half Rod", "Width is half the widest face, minus the center gap"),
        ],
        default='FULL',
    )

    z_location: bpy.props.EnumProperty(
        name="Z Location",
        items=[
            ('TOP', "Top", "Z = Height - 18 - 87 (mm)"),
            ('MID', "Mid", "Z = Height - 18 - 497 (mm)"),
        ],
        default='TOP',
    )

    side: bpy.props.EnumProperty(
        name="Side",
        items=[
            ('LEFT', "Left", "Flush with the widest face's left edge"),
            ('RIGHT', "Right", "Flush with the widest face's right edge"),
        ],
        default='LEFT',
    )

    def invoke(self, context, event):

        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):

        layout = self.layout

        layout.prop(self, "height")

        layout.prop(self, "rod_type")

        if self.rod_type == 'HALF':
            layout.prop(self, "side", expand=True)

        layout.prop(self, "z_location")

    def execute(self, context):

        props = context.scene.mo2wi

        # -----------------------------------------
        # Validate Asset
        # -----------------------------------------

        if props.handle_asset in ("", "NONE"):

            self.report(
                {'WARNING'},
                "Please select the Hanger Rod."
            )

            return {'CANCELLED'}

        filepath = get_handle_filepath(props.handle_asset)

        if not os.path.isfile(filepath):

            self.report(
                {'WARNING'},
                f"Hanger Rod file not found: {filepath}"
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Find Module Root + Widest Face (no selection needed)
        # -----------------------------------------

        root = find_module_root(context)

        if root is None:

            self.report(
                {'WARNING'},
                "Module root not found - the scene has no single "
                "top-level Empty with children. Select the module "
                "and try again."
            )

            return {'CANCELLED'}

        face = find_widest_face(root)

        if face is None:

            self.report(
                {'WARNING'},
                "No mesh geometry found in the module to size the "
                "Hanger Rod against."
            )

            return {'CANCELLED'}

        module_name = props.module_name.strip() or root.name

        # -----------------------------------------
        # Import FBX
        # -----------------------------------------

        rod = import_hardware_asset(context, filepath)

        if rod is None:

            self.report(
                {'WARNING'},
                "Hanger Rod import produced no objects."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Size + Position
        # -----------------------------------------

        height_mm = int(self.height)

        length, location = compute_rod_placement(
            face,
            height_mm,
            self.rod_type,
            self.side,
            self.z_location,
        )

        rod.dimensions = (length, rod.dimensions.y, rod.dimensions.z)
        rod.location = location

        # -----------------------------------------
        # Parent To Module Root
        # -----------------------------------------

        parent_objects(root, [rod])

        # -----------------------------------------
        # Rename
        # -----------------------------------------

        suffix = resolve_asset_suffix(props.handle_asset)

        rod.name = make_name(
            module_name,
            suffix,
            next_index(module_name, suffix)
        )

        # -----------------------------------------
        # Track In UI List
        # -----------------------------------------

        item = props.handle_objects.add()
        item.object = rod

        props.handle_active = len(props.handle_objects) - 1

        # -----------------------------------------
        # Select Result
        # -----------------------------------------

        bpy.ops.object.select_all(action='DESELECT')

        rod.select_set(True)
        context.view_layer.objects.active = rod

        # -----------------------------------------
        # Reset Asset For Next Item
        # -----------------------------------------

        props.handle_asset = "NONE"

        rod_label = (
            "Full Rod" if self.rod_type == 'FULL'
            else f"Half Rod ({self.side.title()})"
        )

        self.report(
            {'INFO'},
            f"Placed '{rod.name}' ({rod_label}, {height_mm}mm height, "
            f"{self.z_location.title()} Z, sized against '{face.name}')."
        )

        return {'FINISHED'}

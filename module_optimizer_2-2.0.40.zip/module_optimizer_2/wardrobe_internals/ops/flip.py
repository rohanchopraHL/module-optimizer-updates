"""
============================================================
Wardrobe Internals

Flip

Mirrors the module: sets the root's Scale to -1/-1/-1 and its
X Rotation to 180 degrees, then freezes that transform into
every mesh's vertex data (same core/freeze.freeze_hierarchy()
Set Pivot Point uses) and corrects the resulting inward-facing
normals in one pass (core/flip.flip_normals()).

Since freeze_hierarchy() always resets the root back to an
identity transform (Location 0, Rotation 0, Scale 1) once it's
done, each click starts from a clean slate - the button can be
used more than once (a 2nd click mirrors the already-mirrored
module back).
============================================================
"""

import bpy

from math import radians

from mathutils import Matrix

from ..core.hierarchy import find_main_empty
from ..core.freeze import freeze_hierarchy
from ..core.flip import flip_normals
from ..core.drawer_filler import (
    is_filler,
    is_drawer_part,
    flip_drawer_filler,
)

from .module_name import find_module_root


# =========================================================
# Flip Operator
# =========================================================

class MO2WI_OT_Flip(bpy.types.Operator):
    """Mirror the module (Scale -1/-1/-1, Rotate 180 on X), freeze the transform and correct normals"""

    bl_idname = "mo2wi.flip"
    bl_label = "Flip"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(context)

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # -----------------------------------------
        # Mirror The Root
        # -----------------------------------------

        if main_empty.rotation_mode != 'XYZ':
            main_empty.rotation_mode = 'XYZ'

        main_empty.scale = (-1.0, -1.0, -1.0)
        main_empty.rotation_euler.x = radians(180)

        context.view_layer.update()

        # -----------------------------------------
        # Freeze + Correct Normals
        # -----------------------------------------

        frozen = freeze_hierarchy(
            context,
            main_empty,
            Matrix.Identity(4),
        )

        flipped = flip_normals(main_empty)

        # -----------------------------------------
        # Reselect The Root
        # -----------------------------------------

        bpy.ops.object.select_all(action='DESELECT')

        if main_empty.name in context.view_layer.objects:
            main_empty.select_set(True)
            context.view_layer.objects.active = main_empty

        self.report(
            {'INFO'},
            f"Flipped module - {frozen} mesh(es) mirrored and re-frozen, "
            f"{flipped} normal(s) corrected."
        )

        return {'FINISHED'}


# =========================================================
# Flip Drawer Filler Operator
# =========================================================

class MO2WI_OT_FlipDrawerFiller(bpy.types.Operator):
    """Move the Drawer Filler to the other end of its drawer row: same-width drawers slide into its place, different-width drawers swap sides with it (selected fillers, or every filler in the module)"""

    bl_idname = "mo2wi.flip_drawer_filler"
    bl_label = "Flip Drawer Filler"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        root = find_module_root(context)

        if root is None:

            self.report(
                {'WARNING'},
                "Module root not found - select any object in the module."
            )

            return {'CANCELLED'}

        objects = list(root.children_recursive)

        fillers = [o for o in context.selected_objects if is_filler(o) and o in objects]

        if not fillers:
            fillers = [o for o in objects if is_filler(o)]

        if not fillers:

            self.report(
                {'WARNING'},
                "No Drawer Filler (_dwr-flr_) found in the module."
            )

            return {'CANCELLED'}

        drawers = [o for o in objects if is_drawer_part(o)]

        meshes = [o for o in objects if o.type == 'MESH']

        done = []

        for filler in fillers:

            try:
                info = flip_drawer_filler(filler, drawers, meshes)
            except ValueError as e:
                self.report({'WARNING'}, f"{e}.")
                return {'CANCELLED'}

            context.view_layer.update()

            done.append(
                f"{filler.name} -> {info['side'].lower()} "
                f"({info['width_mm']:.0f}mm; {info['moved']} drawer part(s) "
                + ("slid - same-width drawers" if info['mode'] == 'SLIDE'
                   else "mirrored - different-width drawers")
                + ")"
            )

        self.report({'INFO'}, "Flipped " + "; ".join(done) + ".")

        return {'FINISHED'}

"""
============================================================
Wardrobe Internals

Set Pivot Point

Puts the module root back at the world origin, centres the
internals on it in X / Y, and freezes the transform of every
object in the hierarchy - root, Part Empties and the combined
Face meshes all end up with Location 0/0/0, Rotation 0,
Scale 1 and no parent-inverse, with the geometry baked into
the mesh data at its world position.

Z is never touched: the panels keep the exact heights CleanUp
Module left them at (they sit "in the air" once the carcass
under them is gone, which is intentional).

The freeze is done by writing mesh vertex data and object
matrices directly - Object > Apply > Transform mangles a
parented Empty hierarchy.
============================================================
"""

import bpy

from mathutils import Vector, Matrix

from .module_name import find_module_root
from ..core.freeze import freeze_hierarchy


# =========================================================
# Floor Center Of Module
# =========================================================

HARDWARE_TAGS = ("_han_", "_h-rod_", "_lck_")


def compute_floor_center(main_empty):
    """
    World-space X / Y center of the mesh descendants' combined
    bounding box (panels only - handles / hanger rod / locks
    skipped), at Z = 0.

    Z is fixed at 0 rather than the lowest geometry so Set
    Pivot Point never changes how high the panels sit.
    """

    min_x = max_x = None
    min_y = max_y = None

    # The panels decide the centre - handles stick out of the front and
    # would pull it forward (and the hanger rod). Only if there is
    # nothing else do they count.
    meshes = [o for o in main_empty.children_recursive if o.type == 'MESH']
    panels = [o for o in meshes if not any(tag in o.name for tag in HARDWARE_TAGS)]

    for obj in panels or meshes:

        for corner in obj.bound_box:

            world_corner = obj.matrix_world @ Vector(corner)

            if min_x is None:

                min_x = max_x = world_corner.x
                min_y = max_y = world_corner.y

                continue

            min_x = min(min_x, world_corner.x)
            max_x = max(max_x, world_corner.x)
            min_y = min(min_y, world_corner.y)
            max_y = max(max_y, world_corner.y)

    if min_x is None:
        return None

    return Vector((
        (min_x + max_x) / 2.0,
        (min_y + max_y) / 2.0,
        0.0,
    ))


# =========================================================
# Set Pivot Point Operator
# =========================================================

class MO2WI_OT_SetPivotPoint(bpy.types.Operator):

    """Reset the module root to the world origin, centre the internals on it in X/Y, and freeze every transform - panel heights are kept"""

    bl_idname = "mo2wi.set_pivot_point"

    bl_label = "Set Pivot Point"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_module_root(context)

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Module root not found - select the module, or make "
                "sure the scene has a single top-level group."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Floor Center (X / Y only, Z stays put)
        # -----------------------------------------

        floor_center = compute_floor_center(
            main_empty
        )

        if floor_center is None:

            self.report(
                {'WARNING'},
                "No mesh geometry found in module."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Freeze The Hierarchy
        # -----------------------------------------

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        frozen = freeze_hierarchy(
            context,
            main_empty,
            Matrix.Translation(-floor_center),
        )

        # -----------------------------------------
        # Reselect The Root
        # -----------------------------------------

        bpy.ops.object.select_all(action='DESELECT')

        if main_empty.name in context.view_layer.objects:
            main_empty.select_set(True)
            context.view_layer.objects.active = main_empty

        self.report(
            {'INFO'},
            f"Pivot Point set - root at origin, {frozen} mesh(es) frozen, "
            "internals centred in X/Y, panel heights kept."
        )

        return {'FINISHED'}

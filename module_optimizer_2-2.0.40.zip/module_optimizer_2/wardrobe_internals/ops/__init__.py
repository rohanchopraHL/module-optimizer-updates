"""
Wardrobe Internals

Operators Package

Registers every operator the Wardrobe Internals panel exposes:
Module Cleanup, Delete Empty Groups, Set Pivot Point, Handle
Library, UV Checker and Collada export.
"""

import bpy

from .module_cleanup import MO2WI_OT_ModuleCleanup
from .module_name import MO2WI_OT_ModuleName
from .build_edgeband import (
    MO2WI_OT_BuildEdgeBand,
    MO2WI_OT_AssignFrontBack,
    MO2WI_OT_BuildEdgeBandAndFaces,
)
from .optimise_module import MO2WI_OT_OptimiseModule
from .delete_empty_groups import MO2WI_OT_DeleteEmptyGroups
from .set_pivot_point import MO2WI_OT_SetPivotPoint

from .panel_conventions import MO2WI_OT_PanelConvention

from .nudge import MO2WI_OT_NudgeUp

from .handle_library import (
    MO2WI_OT_SetHandleTarget,
    MO2WI_OT_ClearHandleTarget,
    MO2WI_OT_AddHandle,
    MO2WI_OT_RemoveHandle,
)

from .hanger_rod import MO2WI_OT_AddHangerRod

from .flip import MO2WI_OT_Flip, MO2WI_OT_FlipDrawerFiller

from .uv_checker import MO2WI_OT_Unwrap

from .export_collada import MO2WI_OT_ExportCollada

from .depth_resizer import (
    MO2WI_OT_DepthAdd,
    MO2WI_OT_DepthRemove,
    MO2WI_OT_ResizeDepth,
    MO2WI_OT_ResizeDepthExportAll,
)

from .width_rescale import (
    MO2WI_OT_WidthAdd,
    MO2WI_OT_WidthRemove,
    MO2WI_OT_RescaleWidth,
    MO2WI_OT_RescaleWidthExportAll,
)

# =========================================================
# Classes
# =========================================================

classes = (

    # STEP 1 : Module Cleanup
    MO2WI_OT_ModuleCleanup,
    MO2WI_OT_ModuleName,
    MO2WI_OT_OptimiseModule,
    MO2WI_OT_BuildEdgeBand,
    MO2WI_OT_AssignFrontBack,
    MO2WI_OT_BuildEdgeBandAndFaces,
    MO2WI_OT_DeleteEmptyGroups,
    MO2WI_OT_SetPivotPoint,

    # PANEL CONVENTIONS
    MO2WI_OT_PanelConvention,

    # NUDGE
    MO2WI_OT_NudgeUp,

    # HANDLE LIBRARY
    MO2WI_OT_SetHandleTarget,
    MO2WI_OT_ClearHandleTarget,
    MO2WI_OT_AddHandle,
    MO2WI_OT_RemoveHandle,

    # HANGER ROD
    MO2WI_OT_AddHangerRod,

    # FLIP
    MO2WI_OT_Flip,
    MO2WI_OT_FlipDrawerFiller,

    # UV CHECKER
    MO2WI_OT_Unwrap,

    # DEPTH RESIZER
    MO2WI_OT_DepthAdd,
    MO2WI_OT_DepthRemove,
    MO2WI_OT_ResizeDepth,
    MO2WI_OT_ResizeDepthExportAll,

    # WIDTH RESCALE
    MO2WI_OT_WidthAdd,
    MO2WI_OT_WidthRemove,
    MO2WI_OT_RescaleWidth,
    MO2WI_OT_RescaleWidthExportAll,

    # EXPORT
    MO2WI_OT_ExportCollada,
)


def register():

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

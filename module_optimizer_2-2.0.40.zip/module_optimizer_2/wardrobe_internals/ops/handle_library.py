"""
============================================================
Wardrobe Internals

Hardware Library

Responsibilities

- Assign / clear Handle Target
- Import a hardware asset from the library, positioned on the
  target's face (Left / Center / Right) and parented under the
  module's root Empty
- Auto-name placed items (ModuleName_han_01, _02, ... for
  Handles; ModuleName_h-rod_01, _02, ... for the Hanger Rod -
  see resolve_asset_suffix() below)
- Remove placed items
============================================================
"""

import os

import bpy

from mathutils import Vector

from ..config import (
    HANDLE_SUFFIX,
    HANDLE_LR_INSET_RATIO,
    HANGER_ROD_ASSET_NAME,
    HANGER_ROD_SUFFIX,
)

from ..core.common import (
    make_name,
    next_index,
    join_objects,
    parent_objects,
)

from ..core.handle_library import get_handle_filepath
from ..core.hierarchy import find_root_empty, find_topmost_ancestor


# =========================================================
# Asset Suffix
# =========================================================
# Most Hardware Library assets are Handles ("han"). A few
# aren't - matched here by filename (without extension) so
# they still use every existing Handle placement button
# instead of needing a separate UI section.

ASSET_SUFFIX_OVERRIDES = {
    HANGER_ROD_ASSET_NAME: HANGER_ROD_SUFFIX,
}


def resolve_asset_suffix(asset_filename):
    """
    Naming suffix for a Hardware Library asset - HANDLE_SUFFIX
    unless the asset's filename (without extension) matches one
    of ASSET_SUFFIX_OVERRIDES.
    """

    stem = os.path.splitext(asset_filename)[0]

    return ASSET_SUFFIX_OVERRIDES.get(stem, HANDLE_SUFFIX)


# =========================================================
# Import Hardware Asset
# =========================================================
# Shared by MO2WI_OT_AddHandle and MO2WI_OT_AddHangerRod
# (ops/hanger_rod.py) - both import an .fbx the same way, they
# just place/size the result differently afterward.

def import_hardware_asset(context, filepath):
    """
    Import filepath (an .fbx) and collapse the result to a
    single object - joining its meshes if it came in as several
    parts. Returns that object, or None if nothing was
    imported.
    """

    before = set(bpy.data.objects)

    bpy.ops.import_scene.fbx(filepath=filepath)

    imported = [
        obj for obj in bpy.data.objects
        if obj not in before
    ]

    if not imported:
        return None

    roots = [
        obj for obj in imported
        if obj.parent is None or obj.parent not in imported
    ]

    if len(roots) == 1:
        return roots[0]

    meshes = [
        obj for obj in imported
        if obj.type == 'MESH'
    ]

    return join_objects(context, meshes) if meshes else roots[0]


# =========================================================
# Resolve Module Name From Target
# =========================================================
# Shared by MO2WI_OT_AddHandle and MO2WI_OT_AddHangerRod.

def resolve_module_name_from_target(props, target):
    """
    Module Name field first (Step 2 workflow), falling back to
    target's own root Empty / topmost ancestor name - Existing
    Module has no Step 2 field to read.
    """

    module_name = props.module_name.strip()

    if module_name:
        return module_name

    root = find_root_empty(target)

    if root is not None:
        return root.name

    top = find_topmost_ancestor(target)

    if top is not None and top is not target:
        return top.name

    return ""


# =========================================================
# Handle Location
# =========================================================

def compute_handle_location(obj, position):
    """
    World-space drop point on the target's front face - the face
    on its -Y side.

    Y is always pinned to the -Y extreme (min Y) so the handle
    sits on the front surface, not buried at mid-thickness, and Z
    is always the bounding-box centre. X depends on `position`:

    - CENTER: the target's own X centre.
    - LEFT / RIGHT: inset in from that edge by
      HANDLE_LR_INSET_RATIO (10%) of the target's own width, so
      the handle sits near - not flush against - the edge.
    """

    if obj.type != 'MESH' or not obj.bound_box:
        return obj.matrix_world.translation.copy()

    corners = [
        obj.matrix_world @ Vector(corner)
        for corner in obj.bound_box
    ]

    xs = [c.x for c in corners]
    ys = [c.y for c in corners]
    zs = [c.z for c in corners]

    min_x, max_x = min(xs), max(xs)
    front_y = min(ys)
    center_z = (min(zs) + max(zs)) / 2.0

    inset = (max_x - min_x) * HANDLE_LR_INSET_RATIO

    if position == 'LEFT':
        x = min_x + inset
    elif position == 'RIGHT':
        x = max_x - inset
    else:
        x = (min_x + max_x) / 2.0

    return Vector((x, front_y, center_z))


# =========================================================
# Set Handle Target
# =========================================================

class MO2WI_OT_SetHandleTarget(bpy.types.Operator):
    """Assign selected object as the Handle Target"""

    bl_idname = "mo2wi.set_handle_target"
    bl_label = "Use Selected Object"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        props = context.scene.mo2wi

        obj = context.active_object

        if obj is None:

            self.report(
                {'WARNING'},
                "Please select the object the handle goes on."
            )

            return {'CANCELLED'}

        props.handle_target = obj

        self.report(
            {'INFO'},
            f"Handle will be placed on '{obj.name}'."
        )

        return {'FINISHED'}


# =========================================================
# Clear Handle Target
# =========================================================

class MO2WI_OT_ClearHandleTarget(bpy.types.Operator):
    """Clear Handle Target"""

    bl_idname = "mo2wi.clear_handle_target"
    bl_label = "Clear Handle Target"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        context.scene.mo2wi.handle_target = None

        self.report(
            {'INFO'},
            "Handle Target cleared."
        )

        return {'FINISHED'}


# =========================================================
# Add Handle
# =========================================================

class MO2WI_OT_AddHandle(bpy.types.Operator):
    """Import the selected handle asset onto the target face"""

    bl_idname = "mo2wi.add_handle"
    bl_label = "Add Handle"

    bl_options = {'REGISTER', 'UNDO'}

    # Set per-button (Left / Center / Right) in ui/handle.py,
    # same "one operator, args set from the UI call" pattern
    # MO2WI_OT_PanelConvention uses for its `suffix`/`combine`.
    position: bpy.props.EnumProperty(
        items=[
            ('LEFT', "Left", ""),
            ('CENTER', "Center", ""),
            ('RIGHT', "Right", ""),
        ],
        default='CENTER',
        options={'HIDDEN'},
    )

    def execute(self, context):

        props = context.scene.mo2wi

        # -----------------------------------------
        # Validate Handle Target
        # -----------------------------------------

        if props.handle_target is None:

            self.report(
                {'WARNING'},
                "Please set where the handle goes (Place On)."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Resolve Module Name
        # -----------------------------------------

        module_name = resolve_module_name_from_target(props, props.handle_target)

        if not module_name:

            self.report(
                {'WARNING'},
                "Please enter a Module Name."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Validate Handle Asset
        # -----------------------------------------

        if props.handle_asset in ("", "NONE"):

            self.report(
                {'WARNING'},
                "Please select a Handle."
            )

            return {'CANCELLED'}

        filepath = get_handle_filepath(props.handle_asset)

        if not os.path.isfile(filepath):

            self.report(
                {'WARNING'},
                f"Handle file not found: {filepath}"
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Import FBX
        # -----------------------------------------

        handle = import_hardware_asset(context, filepath)

        if handle is None:

            self.report(
                {'WARNING'},
                "Handle import produced no objects."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Position At Target Face
        # -----------------------------------------

        handle.location = compute_handle_location(
            props.handle_target,
            self.position,
        )

        # -----------------------------------------
        # Parent To Module Root
        # -----------------------------------------

        root = find_root_empty(props.handle_target)

        parent_objects(
            root if root is not None else props.handle_target,
            [handle]
        )

        # -----------------------------------------
        # Rename
        # -----------------------------------------

        suffix = resolve_asset_suffix(props.handle_asset)

        handle.name = make_name(
            module_name,
            suffix,
            next_index(module_name, suffix)
        )

        # -----------------------------------------
        # Track In UI List
        # -----------------------------------------

        item = props.handle_objects.add()
        item.object = handle

        props.handle_active = len(props.handle_objects) - 1

        # -----------------------------------------
        # Select Result
        # -----------------------------------------

        bpy.ops.object.select_all(action='DESELECT')

        handle.select_set(True)
        context.view_layer.objects.active = handle

        # -----------------------------------------
        # Reset Target / Asset For Next Handle
        # -----------------------------------------

        props.handle_target = None
        props.handle_asset = "NONE"

        self.report(
            {'INFO'},
            f"Placed handle '{handle.name}'."
        )

        return {'FINISHED'}


# =========================================================
# Remove Handle
# =========================================================

class MO2WI_OT_RemoveHandle(bpy.types.Operator):
    """Delete a placed handle from the scene"""

    bl_idname = "mo2wi.remove_handle"
    bl_label = "Remove Handle"

    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):

        props = context.scene.mo2wi

        if self.index < 0 or self.index >= len(props.handle_objects):

            self.report(
                {'WARNING'},
                "Invalid handle index."
            )

            return {'CANCELLED'}

        item = props.handle_objects[self.index]

        if item.object is not None:
            bpy.data.objects.remove(item.object, do_unlink=True)

        props.handle_objects.remove(self.index)

        props.handle_active = min(
            props.handle_active,
            len(props.handle_objects) - 1
        )

        self.report(
            {'INFO'},
            "Handle removed."
        )

        return {'FINISHED'}

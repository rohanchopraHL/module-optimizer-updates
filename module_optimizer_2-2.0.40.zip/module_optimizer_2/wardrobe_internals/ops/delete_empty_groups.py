"""
============================================================
Wardrobe Internals

Delete Empty Groups

Deletes every Empty object in the scene that has no
children, regardless of name or hierarchy.
============================================================
"""

import bpy

from ..config import PART_PREFIX

from .module_name import find_module_root
from .module_cleanup import move_out_of_collections


# =========================================================
# Find Empty Groups
# =========================================================

def find_empty_groups(scene):
    """
    obj.children is a cached/derived list that Blender does
    not refresh synchronously after a script reassigns
    obj.parent (even view_layer.update() does not force it).
    Scan live obj.parent links instead so freshly emptied
    groups are detected right after Apply Convention.
    """

    parents_with_children = {
        obj.parent
        for obj in scene.objects
        if obj.parent is not None
    }

    return [
        obj
        for obj in scene.objects
        if obj.type == 'EMPTY' and obj not in parents_with_children
    ]


# =========================================================
# Diagnostic Dump
# =========================================================

def print_part_diagnostics(scene):
    """
    Print type / child count / parent for every Part.xxx
    object in the scene, to the System Console, so a
    mismatch (wrong type, unexpected children, wrong
    scene) is visible without touching the Python console.
    """

    print("=" * 70)
    print("WINT Delete Empty Groups : Part diagnostic")
    print("=" * 70)

    found = False

    child_counts = {}

    for obj in scene.objects:

        if obj.parent is not None:
            child_counts[obj.parent] = (
                child_counts.get(obj.parent, 0) + 1
            )

    for obj in scene.objects:

        if not obj.name.startswith(PART_PREFIX):
            continue

        found = True

        parent_name = obj.parent.name if obj.parent else None

        print(
            f"{obj.name:24} type={obj.type:8} "
            f"children={child_counts.get(obj, 0):3} "
            f"parent={parent_name}"
        )

    if not found:
        print(f"No objects starting with '{PART_PREFIX}' in scene.objects.")

    print("=" * 70)


# =========================================================
# Delete Empty Groups
# =========================================================

def delete_empty_groups(empty_groups):

    deleted = 0

    for obj in empty_groups:

        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)
            deleted += 1

    return deleted


# =========================================================
# Delete Empty Collections
# =========================================================

def delete_empty_collections(scene):
    """
    Recursively delete every Collection under the Scene
    Collection (e.g. a SketchUp import's "SKP Imported Data" /
    "SKP Mesh Objects" / "SKP Components" groups) that ends up
    holding no objects and no child Collections.

    Children are processed first (bottom-up) so a collection
    left empty only after its own empty sub-collections are
    removed also gets deleted in the same pass.

    Walks the actual Collection data (scene.collection.children)
    rather than the View Layer's LayerCollection tree, so a
    collection is deleted whether its View Layer Exclude
    checkbox, or its Hide in Viewport / Disable in Renders
    visibility, is on or off - none of that affects whether it
    actually holds any objects.
    """

    deleted = []

    def process(collection):

        for child in list(collection.children):

            process(child)

            if len(child.objects) == 0 and len(child.children) == 0:

                child_name = child.name

                collection.children.unlink(child)
                bpy.data.collections.remove(child)
                deleted.append(child_name)

    process(scene.collection)

    return deleted


# =========================================================
# Delete Empty Groups Operator
# =========================================================

class MO2WI_OT_DeleteEmptyGroups(bpy.types.Operator):
    """Remove the outer shell (sides, top, bottom, divider, back panels, doors), then delete every Empty with no children, scene-wide"""

    bl_idname = "mo2wi.delete_empty_groups"
    bl_label = "Delete Empty Groups/Remove Shell"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # Remove Shell first (the former Auto Optimize button) - the
        # groups it empties are then deleted below.
        from ..auto_optimizer import remove_shell

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        shell_parts, shell_meshes = remove_shell(context)

        shell_msg = (
            f"Shell removed: {shell_parts} part(s) ({shell_meshes} mesh(es)). "
            if shell_parts else ""
        )

        print_part_diagnostics(
            context.scene
        )

        # A SketchUp import leaves the module hierarchy linked
        # inside nested import Collections ("SKP Imported Data" /
        # "SKP Components" / ...). Those Collections can never go
        # empty while the module still sits in them, so move the
        # whole hierarchy out to the Scene Collection first - same
        # step CleanUp Module runs. Best effort: if there's no
        # single module root, just fall through to the deletions.

        moved_out = False

        module_root = find_module_root(context)

        if module_root is not None:
            moved_out = move_out_of_collections(
                context,
                module_root
            )

        empty_groups = find_empty_groups(
            context.scene
        )

        deleted = delete_empty_groups(
            empty_groups
        )

        deleted_collections = delete_empty_collections(
            context.scene
        )

        if not deleted and not deleted_collections:

            message = "No empty groups found."

            if moved_out:

                message = (
                    "Module moved into the Scene Collection. "
                    "No empty groups or Collections left to delete."
                )

            self.report(
                {'INFO'},
                shell_msg + message
            )

            return {'FINISHED'}

        message = shell_msg + f"{deleted} empty group(s) deleted."

        if deleted_collections:

            message += (
                f" {len(deleted_collections)} empty Collection(s) "
                f"deleted."
            )

        if moved_out:

            message += (
                " Module moved out of its import Collection(s) into "
                "the Scene Collection."
            )

        self.report(
            {'INFO'},
            message
        )

        return {'FINISHED'}

"""
============================================================
Wardrobe Internals

Module Name

Renames the module's main group (its root Empty) to the name
typed in the panel. No selection needed - the root is found
automatically:

1. the top-most Empty above the active object, if there is one
   and it has children, otherwise
2. the single top-level Empty in the scene that has children.

If neither resolves (nothing active and more than one such
Empty), the user is asked to select the module first.

Also renames every already-named Panel Convention / Handle
object under the root (anything starting with the OLD module
name, e.g. "OldName_fxd-shlf_01") to carry the new name instead
("NewName_fxd-shlf_01") - so re-typing the Name field and
clicking Apply Module Name again re-labels the whole module,
not just the root, if conventions were already applied under
the old name.
============================================================
"""

import bpy

from ..config import NAME_SEPARATOR

from ..core.hierarchy import find_root_empty


# =========================================================
# Find The Module Root (No Selection Required)
# =========================================================

def find_module_root(context):
    """
    Locate the module's root Empty without relying on a
    current selection - see this module's docstring.
    """

    obj = context.active_object

    if obj is not None:

        root = find_root_empty(obj)

        if root is not None and len(root.children) > 0:
            return root

    candidates = [
        candidate
        for candidate in context.scene.objects
        if candidate.parent is None
        and candidate.type == 'EMPTY'
        and len(candidate.children) > 0
    ]

    if len(candidates) == 1:
        return candidates[0]

    return None


# =========================================================
# Unhide In Viewport
# =========================================================

def unhide_in_viewport(context, root):
    """
    Make sure the main group is visible in the viewport once
    it's been named - a SketchUp import can leave the root
    Empty hidden, either via "Disable in Viewports" (saved on
    the object itself) or the per-View-Layer "Hide in
    Viewport" eye toggle.

    hide_set() only works for an object that actually has a
    base in the current View Layer (e.g. not still sitting in
    an Excluded-from-View-Layer import Collection) - guarded
    so this never errors on that case.
    """

    unhidden = False

    if root.hide_viewport:
        root.hide_viewport = False
        unhidden = True

    if root.name in context.view_layer.objects and root.hide_get():
        root.hide_set(False)
        unhidden = True

    return unhidden


# =========================================================
# Rename Prefixed Descendants
# =========================================================

def rename_prefixed_descendants(root, old_name, new_name):
    """
    Rename every descendant under root whose name starts with
    "<old_name>_" to start with "<new_name>_" instead, keeping
    everything after that prefix untouched (suffix + index) -
    e.g. "OldName_fxd-shlf_01" -> "NewName_fxd-shlf_01". Covers
    any Panel Convention / Handle object already named under
    the module's previous name.

    Returns the number of objects renamed.
    """

    if not old_name or old_name == new_name:
        return 0

    prefix = old_name + NAME_SEPARATOR

    renamed = 0

    for obj in root.children_recursive:

        if not obj.name.startswith(prefix):
            continue

        obj.name = new_name + NAME_SEPARATOR + obj.name[len(prefix):]

        renamed += 1

    return renamed


# =========================================================
# Apply Module Name Operator
# =========================================================

class MO2WI_OT_ModuleName(bpy.types.Operator):

    """Rename the module's main group (root Empty) to the Module Name - no selection needed"""

    bl_idname = "mo2wi.module_name"

    bl_label = "Apply Module Name"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        props = context.scene.mo2wi

        name = props.module_name.strip()

        if not name:

            self.report(
                {'WARNING'},
                "Please enter a Module Name."
            )

            return {'CANCELLED'}

        root = find_module_root(context)

        if root is None:

            self.report(
                {'WARNING'},
                "Module root not found - the scene has no single "
                "top-level Empty with children. Select the module "
                "and try again."
            )

            return {'CANCELLED'}

        old_name = root.name

        root.name = name

        renamed = rename_prefixed_descendants(root, old_name, root.name)

        unhidden = unhide_in_viewport(context, root)

        if renamed:

            message = (
                f"Renamed main group '{old_name}' to '{root.name}', "
                f"and {renamed} convention object(s) under it."
            )

        else:

            message = f"Renamed main group '{old_name}' to '{root.name}'."

        if unhidden:

            message += " Main group enabled in the viewport."

        self.report(
            {'INFO'},
            message
        )

        return {'FINISHED'}

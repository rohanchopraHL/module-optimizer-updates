import bpy

from .module_name import find_module_root

from .module_cleanup import (
    move_out_of_collections,
    scale_main_empty,
    select_module,
    apply_all_transforms,
    convert_tris_to_quads,
    remove_materials,
    remove_empty_parts,
    purge_orphans,
)

from .delete_empty_groups import delete_empty_collections


# =========================================================
# Optimise Module Operator
# =========================================================

class MO2WI_OT_OptimiseModule(bpy.types.Operator):
    """
    CleanUp Module for wardrobe internals.

    Scale (measured - the former Scaling Reset), transforms,
    tris to quads, delete all materials, remove empty Parts.
    Never deletes or joins meshes.
    """

    bl_idname = "mo2wi.optimise_module"

    bl_label = "CleanUp Module"

    bl_options = {
        'REGISTER',
        'UNDO',
    }

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_module_root(
            context
        )

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Module root not found - select the module, or make "
                "sure the scene has a single top-level group."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Module Cleanup
        # -----------------------------------------

        # Scene units to millimetres, the same as Cabinets / Wardrobes.
        from ...core.cleanup import set_scene_units_mm

        set_scene_units_mm(context)

        moved_out = move_out_of_collections(
            context,
            main_empty
        )

        deleted_collections = delete_empty_collections(
            context.scene
        )

        scaled = scale_main_empty(
            main_empty
        )

        skipped = select_module(
            context,
            main_empty
        )

        apply_all_transforms()

        convert_tris_to_quads(
            main_empty
        )

        remove_materials(
            main_empty
        )

        removed = remove_empty_parts(
            main_empty
        )

        purge_orphans()

        # No mesh is deleted or joined here any more: the shell goes with
        # Delete Empty Groups/Remove Shell, and Auto Optimize needs the
        # Part groups as imported. (core/strip_internals.py is kept but
        # no longer run.)

        # -----------------------------------------
        # Success
        # -----------------------------------------

        message = (
            f"CleanUp Module Completed Successfully. "
            + ("Scaled to 1 mm = 0.001, " if scaled else "")
            + f"materials removed, {removed} empty Part(s) removed."
        )

        if moved_out:

            message += (
                " Main group moved out of its import Collection(s) "
                "into the Scene Collection."
            )

        if deleted_collections:

            message += (
                f" {len(deleted_collections)} empty import "
                f"Collection(s) deleted."
            )

        if not scaled:

            message += " Scale already right (1 mm = 0.001)."

        if skipped:

            message += (
                f" {len(skipped)} object(s) skipped "
                f"(not in current View Layer)."
            )

        self.report(
            {'INFO'},
            message
        )

        return {'FINISHED'}

"""
============================================================
Wardrobe Internals

Depth Resizer Operators

Rows are typed in by hand: Cabinet Depth (used for renaming,
-450-DC -> -400-DC) and Shelf / Floor Depth (the depth the
module is rescaled to). Row 0 is the always-visible first row
on MO2WI_Properties, rows 1.. are MO2WI_Properties.depth_rows.

- Add Depth           : add an empty row.
- Remove Depth        : remove a row (row 0 is just cleared).
- Resize Depth        : resize the module to one row
                        (core/depth_resizer.py).
- Resize + Export All : for every filled row, resize from the
                        ORIGINAL geometry, rename, and export a
                        .dae to the Output folder - then put the
                        module back exactly as it was.

The row parsing, module lookup and export-all loop are shared
with Width Rescale (ops/width_rescale.py).

The module root is found without a selection (same lookup as
Apply Module Name).
============================================================
"""

import os

import bpy

from bpy.props import IntProperty

from ..config import COLLADA_EXPORT_SCALE

from ..core.depth_resizer import (
    module_meshes,
    parse_exclude,
    resize_depth,
    rename_for_depth,
    take_snapshot,
    restore_snapshot,
    world_points,
    detect_layout,
)

from .module_name import find_module_root
from .export_collada import export_module


# =========================================================
# Rows (shared)
# =========================================================

def row_texts(props, first_cabinet, first_shelf, rows, cabinet_attr, shelf_attr):
    """
    Every row as (cabinet_text, shelf_text) - the always-visible
    first row (on props) first, then the added rows.
    """

    texts = [(getattr(props, first_cabinet), getattr(props, first_shelf))]

    texts += [
        (getattr(item, cabinet_attr), getattr(item, shelf_attr))
        for item in getattr(props, rows)
    ]

    return texts


def parse_row(cabinet_text, shelf_text, what="Depth"):
    """
    Return (cabinet:int, shelf:float), None for an untouched
    (both empty) row. Raises ValueError with a readable message
    if a value isn't a positive number.
    """

    cabinet_text = cabinet_text.strip()
    shelf_text = shelf_text.strip()

    if not cabinet_text and not shelf_text:
        return None

    try:
        cabinet = int(cabinet_text)
    except ValueError:
        raise ValueError(
            f"Cabinet {what} '{cabinet_text}' is not a whole number"
        )

    try:
        shelf = float(shelf_text)
    except ValueError:
        raise ValueError(
            f"Shelf / Floor {what} '{shelf_text}' is not a number"
        )

    if cabinet <= 0 or shelf <= 0.0:
        raise ValueError(f"{what}s must be greater than 0")

    return cabinet, shelf


def depth_row_texts(props):

    return row_texts(
        props, "depth_cabinet", "depth_shelf",
        "depth_rows", "cabinet_depth", "shelf_depth",
    )


# =========================================================
# Module (shared)
# =========================================================

def resolve_module(operator, context, selected_only):
    """
    Return (root, meshes) or report and return (None, None).
    """

    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    root = find_module_root(context)

    if root is None:

        operator.report(
            {'WARNING'},
            "Module root not found - select any object in the module."
        )

        return None, None

    meshes = module_meshes(
        root,
        selected_only,
        context.selected_objects,
    )

    if not meshes:

        operator.report(
            {'WARNING'},
            "No mesh objects found in the module."
        )

        return None, None

    return root, meshes


# =========================================================
# Single Row / Export All (shared)
# =========================================================

def run_single(operator, context, texts, index, what, selected_only, apply_row):
    """
    Parse row `index` and apply it. apply_row(context, root,
    meshes, cabinet, shelf) returns an info message.
    """

    if not (0 <= index < len(texts)):
        return {'CANCELLED'}

    try:
        values = parse_row(*texts[index], what=what)
    except ValueError as e:
        operator.report({'WARNING'}, f"{e}.")
        return {'CANCELLED'}

    if values is None:

        operator.report(
            {'WARNING'},
            f"Type the Cabinet {what} and the Shelf / Floor {what} first."
        )

        return {'CANCELLED'}

    root, meshes = resolve_module(operator, context, selected_only)

    if root is None:
        return {'CANCELLED'}

    try:
        message = apply_row(context, root, meshes, *values)
    except ValueError as e:
        operator.report({'WARNING'}, f"{e}.")
        return {'CANCELLED'}

    operator.report({'INFO'}, message)

    return {'FINISHED'}


def run_export_all(operator, context, texts, what, selected_only, output_dir, apply_row):
    """
    For every filled row: restore the original module, apply the
    row, export <root name>.dae to output_dir. The module is put
    back exactly as it was afterwards.
    """

    rows = []

    try:

        for row in texts:

            values = parse_row(*row, what=what)

            if values is not None:
                rows.append(values)

    except ValueError as e:

        operator.report({'WARNING'}, f"{e}.")

        return {'CANCELLED'}

    if not rows:

        operator.report(
            {'WARNING'},
            f"Type at least one Cabinet {what} and Shelf / Floor {what}."
        )

        return {'CANCELLED'}

    if output_dir.startswith("//") and not bpy.data.filepath:

        operator.report(
            {'WARNING'},
            "Pick an Output folder (or save the .blend first)."
        )

        return {'CANCELLED'}

    out_dir = bpy.path.abspath(output_dir)

    os.makedirs(out_dir, exist_ok=True)

    root, meshes = resolve_module(operator, context, selected_only)

    if root is None:
        return {'CANCELLED'}

    # In-scene modules are in metres -> export at mm scale like
    # the Export button; a re-imported .dae is already in mm.
    _, _, units_per_mm = detect_layout(
        {obj: world_points(obj) for obj in meshes},
        context.scene.mo2wi.depth_axis,
    )

    export_scale = COLLADA_EXPORT_SCALE if units_per_mm < 1.0 else None

    snapshot = take_snapshot(root, meshes)

    original_name = root.name

    written = []

    try:

        for cabinet, shelf in rows:

            restore_snapshot(snapshot)

            context.view_layer.update()

            apply_row(context, root, meshes, cabinet, shelf)

            file_name = root.name

            if file_name == original_name:
                file_name = f"{original_name}_{cabinet}"

            filepath = os.path.join(out_dir, file_name + ".dae")

            export_module(
                context,
                root,
                filepath,
                scale=export_scale,
            )

            written.append(os.path.basename(filepath))

    except Exception as e:

        operator.report(
            {'WARNING'},
            f"Stopped after {len(written)} file(s): {e}"
        )

        return {'CANCELLED'}

    finally:

        restore_snapshot(snapshot)

        context.view_layer.update()

    operator.report(
        {'INFO'},
        f"Exported {len(written)} file(s) to {out_dir}: "
        + ", ".join(written)
    )

    return {'FINISHED'}


# =========================================================
# Depth
# =========================================================

def apply_depth_row(context, root, meshes, cabinet_depth, shelf_depth):

    props = context.scene.mo2wi

    info = resize_depth(
        meshes,
        shelf_depth,
        parse_exclude(props.depth_exclude),
        props.depth_axis,
    )

    if props.depth_rename:
        rename_for_depth(
            [root] + list(root.children_recursive),
            cabinet_depth,
        )

    context.view_layer.update()

    return (
        f"Depth {info['from_mm']:.1f} -> {shelf_depth:.1f} mm "
        f"(back moved {info['moved_mm']:.1f} mm along "
        f"{info['axis']}); {len(meshes)} mesh(es); "
        f"{info['skipped_tris']} zero-area tri(s) skipped."
    )


class MO2WI_OT_DepthAdd(bpy.types.Operator):
    """Add an empty depth row"""

    bl_idname = "mo2wi.depth_add"
    bl_label = "Add Depth"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        context.scene.mo2wi.depth_rows.add()

        return {'FINISHED'}


class MO2WI_OT_DepthRemove(bpy.types.Operator):
    """Remove this depth row (the first row is just cleared)"""

    bl_idname = "mo2wi.depth_remove"
    bl_label = "Remove Depth"

    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=0)

    def execute(self, context):

        props = context.scene.mo2wi

        if self.index == 0:

            props.depth_cabinet = ""
            props.depth_shelf = ""

            return {'FINISHED'}

        if not (1 <= self.index <= len(props.depth_rows)):
            return {'CANCELLED'}

        props.depth_rows.remove(self.index - 1)

        return {'FINISHED'}


class MO2WI_OT_ResizeDepth(bpy.types.Operator):
    """Resize the module to this row: rename with Cabinet Depth, rescale to Shelf / Floor Depth"""

    bl_idname = "mo2wi.resize_depth"
    bl_label = "Resize Depth"

    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=0)

    def execute(self, context):

        props = context.scene.mo2wi

        return run_single(
            self, context,
            depth_row_texts(props), self.index, "Depth",
            props.depth_selected_only, apply_depth_row,
        )


class MO2WI_OT_ResizeDepthExportAll(bpy.types.Operator):
    """Resize to every filled depth row in turn and export each one as a .dae, then restore the original module"""

    bl_idname = "mo2wi.resize_depth_export_all"
    bl_label = "Resize + Export All"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        props = context.scene.mo2wi

        return run_export_all(
            self, context,
            depth_row_texts(props), "Depth",
            props.depth_selected_only, props.depth_output_dir,
            apply_depth_row,
        )

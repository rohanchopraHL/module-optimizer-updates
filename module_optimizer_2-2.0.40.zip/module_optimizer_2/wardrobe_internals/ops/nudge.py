"""
============================================================
Wardrobe Internals

Nudge

Moves the current selection straight up (world +Z) by a fixed
distance (config.NUDGE_UP_MM), same 2-input-mode pattern as
Panel Conventions (ops/panel_conventions.py):

- New Module (still one combined mesh) - select faces in Edit
  Mode, Face select: only those faces' vertices move.
- Existing Module (panels already their own objects) - select
  one or more whole objects in Object Mode: each object moves.
============================================================
"""

import bpy

from ..config import NUDGE_UP_MM

from ..core.panel_conventions import has_selected_faces

from ..core.nudge import (
    resolve_world_offset,
    nudge_edit_faces,
    nudge_objects,
)


# =========================================================
# Nudge Up Operator
# =========================================================

class MO2WI_OT_NudgeUp(bpy.types.Operator):
    """Move the selected faces/objects straight up by a fixed distance"""

    bl_idname = "mo2wi.nudge_up"
    bl_label = "Nudge Up"

    bl_options = {'REGISTER', 'UNDO'}

    distance_mm: bpy.props.FloatProperty(
        default=NUDGE_UP_MM,
        options={'HIDDEN'},
    )

    def execute(self, context):

        active = context.active_object

        edit_mode_faces = (
            active is not None
            and active.type == 'MESH'
            and active.mode == 'EDIT'
        )

        if edit_mode_faces:

            if not has_selected_faces(active):

                self.report(
                    {'WARNING'},
                    "Select faces first."
                )

                return {'CANCELLED'}

            offset = resolve_world_offset(active, self.distance_mm)

            moved = nudge_edit_faces(active, offset)

            unit = "face vertex" if moved == 1 else "face vertices"

        else:

            objects = [
                obj for obj in context.selected_objects
                if obj.type == 'MESH'
            ]

            if not objects:

                self.report(
                    {'WARNING'},
                    "Select faces (Edit Mode) or objects first."
                )

                return {'CANCELLED'}

            offset = resolve_world_offset(objects, self.distance_mm)

            moved = nudge_objects(objects, offset)

            unit = "object" if moved == 1 else "objects"

        self.report(
            {'INFO'},
            f"Nudged {moved} {unit} up {self.distance_mm:g}mm."
        )

        return {'FINISHED'}

"""
============================================================
Wardrobe Internals

Collada Export

Temporarily sets the module root Empty's scale to
1000 / 1000 / 1000 (mm-scale output), exports the module
to a .dae file, then restores the root's original scale.

Uses Blender's native bpy.ops.wm.collada_export when
available. Recent Blender releases (5.0+) no longer bundle
Collada support, so this falls back to a pure-Python COLLADA
writer (core/dae_export_fallback.py) in that case.
============================================================
"""

import bpy

from bpy.props import StringProperty

from bpy_extras.io_utils import ExportHelper

from ..config import (
    COLLADA_EXPORT_SCALE,
    COLLADA_FORWARD_AXIS,
    COLLADA_UP_AXIS,
)

from ..core.hierarchy import find_main_empty
from ..core.dae_export_fallback import DaeExporter
from .module_cleanup import select_module


# =========================================================
# Export Helpers
# =========================================================

def export_native(filepath):
    """
    Try Blender's built-in Collada exporter.

    Returns True on success, False if the operator isn't
    available in this Blender build (AttributeError),
    raises on any other export failure.
    """

    try:

        result = bpy.ops.wm.collada_export(

            filepath=filepath,

            selected=True,
            include_children=False,
            include_armatures=False,
            include_shapekeys=False,

            apply_global_orientation=True,
            export_global_forward_selection=COLLADA_FORWARD_AXIS,
            export_global_up_selection=COLLADA_UP_AXIS,

            use_texture_copies=False,
            active_uv_only=False,
            include_animations=False,

        )

    except AttributeError:
        return False

    if 'FINISHED' not in result:
        raise RuntimeError("native Collada export did not finish")

    return True


def export_fallback(context, filepath):
    """
    Pure-Python COLLADA writer used when the native
    operator isn't available in this Blender build.
    """

    exporter = DaeExporter(

        context,
        filepath,

        to_forward=COLLADA_FORWARD_AXIS,
        to_up=COLLADA_UP_AXIS,

        export_materials=True,
        copy_textures=False,

    )

    exporter.export()


def export_module(context, main_empty, filepath, scale=COLLADA_EXPORT_SCALE):
    """
    Select the whole module, temporarily set the root's scale
    (None = leave it as-is), export, then restore the scale.

    Returns True if the pure-Python fallback was used. Raises
    on export failure (the scale is restored either way).
    """

    select_module(
        context,
        main_empty
    )

    original_scale = tuple(main_empty.scale)

    if scale is not None:
        main_empty.scale = (scale, scale, scale)

    context.view_layer.update()

    try:

        if export_native(filepath):
            return False

        export_fallback(context, filepath)

        return True

    finally:

        main_empty.scale = original_scale

        context.view_layer.update()


# =========================================================
# Export Collada Operator
# =========================================================

class MO2WI_OT_ExportCollada(bpy.types.Operator, ExportHelper):
    """Export the module to Collada (.dae) at mm scale"""

    bl_idname = "mo2wi.export_collada"

    bl_label = "Collada (.DAE) Export"

    bl_options = {'REGISTER'}

    filename_ext = ".dae"

    filter_glob: StringProperty(
        default="*.dae",
        options={'HIDDEN'},
    )

    def invoke(self, context, event):

        main_empty = find_main_empty(context)

        if main_empty is not None:
            self.filepath = main_empty.name + self.filename_ext

        return super().invoke(context, event)

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(
            context
        )

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Export At mm Scale (scale restored after)
        # -----------------------------------------

        try:

            used_fallback = export_module(
                context,
                main_empty,
                self.filepath,
            )

        except Exception as e:

            self.report(
                {'WARNING'},
                f"Collada export failed: {e}"
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Success
        # -----------------------------------------

        message = f"Exported '{self.filepath}'."

        if used_fallback:
            message += " (pure-Python fallback - no native Collada support)"

        self.report(
            {'INFO'},
            message
        )

        return {'FINISHED'}

"""
============================================================
Wardrobe Internals

Panel Conventions

One shared operator behind all 7 Panel Conventions buttons
(Fixed Shelf, Removable Shelf, Drawer Filler, Internal Drawer,
Internal Glass Drawer, Carcass Internal, Vertical Panel) - each
button sets this operator's `suffix` / `label` / `combine`
properties before calling it (see ui/panel_conventions.py),
same "one operator, args set from the UI call" pattern
MO2WI_OT_RemoveHandle uses for its `index`.

Responsibilities
----------------
Name "<module>_<suffix>_<NN>", parented under the module root,
either:

- New Module (still one combined mesh) - select faces in Edit
  Mode, Face select: the selection is separated out, each
  connected island becoming its own object (numbered
  left-to-right / top-to-bottom).
- Existing Module (panels already their own objects, e.g.
  "Face.030") - select one or more whole objects in Object
  Mode: each is renamed in place, no Edit Mode needed.

Either way, Drawer Filler, Internal Drawer, Internal Glass
Drawer and Carcass Internal always combine the whole selection -
even across several disconnected faces/objects - into a single
object (`combine=True`), since their source faces/panels are
naturally separate but belong together.
============================================================
"""

import bpy

from ..core.common import (
    make_name,
    next_index,
    parent_objects_keep_world,
    select_objects,
    join_objects,
)

from ..core.panel_conventions import (
    resolve_module_name,
    resolve_root,
    has_selected_faces,
    separate_selected_faces,
    split_into_islands,
    island_sort_key,
)


# =========================================================
# Panel Convention Operator
# =========================================================

class MO2WI_OT_PanelConvention(bpy.types.Operator):
    """Turn the current selection into a named Panel Convention object"""

    bl_idname = "mo2wi.panel_convention"
    bl_label = "Panel Convention"

    bl_options = {'REGISTER', 'UNDO'}

    suffix: bpy.props.StringProperty(options={'HIDDEN'})
    label: bpy.props.StringProperty(options={'HIDDEN'})
    combine: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):

        active = context.active_object

        # -----------------------------------------
        # Resolve Input Mode
        # -----------------------------------------
        # Edit Mode, faces selected on the active mesh -> New
        # Module. Otherwise, whatever whole objects are selected
        # in Object Mode -> Existing Module (panels already
        # separate objects). Decided once, up front, since the
        # Edit-Mode branch below changes context.active_object's
        # own mode as it works.

        edit_mode_faces = (
            active is not None
            and active.type == 'MESH'
            and active.mode == 'EDIT'
        )

        if edit_mode_faces:

            if not has_selected_faces(active):

                self.report(
                    {'WARNING'},
                    "Select faces first."
                )

                return {'CANCELLED'}

            candidates = active

        else:

            candidates = [
                obj for obj in context.selected_objects
                if obj.type == 'MESH'
            ]

            if not candidates:

                self.report(
                    {'WARNING'},
                    "Select faces (Edit Mode) or objects first."
                )

                return {'CANCELLED'}

        # -----------------------------------------
        # Resolve Module Name / Root
        # -----------------------------------------

        module_name = resolve_module_name(context, candidates)

        if not module_name:

            self.report(
                {'WARNING'},
                "Please enter a Module Name."
            )

            return {'CANCELLED'}

        root = resolve_root(candidates)

        # No module root found: Edit-Mode islands are brand new
        # objects, so nesting them under the mesh they came out of
        # is a safe fallback (mirrors Handle Library's own
        # attach-to-target fallback). In Object Mode the "island"
        # can BE one of the candidates themselves (e.g. a single
        # selected object, Combine off) - parenting it under
        # itself would be a bug, so there's no fallback there:
        # rename only, leave it wherever it already is.
        fallback_parent = active if edit_mode_faces else None

        # -----------------------------------------
        # Build Island List
        # -----------------------------------------

        if edit_mode_faces:

            separated = separate_selected_faces(active)

            if separated is None:

                self.report(
                    {'WARNING'},
                    "Nothing to separate."
                )

                return {'CANCELLED'}

            if self.combine:
                islands = [separated]
            else:
                islands = split_into_islands(context, separated)

        elif self.combine:

            combined = join_objects(context, candidates)

            islands = [combined] if combined is not None else []

        else:

            islands = list(candidates)

        if not islands:

            self.report(
                {'WARNING'},
                "Nothing to combine."
            )

            return {'CANCELLED'}

        islands.sort(key=island_sort_key)

        # -----------------------------------------
        # Rename + Parent
        # -----------------------------------------

        for island in islands:

            index = next_index(module_name, self.suffix)

            island.name = make_name(module_name, self.suffix, index)

            parent_target = root if root is not None else fallback_parent

            if parent_target is not None and parent_target is not island:

                parent_objects_keep_world(
                    parent_target,
                    [island]
                )

        select_objects(context, islands)

        names = ", ".join(island.name for island in islands)

        self.report(
            {'INFO'},
            f"{self.label} : {names}"
        )

        return {'FINISHED'}

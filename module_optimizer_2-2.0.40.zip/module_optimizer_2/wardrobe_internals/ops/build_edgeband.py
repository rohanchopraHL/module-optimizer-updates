import bpy

from ..core.hierarchy import find_main_empty
from ..core.module_finder import ModuleFinder
from ..core.face_finder import FaceFinder
from ..core.geometry_analyzer import GeometryAnalyzer
from ..core.combiner import Combiner
from ..core.face_orientation import FaceOrientation


# =========================================================
# Analyze Parts
# =========================================================

def analyze_parts(parts):
    """
    Analyze every Part
    and return valid analyses.
    """

    analyses = []

    for part in parts:

        faces = FaceFinder.find_faces(
            part
        )

        if not faces:
            continue

        analysis = GeometryAnalyzer.analyze(
            part,
            faces
        )

        if not analysis.is_valid:

            print(
                f"Skipping Invalid Part : {part.name}"
            )

            continue

        analyses.append(
            analysis
        )

    return analyses


# =========================================================
# Build EdgeBands
# =========================================================

def build_edgebands(analyses):
    """
    Combine EdgeBand faces
    for every valid Part.
    """

    total = 0

    for analysis in analyses:

        edge_band = Combiner.combine_edge_faces(

            analysis.part,

            analysis.edge_faces

        )

        if edge_band is None:

            print(
                f"Failed : {analysis.part.name}"
            )

            continue

        print(
            f"Created EdgeBand : {analysis.part.name}"
        )

        total += 1

    return total

# =========================================================
# Build EdgeBand Operator
# =========================================================

class MO2WI_OT_BuildEdgeBand(bpy.types.Operator):
    """
    Build EdgeBand
    """

    bl_idname = "mo2wi.build_edgeband"

    bl_label = "Build EdgeBand"

    bl_options = {
        'REGISTER',
        'UNDO',
    }

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(
            context
        )

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}


        parts = ModuleFinder.find_parts(
            main_empty
        )

        if not parts:

            self.report(
                {'WARNING'},
                "No Parts found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Analyze Parts
        # -----------------------------------------

        analyses = analyze_parts(
            parts
        )

        if not analyses:

            self.report(
                {'WARNING'},
                "No valid Parts found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Build EdgeBands
        # -----------------------------------------

        total = build_edgebands(
            analyses
        )

        # -----------------------------------------
        # Success
        # -----------------------------------------

        self.report(
            {'INFO'},
            f"{total} EdgeBand(s) created."
        )

        return {'FINISHED'}


# =========================================================
# Find Surface Faces
# =========================================================

def find_surface_faces(parts):
    """
    Find each Part's 2 Surface Faces.

    Unlike analyze_parts(), this does not require 4 Edge
    Faces to still be present, so it also works after
    Build EdgeBand has already merged them into a single
    EdgeBand object.
    """

    results = []

    for part in parts:

        faces = FaceFinder.find_faces(
            part
        )

        if not faces:
            continue

        surface_faces = [
            face
            for face in faces
            if not GeometryAnalyzer.classify_face(face)
        ]

        if len(surface_faces) != 2:

            print(
                f"Skipping Part (expected 2 Surface Faces) : {part.name}"
            )

            continue

        results.append(
            (part, surface_faces)
        )

    return results


# =========================================================
# Assign Front / Back
# =========================================================

def assign_front_back(parts_faces, main_empty):
    """
    Classify every Part's 2 Surface Faces as Front
    (outward-facing) or Back (inward-facing), relative
    to the module's overall bounding-box center, and
    rename them accordingly.
    """

    module_center = FaceOrientation.compute_module_center(
        main_empty
    )

    if module_center is None:
        return 0

    total = 0

    for part, surface_faces in parts_faces:

        for face in surface_faces:

            label = FaceOrientation.assign(
                face,
                module_center
            )

            if label is None:

                print(
                    f"Failed to classify : {face.name}"
                )

                continue

            print(
                f"Assigned {label} : {face.name}"
            )

            total += 1

    return total

# =========================================================
# Assign Front / Back Operator
# =========================================================

class MO2WI_OT_AssignFrontBack(bpy.types.Operator):
    """
    Assign Front / Back
    """

    bl_idname = "mo2wi.assign_front_back"

    bl_label = "Assign Front/Back"

    bl_options = {
        'REGISTER',
        'UNDO',
    }

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(
            context
        )

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}


        parts = ModuleFinder.find_parts(
            main_empty
        )

        if not parts:

            self.report(
                {'WARNING'},
                "No Parts found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Find Surface Faces
        # -----------------------------------------

        parts_faces = find_surface_faces(
            parts
        )

        if not parts_faces:

            self.report(
                {'WARNING'},
                "No valid Parts found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Assign Front / Back
        # -----------------------------------------

        total = assign_front_back(
            parts_faces,
            main_empty
        )

        # -----------------------------------------
        # Success
        # -----------------------------------------

        self.report(
            {'INFO'},
            f"{total} face(s) assigned Front/Back."
        )

        return {'FINISHED'}


# =========================================================
# Build EdgeBand & Faces Operator
# =========================================================

class MO2WI_OT_BuildEdgeBandAndFaces(bpy.types.Operator):
    """
    Build EdgeBand, then assign Front/Back
    to every Part's Surface Faces.
    """

    bl_idname = "mo2wi.build_edgeband_and_faces"

    bl_label = "Build EdgeBand & Faces"

    bl_options = {
        'REGISTER',
        'UNDO',
    }

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(
            context
        )

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}


        parts = ModuleFinder.find_parts(
            main_empty
        )

        if not parts:

            self.report(
                {'WARNING'},
                "No Parts found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Build EdgeBands
        # -----------------------------------------

        analyses = analyze_parts(
            parts
        )

        edgeband_total = 0

        if analyses:

            edgeband_total = build_edgebands(
                analyses
            )

        # -----------------------------------------
        # Assign Front / Back
        # -----------------------------------------

        parts_faces = find_surface_faces(
            parts
        )

        face_total = 0

        if parts_faces:

            face_total = assign_front_back(
                parts_faces,
                main_empty
            )

        # -----------------------------------------
        # Success
        # -----------------------------------------

        if edgeband_total == 0 and face_total == 0:

            self.report(
                {'WARNING'},
                "No valid Parts found."
            )

            return {'CANCELLED'}

        self.report(
            {'INFO'},
            f"{edgeband_total} EdgeBand(s) created, "
            f"{face_total} face(s) assigned Front/Back."
        )

        return {'FINISHED'}

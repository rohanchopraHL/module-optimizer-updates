import bpy

from ..core.hierarchy import find_main_empty

from ..core.uv_checker import (
    find_mesh_objects,
    box_map_unwrap,
    get_checker_material,
    assign_checker_material,
)


# =========================================================
# Unwrap Operator
# =========================================================

class MO2WI_OT_Unwrap(bpy.types.Operator):
    """Box Map unwrap every mesh and apply the Checker material"""

    bl_idname = "mo2wi.unwrap"

    bl_label = "Unwrap"

    bl_options = {
        'REGISTER',
        'UNDO',
    }

    def execute(self, context):

        # -----------------------------------------
        # Find Main Empty
        # -----------------------------------------

        main_empty = find_main_empty(
            context
        )

        if main_empty is None:

            self.report(
                {'WARNING'},
                "Main Empty not found."
            )

            return {'CANCELLED'}

        meshes = find_mesh_objects(
            main_empty
        )

        if not meshes:

            self.report(
                {'WARNING'},
                "No mesh objects found."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Box Map Unwrap
        # -----------------------------------------

        unwrapped = box_map_unwrap(
            context,
            meshes
        )

        if unwrapped is None:

            self.report(
                {'WARNING'},
                "Box Map (uv.muv_uvw_box_map) is unavailable. "
                "It ships with this add-on but failed to register - "
                "check the System Console for errors."
            )

            return {'CANCELLED'}

        # -----------------------------------------
        # Checker Material
        # -----------------------------------------

        material = get_checker_material()

        if material is None:

            self.report(
                {'WARNING'},
                f"{unwrapped} mesh(es) unwrapped, but the Checker "
                f"texture is missing from the add-on's assets."
            )

            return {'CANCELLED'}

        assigned = assign_checker_material(
            meshes,
            material
        )

        # -----------------------------------------
        # Success
        # -----------------------------------------

        self.report(
            {'INFO'},
            f"{unwrapped} mesh(es) unwrapped, "
            f"{assigned} assigned the Checker material."
        )

        return {'FINISHED'}

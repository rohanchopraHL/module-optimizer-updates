"""
============================================================
Wardrobe Internals

Width Rescale Operators

Same layout as the Depth Resizer: rows typed in by hand -
Cabinet Width (appended to the names, -450-DC -> -450-DC-900W)
and Shelf / Floor Width (the overall internal width the module
is rescaled to, spread equally over its bays - see
core/width_rescale.py). Row 0 is the always-visible first row
on MO2WI_Properties, rows 1.. are MO2WI_Properties.width_rows.
============================================================
"""

import bpy

from bpy.props import IntProperty

from ..core.depth_resizer import parse_exclude

from ..core.width_rescale import (
    rescale_width,
    rename_for_width,
)

from .depth_resizer import (
    row_texts,
    run_single,
    run_export_all,
)


def width_row_texts(props):

    return row_texts(
        props, "width_cabinet", "width_shelf",
        "width_rows", "cabinet_width", "shelf_width",
    )


def apply_width_row(context, root, meshes, cabinet_width, shelf_width):

    props = context.scene.mo2wi

    module_name = root.name

    info = rescale_width(
        meshes,
        shelf_width,
        parse_exclude(props.width_exclude),
    )

    if props.width_rename:
        rename_for_width(
            [root] + list(root.children_recursive),
            cabinet_width,
            module_name,
        )

    context.view_layer.update()

    before = " + ".join(f"{b:.0f}" for b in info["bays_before"])
    after = " + ".join(f"{b:.0f}" for b in info["bays_after"])

    return (
        f"Width {info['from_mm']:.1f} -> {shelf_width:.1f} mm; "
        f"{len(info['bays_before'])} bay(s): {before} -> {after}; "
        f"{info['skipped_tris']} zero-area tri(s) skipped."
    )


class MO2WI_OT_WidthAdd(bpy.types.Operator):
    """Add an empty width row"""

    bl_idname = "mo2wi.width_add"
    bl_label = "Add Width"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        context.scene.mo2wi.width_rows.add()

        return {'FINISHED'}


class MO2WI_OT_WidthRemove(bpy.types.Operator):
    """Remove this width row (the first row is just cleared)"""

    bl_idname = "mo2wi.width_remove"
    bl_label = "Remove Width"

    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=0)

    def execute(self, context):

        props = context.scene.mo2wi

        if self.index == 0:

            props.width_cabinet = ""
            props.width_shelf = ""

            return {'FINISHED'}

        if not (1 <= self.index <= len(props.width_rows)):
            return {'CANCELLED'}

        props.width_rows.remove(self.index - 1)

        return {'FINISHED'}


class MO2WI_OT_RescaleWidth(bpy.types.Operator):
    """Rescale the module to this row: rename with Cabinet Width, rescale to Shelf / Floor Width (equal per bay)"""

    bl_idname = "mo2wi.rescale_width"
    bl_label = "Rescale Width"

    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=0)

    def execute(self, context):

        props = context.scene.mo2wi

        return run_single(
            self, context,
            width_row_texts(props), self.index, "Width",
            props.width_selected_only, apply_width_row,
        )


class MO2WI_OT_RescaleWidthExportAll(bpy.types.Operator):
    """Rescale to every filled width row in turn and export each one as a .dae, then restore the original module"""

    bl_idname = "mo2wi.rescale_width_export_all"
    bl_label = "Rescale + Export All"

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        props = context.scene.mo2wi

        return run_export_all(
            self, context,
            width_row_texts(props), "Width",
            props.width_selected_only, props.width_output_dir,
            apply_width_row,
        )

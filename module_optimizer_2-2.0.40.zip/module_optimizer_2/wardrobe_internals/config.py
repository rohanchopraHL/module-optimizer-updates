"""
============================================================
Wardrobe Internals

Configuration Constants

Contains:
- Geometry
- EdgeBand Detection
- Naming Conventions
- UI Enums
- Debug
============================================================
"""

# =========================================================
# Geometry
# =========================================================

ZERO_TOLERANCE = 0.001

# =========================================================
# EdgeBand Detection
# =========================================================

EDGE_MIN = 5.0
EDGE_MAX = 25.0

# =========================================================
# Naming
# =========================================================

NAME_SEPARATOR = "_"

PART_PREFIX = "Part"
FACE_PREFIX = "Face"
EDGEBAND_NAME = "EdgeBand"

# =========================================================
# Carcass Naming
# =========================================================

CARCASS_GROUP = "car"
CARCASS_INTERNAL = "car-in"

CARCASS_VISIBLE_SIDE = "car_vs"
CARCASS_VISIBLE_SIDE_LEFT = "car_vs-l"
CARCASS_VISIBLE_SIDE_RIGHT = "car_vs-r"
CARCASS_SIDE_PANEL = "car_sd-pnl"
CARCASS_OSL = "OSL"
CARCASS_BSL = "BSL"

# =========================================================
# Shutter Naming
# =========================================================

SHUTTER_GROUP = "sh"
SHUTTER_FRONT = "sh-ft"
SHUTTER_BACK = "sh-bk"
SHUTTER_EDGEBAND = "sh-eb"

# =========================================================
# Counter Top Naming
# =========================================================

COUNTERTOP_GROUP = "c-top_sh"
COUNTERTOP_FRONT = "c-top_sh-ft"
COUNTERTOP_BACK = "c-top_sh-bk"
COUNTERTOP_EDGEBAND = "c-top_sh-eb"
COUNTERTOP_COMBINED = "c-top"

# =========================================================
# Top / Bottom Panel Naming
# =========================================================

TOP_PANEL = "car_vs-t"
BOTTOM_PANEL = "car_vs-b"

# Bottom Panel auto-detection: the lowest (closest-to-floor)
# Part whose overall width is at least this many mm is the
# bottom panel - no upper width limit, and no absolute Z
# window (raw Blender Z isn't reliably in mm - see
# GeometryAnalyzer.detect_unit - so "lowest" is used instead
# of a fixed mm range, which is scale-independent).
BOTTOM_PANEL_MIN_WIDTH_MM = 200.0

# =========================================================
# Skirting Naming
# =========================================================

SKIRTING_GROUP = "skr_sh"
SKIRTING_FRONT = "skr_sh-ft"
SKIRTING_EDGEBAND = "skr_sh-eb"

# Skirting is built as a new box: full module width (X),
# fixed 18mm depth (Y), and a Top/Bottom-Panel-style kickboard
# height (Z) the user picks per run.
SKIRTING_DEPTH_MM = 18.0

SKIRTING_HEIGHTS = [

    ("100", "100mm", ""),
    ("110", "110mm", ""),

]

# =========================================================
# Panel Conventions Naming
# =========================================================
# Each button separates the faces currently selected (Edit
# Mode, Face select) into their own object(s) and names them
# "<module>_<suffix>_<NN>" - see ops/panel_conventions.py.

FIXED_SHELF_SUFFIX = "fxd-shlf"
REMOVABLE_SHELF_SUFFIX = "var-shlf"
DRAWER_FILLER_SUFFIX = "dwr-flr"
INTERNAL_DRAWER_SUFFIX = "int-dwr"
INTERNAL_GLASS_DRAWER_SUFFIX = "int-dwr-gl"
VERTICAL_PANEL_SUFFIX = "vt-pnl"

# =========================================================
# Nudge
# =========================================================
# Fixed vertical offset the Nudge Up button raises the current
# selection by - see ops/nudge.py.

NUDGE_UP_MM = 10.0

# =========================================================
# Handle Naming
# =========================================================

HANDLE_SUFFIX = "han"

# Hardware Library assets that aren't a Handle get their own
# naming - matched against the asset's filename (without
# extension, see core/handle_library.py's enum labels). Add
# more (filename, suffix) pairs here as more non-Handle
# hardware is bundled.
HANGER_ROD_ASSET_NAME = "Hanger Rod"
HANGER_ROD_SUFFIX = "h-rod"

# =========================================================
# Hanger Rod Placement
# =========================================================
# The Hanger Rod has no Left/Center/Right - instead, clicking
# Add Hanger Rod pops up a dialog with a Height dropdown (one
# entry per value here, mm - first entry is the default), a
# Full Rod / Half Rod dropdown, and Left/Right if Half - see
# ops/hanger_rod.py. Add / reorder heights here.
HANGER_ROD_HEIGHTS = (2400, 2100, 1800)

# Z: the rod asset's own origin sits at its TOP edge (it hangs
# down from there), placed at
# Height - HANGER_ROD_TOP_OFFSET_MM - drop, where `drop` is the
# Z Location dropdown pick: HANGER_ROD_DROP_MM for "Top",
# HANGER_ROD_MID_DROP_MM for "Mid".
HANGER_ROD_TOP_OFFSET_MM = 18.0
HANGER_ROD_DROP_MM = 87.0
HANGER_ROD_MID_DROP_MM = 497.0

# Half Rod width = (widest face's own width / 2) - this gap, so
# the 2 half rods clear a center support. Positioned flush with
# the widest face's Left/Right edge (whichever side was picked),
# not centered in its half - assumed from "582-9=573" with no
# centering mentioned; flag if that's wrong.
HANGER_ROD_HALF_GAP_MM = 9.0

# =========================================================
# Handle Placement
# =========================================================

# Vertical handles are dropped near a corner of the target
# face rather than dead center. X is inset in from the
# Left/Right edge by this fixed distance (mm) so the handle
# doesn't hang off the panel.
HANDLE_EDGE_MARGIN_MM = 40.0

# Z is inset in from the Top/Bottom edge by this fixed
# distance (mm) - e.g. Top Left sits 152.553mm down from the
# panel's top edge, Bottom Left sits 152.553mm up from its
# bottom edge.
HANDLE_VERTICAL_Z_MM = 152.553

# Horizontal Top/Bottom are inset in from the target's
# Top/Bottom edge (at horizontally-centered X) by this fixed
# distance (mm): Top = top edge - offset, Bottom = bottom
# edge + offset. Center uses the face's own center instead.
HANDLE_HORIZONTAL_Z_OFFSET_MM = 100.0

# Handle placement (ops/handle_library.py,
# compute_handle_location()): the handle always sits on the
# target's front (-Y) face - Y pinned to the target's min Y,
# Z at its centre. X depends on the Left / Center / Right
# button: Center = X centre; Left = left edge + this fraction
# of the target's width; Right = right edge - the same.
HANDLE_LR_INSET_RATIO = 0.10

HANDLE_ORIENTATIONS = [

    ("HORIZONTAL", "Horizontal", "Handle lies flat, left to right (drawers)"),
    ("VERTICAL", "Vertical", "Handle stands upright, top to bottom (shutters)"),

]

HANDLE_POSITIONS = [

    ("NONE", "Select", ""),
    ("TOP_LEFT", "Top Left", ""),
    ("TOP_RIGHT", "Top Right", ""),
    ("BOTTOM_LEFT", "Bottom Left", ""),
    ("BOTTOM_RIGHT", "Bottom Right", ""),

]

HANDLE_HORIZONTAL_POSITIONS = [

    ("TOP", "Top", ""),
    ("CENTER", "Center", ""),
    ("BOTTOM", "Bottom", ""),

]

# Left / Center / Right buttons shown once both a Handle and a
# Place On target are picked - see ops/handle_library.py,
# MO2WI_OT_AddHandle.position.
HANDLE_LR_POSITIONS = [

    ("LEFT", "Left", "Inset 10% of the face's width in from its left edge"),
    ("CENTER", "Center", "Centered on the face"),
    ("RIGHT", "Right", "Inset 10% of the face's width in from its right edge"),

]

# =========================================================
# UV Checker
# =========================================================

UNWRAP_BOX_SIZE = 1.03
CHECKER_MATERIAL_NAME = "Checker"

# =========================================================
# Collada Export
# =========================================================

COLLADA_EXPORT_SCALE = 1000.0
COLLADA_FORWARD_AXIS = '-Z'
COLLADA_UP_AXIS = 'Y'

# =========================================================
# Depth Resizer
# =========================================================

# Any object whose name contains one of these keeps its depth
# (it's still re-centred with the rest of the module).
DEPTH_RESIZE_EXCLUDE = "h-rod, _han_, car-in"

# Width Rescale: hanger rods / carcass internals DO get narrower
# with their bay, so only handles keep their size by default.
WIDTH_RESCALE_EXCLUDE = "_han_"

# Which world axis is the module's depth. AUTO picks whichever of
# Y / Z the module is shallower along - Y for a module still laid
# out the Wardrobe Internals way (back at +Y), Z for a re-imported
# .dae (back at -Z).
DEPTH_AXES = [

    ("AUTO", "Auto", "Use whichever of Y / Z the module is shallower along"),
    ("Y", "Y (in scene)", "Depth along Y, back of the module at +Y"),
    ("Z", "Z (re-imported .dae)", "Depth along Z, back of the module at -Z"),

]

# =========================================================
# Convention Types
# =========================================================

GROUP_CONVENTIONS = [

    ("NONE", "Select", ""),
    ("CARCASS", "Carcass", ""),
    ("SIDE_PANELS", "Side Panels", ""),
    ("SHUTTER", "Shutter", ""),

]

# =========================================================
# Edit Convention Actions
# =========================================================
# Dropdown picker for the 4 manual Edit Convention buttons -
# picking one reveals just that single button below the
# dropdown instead of always showing all 4 stacked.

EDIT_CONVENTION_ACTIONS = [

    ("NONE", "Select", ""),
    ("CARCASS_INTERNAL", "Carcass Internal", ""),
    ("VISIBLE_SIDE_PANELS", "Visible Side Panels", ""),
    ("OSL_BSL_INTERNAL", "Internal OSL/BSL", ""),
    ("LR_VISIBLE_SIDE", "L/R Visible Side OSL/BSL", ""),

]

# =========================================================
# Module Types
# =========================================================

MODULE_TYPES = [

    ("NONE", "Select", ""),
    ("NEW_MODULE", "New Module", ""),
    ("EXISTING_MODULE", "Edit/Existing Modules", ""),
    ("WARDROBE_INTERNALS", "Wardrobe Internals", ""),

]

# =========================================================
# CleanUp Module - Carcass Panel Stripping
# =========================================================
# CleanUp Module (Wardrobe Internals) keeps only the module's
# internal components. It deletes the outer carcass panels,
# detected purely by position:
#   Top    - the Part whose mesh sits highest (+Z)
#   Bottom - the lowest full-width Part
#   Left   - the Part furthest at the -X end
#   Right  - the Part furthest at the +X end
#   Back   - the thin Part furthest at the +Y end (module rear)
#   Skirting - a short Part sitting below the bottom panel
#              (deleted only when present)

# A Part at the +Y (rear) extreme is only treated as the back
# panel when it is a thin sheet - its depth (Y extent) under
# this fraction of the module's overall depth - so a module
# with no back panel doesn't lose an internal part instead.
BACK_PANEL_MAX_DEPTH_RATIO = 0.4

# A Part is treated as skirting (rather than the bottom panel)
# when it sits below the lowest full-width Part, its depth is
# under this fraction of the module's overall depth, and its
# height is under SKIRTING_MAX_HEIGHT_MM.
SKIRTING_MAX_DEPTH_RATIO = 0.4
SKIRTING_MAX_HEIGHT_MM = 250.0

# Panel stripping only runs when the module still has at least
# this many Parts (4 shell panels + at least 1 internal), so a
# second CleanUp pass on an already-stripped module can't eat
# its internals. The module root is also flagged after the
# first pass as a second guard.
MIN_PARTS_FOR_PANEL_STRIP = 5
INTERNALS_STRIPPED_FLAG = "wint_internals_stripped"

# =========================================================
# Debug
# =========================================================

DEBUG = False

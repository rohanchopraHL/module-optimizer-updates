"""
============================================================
Wardrobe Internals

Hierarchy Helpers

Shared object-hierarchy lookups used by Module Cleanup and
Build EdgeBand.
============================================================
"""


# =========================================================
# Find Root Empty
# =========================================================

def find_root_empty(obj):
    """
    Walk obj's parent chain up to its top-most ancestor,
    returning it only if that ancestor is an Empty (the
    module's root / main group).
    """

    if obj is None:
        return None

    while obj.parent is not None:
        obj = obj.parent

    if obj.type != 'EMPTY':
        return None

    return obj


# =========================================================
# Find Topmost Ancestor
# =========================================================

def find_topmost_ancestor(obj):
    """
    Walk obj's parent chain up to its top-most ancestor and
    return it, regardless of object type.

    Unlike find_root_empty(), this never returns None (for a
    non-None obj) - used as a last-resort "main group" name
    source for Existing Module files where the top of the
    hierarchy isn't necessarily an Empty.
    """

    if obj is None:
        return None

    while obj.parent is not None:
        obj = obj.parent

    return obj


# =========================================================
# Find Main Empty
# =========================================================

def find_main_empty(context):
    """
    Return the module root Empty.

    If the active object is already an Empty, it is
    returned as-is. Otherwise the parent chain is walked
    up to the top-most object, which must be an Empty.

    Select the module's root Empty (not a Part sub-group)
    before running Module Cleanup / Build EdgeBand -
    an Empty is always returned immediately without
    climbing further, even if it is not the true root.
    """

    obj = context.active_object

    if obj is None:
        return None

    if obj.type == 'EMPTY':
        return obj

    return find_root_empty(obj)


# =========================================================
# Find Module Root
# =========================================================

def find_module_root(context):
    """
    Return the module's true top-level root Empty by walking
    ALL the way up the active object's parent chain - unlike
    find_main_empty(), selecting an Empty does not short-circuit
    the climb.

    A "Part" group is itself an Empty in this add-on's
    convention, so if the user's active object happens to be one
    Part (rather than the true module root), find_main_empty()
    would wrongly return that single Part - and Visible Sides /
    Top / Bottom / Internal OSL would then silently search only
    inside it, finding nothing outside. Carcass / Side Panels
    need the real module root every time, so they use this
    instead - selecting a Face, a Part, or the true root Empty
    all resolve to the same top-level Empty.
    """

    obj = context.active_object

    if obj is None:
        return None

    return find_root_empty(obj)


# =========================================================
# Resolve Module Name From Selection
# =========================================================

def resolve_module_name(selected_objects):
    """
    Find the module's "main group" name from whichever selected
    object actually has a usable parent chain - trying the
    module's root Empty first, then falling back to the plain
    top-most ancestor (Existing Module files aren't guaranteed
    to have an Empty at the top).

    Used as a Module Name fallback by any Edit Convention /
    Existing Module operator that has no Step 2 field to read.
    """

    for obj in selected_objects:

        root = find_root_empty(obj)

        if root is not None:
            return root.name

    for obj in selected_objects:

        top = find_topmost_ancestor(obj)

        if top is not None and top is not obj:
            return top.name

    return ""

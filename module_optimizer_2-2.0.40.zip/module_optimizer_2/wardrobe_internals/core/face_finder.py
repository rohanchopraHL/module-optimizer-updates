from ..config import FACE_PREFIX


class FaceFinder:

    @staticmethod
    def find_faces(part):

        faces = []

        if part is None:
            return faces

        for child in part.children:

            if child.name.startswith(FACE_PREFIX):
                faces.append(child)

        return faces

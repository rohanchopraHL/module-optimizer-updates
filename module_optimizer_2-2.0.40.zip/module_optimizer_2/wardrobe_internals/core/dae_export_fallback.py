"""
============================================================
Wardrobe Internals

Collada Export Fallback

Pure-Python COLLADA (.dae) writer used when the native
bpy.ops.wm.collada_export operator is unavailable (Blender
dropped bundled Collada support). Adapted from a standalone
dae_exporter.py utility, with global orientation (Forward /
Up axis) conversion added to match what the native exporter
would have produced.

Only positions / normals / UVs / triangles / basic Base
Color materials are written - no animation support, matching
this add-on's Collada Export requirements (no textures
copied, no animation).
============================================================
"""

import os
import shutil
import datetime
import math

from xml.etree import ElementTree as ET
from xml.dom import minidom

import bpy

from mathutils import Matrix


# =========================================================
# Helpers
# =========================================================

def safe_id(name, used=None):
    """Turn a Blender name into a safe COLLADA id (no spaces/dots, unique)."""

    out = "".join(c if (c.isalnum() or c == "_") else "_" for c in name)

    if not out or out[0].isdigit():
        out = "_" + out

    if used is not None:
        base = out
        i = 1
        while out in used:
            out = f"{base}_{i}"
            i += 1
        used.add(out)

    return out


def floats_to_str(values, precision=6):
    fmt = "{:." + str(precision) + "f}"
    return " ".join(fmt.format(v) for v in values)


def matrix_to_collada_str(matrix):
    """COLLADA <matrix> is row-major, 16 floats."""

    vals = []
    for row in matrix:
        vals.extend(row)
    return floats_to_str(vals)


def sub(parent, tag, text=None, **attrib):
    el = ET.SubElement(parent, tag, {k: str(v) for k, v in attrib.items()})
    if text is not None:
        el.text = text
    return el


# =========================================================
# Up Axis Metadata
# =========================================================

UP_AXIS_TAG = {
    'X': "X_UP",
    'Y': "Y_UP",
    'Z': "Z_UP",
}


# =========================================================
# Orientation Conversion
#
# Blender's native orientation is Forward -Y, Up Z. The only
# conversion this add-on actually needs is to Forward -Z,
# Up Y (the standard Y-up convention, e.g. matching Blender's
# own glTF exporter's fixed Z-up-to-Y-up conversion) - a
# single -90 degree rotation about X. Verified by round-trip:
# re-importing through Blender's native Collada importer
# (which un-rotates +90 degrees about X for a Y_UP-tagged
# file) should cancel out to exactly zero rotation.
# =========================================================

def get_conversion_matrix(to_forward, to_up):

    if to_forward == '-Z' and to_up == 'Y':
        return Matrix.Rotation(-math.pi / 2.0, 4, 'X')

    raise ValueError(
        f"No orientation conversion defined for "
        f"forward={to_forward!r}, up={to_up!r}."
    )


# =========================================================
# Core Exporter
# =========================================================

class DaeExporter:
    """
    Exports the given context's selected objects to a COLLADA
    file, converting from Blender's native orientation
    (Forward -Y, Up Z) to to_forward / to_up.
    """

    def __init__(
        self,
        context,
        filepath,
        to_forward='-Z',
        to_up='Y',
        export_materials=True,
        copy_textures=False,
        apply_modifiers=True,
    ):

        self.context = context
        self.filepath = filepath
        self.export_materials = export_materials
        self.copy_textures = copy_textures
        self.apply_modifiers = apply_modifiers

        self.out_dir = os.path.dirname(filepath)
        self.tex_dir = os.path.join(self.out_dir, "textures")

        self.used_ids = set()
        self.geom_id_by_mesh = {}
        self.mat_id_by_material = {}
        self.image_id_by_image = {}
        self.image_rel_path = {}
        self.mesh_material_symbols = {}

        self.depsgraph = context.evaluated_depsgraph_get()

        self.to_up = to_up
        self.conversion_matrix = get_conversion_matrix(to_forward, to_up)

    # -- object collection ---------------------------------

    def get_export_objects(self):

        objs = list(self.context.selected_objects)

        return [o for o in objs if o.type in ('MESH', 'EMPTY')]

    # -- images / textures ----------------------------------

    def register_image(self, image):

        if image in self.image_id_by_image:
            return self.image_id_by_image[image]

        img_id = safe_id("img_" + image.name, self.used_ids)
        self.image_id_by_image[image] = img_id

        if self.copy_textures:

            os.makedirs(self.tex_dir, exist_ok=True)
            base_name = (
                bpy.path.basename(image.filepath)
                if image.filepath else (image.name + ".png")
            )
            if not os.path.splitext(base_name)[1]:
                base_name += ".png"
            dest_path = os.path.join(self.tex_dir, base_name)

            try:
                if image.packed_file or not image.filepath:
                    old_path = image.filepath
                    image.filepath_raw = dest_path
                    image.file_format = 'PNG'
                    image.save()
                    if old_path:
                        image.filepath_raw = old_path
                else:
                    src = bpy.path.abspath(image.filepath)
                    if (
                        os.path.isfile(src)
                        and os.path.abspath(src) != os.path.abspath(dest_path)
                    ):
                        shutil.copyfile(src, dest_path)
            except Exception as e:
                print(f"[DAE Export] Could not export texture '{image.name}': {e}")

            rel_path = "textures/" + os.path.basename(dest_path)

        else:
            rel_path = bpy.path.abspath(image.filepath) if image.filepath else image.name

        self.image_rel_path[image] = rel_path.replace("\\", "/")

        return img_id

    # -- materials --------------------------------------------

    def get_material_color_and_texture(self, material):
        """Returns (rgba tuple, image_or_None) reading the Principled BSDF if present."""

        rgba = (0.8, 0.8, 0.8, 1.0)
        image = None

        if material and material.use_nodes:

            bsdf = None
            for node in material.node_tree.nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    bsdf = node
                    break

            if bsdf:
                base_color_input = bsdf.inputs.get("Base Color")
                if base_color_input is not None:
                    if base_color_input.is_linked:
                        link = base_color_input.links[0]
                        src_node = link.from_node
                        if src_node.type == 'TEX_IMAGE' and src_node.image:
                            image = src_node.image
                    else:
                        rgba = tuple(base_color_input.default_value)

        elif material:
            rgba = (*material.diffuse_color[:3], 1.0)

        return rgba, image

    def register_material(self, material):

        if material in self.mat_id_by_material:
            return self.mat_id_by_material[material]

        mat_id = safe_id("mat_" + material.name, self.used_ids)
        self.mat_id_by_material[material] = mat_id

        return mat_id

    # -- geometry -------------------------------------------

    def get_evaluated_mesh(self, obj):

        if self.apply_modifiers:
            obj_eval = obj.evaluated_get(self.depsgraph)
            mesh = obj_eval.to_mesh()
        else:
            mesh = obj.to_mesh()

        mesh.calc_loop_triangles()

        return mesh

    def register_geometry(self, obj):

        mesh = obj.data

        if mesh in self.geom_id_by_mesh:
            return self.geom_id_by_mesh[mesh]

        geom_id = safe_id("geom_" + mesh.name, self.used_ids)
        self.geom_id_by_mesh[mesh] = geom_id

        return geom_id

    def build_geometry_element(self, lib_geometries, obj):

        mesh_key = obj.data
        geom_id = self.register_geometry(obj)

        eval_mesh = self.get_evaluated_mesh(obj)

        # Geometry data stays in the object's own local space -
        # only the node matrices (see build_visual_scene) carry
        # the orientation conversion, so vertex/normal data here
        # is written exactly as Blender authored it.

        positions = []
        for v in eval_mesh.vertices:
            positions.extend(v.co)

        normals = []
        for v in eval_mesh.vertices:
            normals.extend(v.normal)

        has_uv = len(eval_mesh.uv_layers) > 0
        uvs = []
        if has_uv:
            uv_layer = eval_mesh.uv_layers.active.data
            uv_by_loop = [None] * len(eval_mesh.loops)
            for li, loop in enumerate(eval_mesh.loops):
                uv_by_loop[li] = uv_layer[li].uv
            for uv in uv_by_loop:
                uvs.extend((uv[0], uv[1]))

        mat_count = max(1, len(eval_mesh.materials))
        tris_by_mat = {i: [] for i in range(mat_count)}
        for tri in eval_mesh.loop_triangles:
            mi = tri.material_index if tri.material_index < mat_count else 0
            tris_by_mat[mi].append(tri)

        geometry_el = sub(lib_geometries, "geometry", id=geom_id, name=safe_id(mesh_key.name))
        mesh_el = sub(geometry_el, "mesh")

        pos_src_id = geom_id + "-positions"
        src = sub(mesh_el, "source", id=pos_src_id)
        sub(src, "float_array", floats_to_str(positions), id=pos_src_id + "-array", count=len(positions))
        acc_el = sub(sub(src, "technique_common"), "accessor",
                     source="#" + pos_src_id + "-array", count=len(eval_mesh.vertices), stride=3)
        sub(acc_el, "param", name="X", type="float")
        sub(acc_el, "param", name="Y", type="float")
        sub(acc_el, "param", name="Z", type="float")

        norm_src_id = geom_id + "-normals"
        src = sub(mesh_el, "source", id=norm_src_id)
        sub(src, "float_array", floats_to_str(normals), id=norm_src_id + "-array", count=len(normals))
        acc_el = sub(sub(src, "technique_common"), "accessor",
                     source="#" + norm_src_id + "-array", count=len(eval_mesh.vertices), stride=3)
        sub(acc_el, "param", name="X", type="float")
        sub(acc_el, "param", name="Y", type="float")
        sub(acc_el, "param", name="Z", type="float")

        uv_src_id = geom_id + "-uv"
        if has_uv:
            src = sub(mesh_el, "source", id=uv_src_id)
            sub(src, "float_array", floats_to_str(uvs), id=uv_src_id + "-array", count=len(uvs))
            acc_el = sub(sub(src, "technique_common"), "accessor",
                         source="#" + uv_src_id + "-array", count=len(eval_mesh.loops), stride=2)
            sub(acc_el, "param", name="S", type="float")
            sub(acc_el, "param", name="T", type="float")

        vtx_id = geom_id + "-vertices"
        vtx_el = sub(mesh_el, "vertices", id=vtx_id)
        sub(vtx_el, "input", semantic="POSITION", source="#" + pos_src_id)
        sub(vtx_el, "input", semantic="NORMAL", source="#" + norm_src_id)

        material_symbols = {}
        for mi in range(mat_count):
            tris = tris_by_mat[mi]
            if not tris:
                continue
            material = eval_mesh.materials[mi] if mi < len(eval_mesh.materials) and eval_mesh.materials[mi] else None
            symbol = safe_id("sym_" + (material.name if material else "default"))
            symbol = f"{symbol}_{mi}"
            material_symbols[mi] = (symbol, material)

            attrs = {"count": len(tris), "material": symbol}
            tri_el = sub(mesh_el, "triangles", **attrs)
            sub(tri_el, "input", semantic="VERTEX", source="#" + vtx_id, offset=0)
            if has_uv:
                sub(tri_el, "input", semantic="TEXCOORD", source="#" + uv_src_id, offset=1, set=0)

            p_vals = []
            for tri in tris:
                for li in tri.loops:
                    vi = eval_mesh.loops[li].vertex_index
                    p_vals.append(vi)
                    if has_uv:
                        p_vals.append(li)
            sub(tri_el, "p", " ".join(str(i) for i in p_vals))

        self.mesh_material_symbols[mesh_key] = material_symbols

        obj.to_mesh_clear()

        return geom_id

    # -- library builders -------------------------------------

    def build_libraries(self, root, export_objs):

        lib_images = sub(root, "library_images")
        lib_effects = sub(root, "library_effects")
        lib_materials = sub(root, "library_materials")
        lib_geometries = sub(root, "library_geometries")

        mesh_objs = [o for o in export_objs if o.type == 'MESH' and o.data is not None]

        seen_meshes = set()
        for obj in mesh_objs:
            if obj.data not in seen_meshes:
                self.build_geometry_element(lib_geometries, obj)
                seen_meshes.add(obj.data)

        if self.export_materials:

            all_materials = set()
            for mesh in seen_meshes:
                for mat in mesh.materials:
                    if mat:
                        all_materials.add(mat)

            for material in all_materials:

                mat_id = self.register_material(material)
                rgba, image = self.get_material_color_and_texture(material)

                effect_id = mat_id + "-effect"
                effect_el = sub(lib_effects, "effect", id=effect_id)
                profile = sub(effect_el, "profile_COMMON")

                if image is not None:
                    img_id = self.register_image(image)
                    sub(lib_images, "image", id=img_id, name=img_id)
                    init_from = sub(lib_images[-1], "init_from")
                    init_from.text = self.image_rel_path[image]

                    surface_sid = mat_id + "-surface"
                    sampler_sid = mat_id + "-sampler"
                    newparam1 = sub(profile, "newparam", sid=surface_sid)
                    surface_el = sub(newparam1, "surface", type="2D")
                    sub(surface_el, "init_from", img_id)
                    newparam2 = sub(profile, "newparam", sid=sampler_sid)
                    sampler_el = sub(newparam2, "sampler2D")
                    sub(sampler_el, "source", surface_sid)

                technique = sub(profile, "technique", sid="common")
                phong = sub(technique, "phong")
                diffuse_el = sub(phong, "diffuse")
                if image is not None:
                    sub(diffuse_el, "texture", texture=mat_id + "-sampler", texcoord="UVMap")
                else:
                    sub(diffuse_el, "color", floats_to_str(rgba))
                specular_el = sub(phong, "specular")
                sub(specular_el, "color", floats_to_str((0.2, 0.2, 0.2, 1.0)))
                shininess_el = sub(phong, "shininess")
                sub(shininess_el, "float", "20.0")

                material_el = sub(lib_materials, "material", id=mat_id, name=material.name)
                sub(material_el, "instance_effect", url="#" + effect_id)

        if len(lib_images) == 0:
            root.remove(lib_images)

    def build_visual_scene(self, root, export_objs):
        """
        Root-level objects (no parent, or parent not in the
        export set) get the orientation conversion baked into
        their local matrix. Child nodes keep their matrix_local
        untouched - for a rigid whole-scene rotation, a child's
        transform relative to its (also-rotated) parent is
        mathematically unchanged, so only roots need it.
        """

        lib_scenes = sub(root, "library_visual_scenes")
        scene_id = "Scene"
        visual_scene_el = sub(lib_scenes, "visual_scene", id=scene_id, name=scene_id)

        export_set = set(export_objs)

        node_el_by_obj = {}
        top_level = []

        for obj in export_objs:

            is_root = obj.parent is None or obj.parent not in export_set

            matrix = obj.matrix_local
            if is_root:
                matrix = self.conversion_matrix @ matrix

            node_id = safe_id("node_" + obj.name, self.used_ids)
            node_el = ET.Element("node", {"id": node_id, "name": obj.name, "type": "NODE"})
            sub(node_el, "matrix", matrix_to_collada_str(matrix), sid="transform")

            if obj.type == 'MESH' and obj.data is not None:
                geom_id = self.geom_id_by_mesh.get(obj.data)
                if geom_id:
                    inst_geom = sub(node_el, "instance_geometry", url="#" + geom_id)
                    symbols = self.mesh_material_symbols.get(obj.data, {})
                    if symbols:
                        bind_mat = sub(inst_geom, "bind_material")
                        tech_common = sub(bind_mat, "technique_common")
                        for symbol, material in symbols.values():
                            mat_id = self.mat_id_by_material.get(material)
                            if mat_id:
                                inst_mat = sub(tech_common, "instance_material",
                                               symbol=symbol, target="#" + mat_id)
                                sub(inst_mat, "bind_vertex_input",
                                    semantic="UVMap", input_semantic="TEXCOORD", input_set=0)

            node_el_by_obj[obj] = node_el

        for obj in export_objs:
            node_el = node_el_by_obj[obj]
            parent = obj.parent
            if parent is not None and parent in node_el_by_obj:
                node_el_by_obj[parent].append(node_el)
            else:
                top_level.append(node_el)

        for node_el in top_level:
            visual_scene_el.append(node_el)

        return scene_id

    # -- top level export --------------------------------------

    def export(self):

        root = ET.Element("COLLADA", {
            "xmlns": "http://www.collada.org/2005/11/COLLADASchema",
            "version": "1.4.1",
        })

        asset = sub(root, "asset")
        now = datetime.datetime.utcnow().isoformat()
        sub(asset, "created", now)
        sub(asset, "modified", now)
        sub(asset, "unit", name="meter", meter="1")
        sub(asset, "up_axis", UP_AXIS_TAG.get(self.to_up, "Y_UP"))

        export_objs = self.get_export_objects()
        if not export_objs:
            raise RuntimeError("No mesh/empty objects to export (nothing selected).")

        self.build_libraries(root, export_objs)
        scene_id = self.build_visual_scene(root, export_objs)

        scene_el = sub(root, "scene")
        sub(scene_el, "instance_visual_scene", url="#" + scene_id)

        xml_str = ET.tostring(root, encoding="unicode")
        pretty = minidom.parseString(xml_str).toprettyxml(indent="  ")
        pretty = "\n".join(line for line in pretty.split("\n") if line.strip())

        with open(self.filepath, "w", encoding="utf-8") as f:
            f.write(pretty)

"""
============================================================
Wardrobe Internals

Freeze

Bakes a hierarchy's transforms into its mesh vertex data and
resets every object to identity - shared by Set Pivot Point
(ops/set_pivot_point.py) and Flip (ops/flip.py), the 2 tools
in this add-on that need to bake a transform in without using
Object > Apply > Transform (which mangles a parented Empty
hierarchy).
============================================================
"""

from mathutils import Matrix


# =========================================================
# Freeze The Whole Hierarchy
# =========================================================

def freeze_hierarchy(context, main_empty, offset):
    """
    Bake each mesh's (offset-shifted) world transform into its
    vertex data, then reset every object under `main_empty`
    (and `main_empty` itself) to an identity transform with no
    parent-inverse.

    `offset` is a world-space Matrix applied to every mesh
    before baking - e.g. Set Pivot Point uses a translation by
    -floor_center, Flip uses Identity (the mirror/rotation is
    already on main_empty's own matrix_basis by the time this
    runs, so main_empty.matrix_world already carries it).

    Returns the number of mesh objects frozen.
    """

    identity = Matrix.Identity(4)

    all_objects = [main_empty] + list(main_empty.children_recursive)

    meshes = [obj for obj in all_objects if obj.type == 'MESH']

    for mesh in meshes:

        target_world = offset @ mesh.matrix_world

        data = mesh.data

        # A mesh shared by several objects must not be baked
        # more than once - give this object its own copy first.
        if data.users > 1:
            data = data.copy()
            mesh.data = data

        data.transform(target_world)
        data.update()

    for obj in all_objects:
        obj.matrix_parent_inverse = identity
        obj.matrix_basis = identity

    context.view_layer.update()

    return len(meshes)

# """
#
# Wardrobe Internals
#
# Common Helper Functions
#
# """

import bpy

from mathutils import Matrix

from ..config import DEBUG, NAME_SEPARATOR

# =========================================================
# Object Helpers
# =========================================================

def get_valid_objects(collection):
    """
    Return only valid Blender objects from
    a CollectionProperty.
    """

    return [
        item.object
        for item in collection
        if item.object is not None
    ]


# =========================================================
# Rename Helper
# =========================================================

def rename_object(obj, new_name):
    """
    Rename Blender object.
    """

    if obj is None:
        return None

    obj.name = new_name

    return obj


# =========================================================
# Join Objects
# =========================================================

def join_objects(context, objects):
    """
    Join objects.

    First object survives.
    """

    objects = [
        obj
        for obj in objects
        if obj is not None
    ]

    if len(objects) == 0:
        return None

    if len(objects) == 1:
        return objects[0]

    bpy.ops.object.select_all(
        action='DESELECT'
    )

    survivor = objects[0]

    for obj in objects:
        obj.select_set(True)

    context.view_layer.objects.active = survivor

    result = bpy.ops.object.join()

    if DEBUG:
        print("----------------------------------------")
        print("JOIN RESULT :", result)
        print("ACTIVE      :", context.view_layer.objects.active)
        print("OBJECT COUNT:", len(objects))
        print("----------------------------------------")

    return survivor


# =========================================================
# Parent Objects
# =========================================================

def parent_objects(parent, children):
    """
    Parent children to parent object.
    """

    if parent is None:
        return

    for child in children:

        if child is None:
            continue

        child.parent = parent

        child.matrix_parent_inverse = (
            parent.matrix_world.inverted()
        )


# =========================================================
# Parent Objects (Keep World Position)
# =========================================================

def parent_objects_keep_world(parent, children):
    """
    Parent children to parent object, preserving each child's
    current world-space position/rotation/scale exactly -
    unlike parent_objects() above, this doesn't assume the
    child's matrix_basis already represents the right
    parent-relative transform, so it's safe regardless of
    whatever parent the child had before (matches
    core/strip_internals.py's combine_and_flatten_part()).
    """

    if parent is None:
        return

    for child in children:

        if child is None:
            continue

        world = child.matrix_world.copy()

        child.parent = parent
        child.matrix_parent_inverse = Matrix.Identity(4)
        child.matrix_world = world


# =========================================================
# Select Objects
# =========================================================

def select_objects(context, objects):
    """
    Select objects in viewport.
    """

    bpy.ops.object.select_all(
        action='DESELECT'
    )

    first = None

    for obj in objects:

        if obj is None:
            continue

        obj.select_set(True)

        if first is None:
            first = obj

    if first:

        context.view_layer.objects.active = first


# =========================================================
# Name Generator
# =========================================================

def make_name(module_name, suffix, index):
    """
    Example:

    Kitchen01_sh-ft_01
    Kitchen01_car_01
    """

    return NAME_SEPARATOR.join([
        module_name,
        suffix,
        f"{index:02d}",
    ])


# =========================================================
# Next Available Index
# =========================================================

def next_index(module_name, suffix):
    """
    Find the next free numeric suffix for
    module_name_suffix_XX, based on existing object names,
    so repeated Apply Convention calls produce _01, _02,
    _03, ... instead of colliding on _01 every time.
    """

    prefix = NAME_SEPARATOR.join([
        module_name,
        suffix,
        "",
    ])

    highest = 0

    for obj in bpy.data.objects:

        if not obj.name.startswith(prefix):
            continue

        digits = obj.name[len(prefix):len(prefix) + 2]

        if digits.isdigit():
            highest = max(highest, int(digits))

    return highest + 1

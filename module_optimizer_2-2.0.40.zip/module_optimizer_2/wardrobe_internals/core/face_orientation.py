"""
============================================================
Wardrobe Internals

Face Orientation

Responsibilities
----------------
- Compute the module's overall bounding-box center
- Determine whether a surface face points outward
  (Front) or inward (Back) relative to that center
============================================================
"""

from mathutils import Vector

from .common import rename_object


FRONT_NAME = "Front"
BACK_NAME = "Back"


class FaceOrientation:
    """
    Classifies surface faces as Front (outward-facing)
    or Back (inward-facing) using the module's overall
    bounding-box center as reference.
    """

    # --------------------------------------------------------
    # Module Center
    # --------------------------------------------------------

    @staticmethod
    def compute_module_center(main_empty):
        """
        World-space bounding-box center of every mesh
        descendant of main_empty.
        """

        min_corner = None
        max_corner = None

        for obj in main_empty.children_recursive:

            if obj.type != 'MESH':
                continue

            for corner in obj.bound_box:

                world_corner = obj.matrix_world @ Vector(corner)

                if min_corner is None:

                    min_corner = world_corner.copy()
                    max_corner = world_corner.copy()

                    continue

                min_corner.x = min(min_corner.x, world_corner.x)
                min_corner.y = min(min_corner.y, world_corner.y)
                min_corner.z = min(min_corner.z, world_corner.z)

                max_corner.x = max(max_corner.x, world_corner.x)
                max_corner.y = max(max_corner.y, world_corner.y)
                max_corner.z = max(max_corner.z, world_corner.z)

        if min_corner is None:
            return None

        return (min_corner + max_corner) / 2.0

    # --------------------------------------------------------
    # World-Space Face Data
    # --------------------------------------------------------

    @staticmethod
    def get_world_center(face):
        """
        World-space center of a face object's
        single polygon.
        """

        polygons = face.data.polygons

        if not polygons:
            return None

        return face.matrix_world @ polygons[0].center

    # --------------------------------------------------------

    @staticmethod
    def get_world_normal(face):
        """
        World-space normal of a face object's
        single polygon.
        """

        polygons = face.data.polygons

        if not polygons:
            return None

        normal_matrix = (
            face.matrix_world.to_3x3().inverted_safe().transposed()
        )

        world_normal = normal_matrix @ polygons[0].normal

        world_normal.normalize()

        return world_normal

    # --------------------------------------------------------
    # Classification
    # --------------------------------------------------------

    @staticmethod
    def classify(face, module_center):
        """
        Returns FRONT_NAME if the face normal points away
        from module_center (outward), otherwise BACK_NAME.
        """

        center = FaceOrientation.get_world_center(face)
        normal = FaceOrientation.get_world_normal(face)

        if center is None or normal is None:
            return None

        outward = center - module_center

        if outward.dot(normal) >= 0:
            return FRONT_NAME

        return BACK_NAME

    # --------------------------------------------------------
    # Assign
    # --------------------------------------------------------

    @staticmethod
    def assign(face, module_center):
        """
        Classify a face and rename it Front / Back.

        Returns the assigned label, or None if the face
        could not be classified.
        """

        label = FaceOrientation.classify(face, module_center)

        if label is None:
            return None

        rename_object(face, label)

        return label

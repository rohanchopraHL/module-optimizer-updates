import bpy

from ..config import EDGEBAND_NAME


class Combiner:
    """
    Combines EdgeBand faces into a single object.
    """

    # --------------------------------------------------------
    # EdgeBand
    # --------------------------------------------------------

    @staticmethod
    def combine_edge_faces(part, edge_faces):
        """
        Combine edge faces into one EdgeBand object.
        """

        if len(edge_faces) < 2:

            print(
                "Not enough edge faces to combine."
            )

            return None

        view_layer = bpy.context.view_layer

        previous_active = view_layer.objects.active
        previous_selected = list(
            bpy.context.selected_objects
        )

        try:

            if bpy.context.mode != 'OBJECT':
                bpy.ops.object.mode_set(
                    mode='OBJECT'
                )

            bpy.ops.object.select_all(
                action='DESELECT'
            )

            for obj in edge_faces:
                obj.select_set(True)

            view_layer.objects.active = edge_faces[-1]

            bpy.ops.object.join()

            edge_band = view_layer.objects.active

            edge_band.name = EDGEBAND_NAME

            edge_band.parent = part

            edge_band.matrix_parent_inverse = (
                part.matrix_world.inverted()
            )

            return edge_band

        finally:

            bpy.ops.object.select_all(
                action='DESELECT'
            )

            for obj in previous_selected:

                # bpy.ops.object.join() above may have deleted some
                # of these (e.g. the edge faces just merged), which
                # leaves a freed StructRNA that raises ReferenceError
                # on any attribute access, including .name.
                try:
                    name = obj.name
                except ReferenceError:
                    continue

                if name in bpy.data.objects:

                    bpy.data.objects[
                        name
                    ].select_set(True)

            if previous_active:

                try:
                    active_name = previous_active.name
                except ReferenceError:
                    active_name = None

                if active_name and active_name in bpy.data.objects:

                    view_layer.objects.active = (
                        bpy.data.objects[
                            active_name
                        ]
                    )

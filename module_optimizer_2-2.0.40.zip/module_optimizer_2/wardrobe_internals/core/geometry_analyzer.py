"""
============================================================
Wardrobe Internals

Geometry Analyzer

Responsibilities
----------------
- Analyze every Part
- Detect unit system
- Convert dimensions to millimeters
- Classify faces
- Return analysis result
============================================================
"""

from dataclasses import dataclass, field

from ..config import (
    EDGE_MIN,
    EDGE_MAX,
    ZERO_TOLERANCE,
    DEBUG,
)


# ============================================================
# Part Analysis
# ============================================================

@dataclass
class PartAnalysis:
    """
    Stores analysis result for a single Part.
    """

    part: object

    surface_faces: list = field(default_factory=list)
    edge_faces: list = field(default_factory=list)

    @property
    def is_valid(self):
        """
        A valid cabinet panel must contain:

            2 Surface Faces
            4 Edge Faces
        """

        return (
            len(self.surface_faces) == 2
            and
            len(self.edge_faces) == 4
        )


# ============================================================
# Geometry Analyzer
# ============================================================

class GeometryAnalyzer:
    """
    Performs geometry analysis for cabinet Parts.
    """

    # --------------------------------------------------------
    # Public
    # --------------------------------------------------------

    @staticmethod
    def analyze(part, faces):

        if DEBUG:
            print()
            print("=" * 60)
            print(f"Analyzing : {part.name}")
            print("=" * 60)

        result = PartAnalysis(part)

        if not faces:
            return result

        for face in faces:

            is_edge = GeometryAnalyzer.classify_face(face)

            if is_edge:
                result.edge_faces.append(face)
            else:
                result.surface_faces.append(face)

        if DEBUG:

            print()

            print(
                f"Surface Faces : {len(result.surface_faces)}"
            )

            for face in result.surface_faces:
                print(f"    {face.name}")

            print()

            print(
                f"Edge Faces : {len(result.edge_faces)}"
            )

            for face in result.edge_faces:
                print(f"    {face.name}")

            print()

            print(
                f"Status : {'VALID' if result.is_valid else 'INVALID'}"
            )

        return result

    # --------------------------------------------------------
    # Unit Detection
    # --------------------------------------------------------

    @staticmethod
    def detect_unit(dimensions):
        """
        Detect whether dimensions are stored in
        meters or millimeters.

        Returns:
            "METER"
            "MILLIMETER"
        """

        largest = max(dimensions, default=0.0)

        if largest < 10:
            return "METER"

        return "MILLIMETER"


    # --------------------------------------------------------
    # Unit Conversion
    # --------------------------------------------------------

    @staticmethod
    def convert_to_mm(value, unit):
        """
        Convert a single dimension to millimeters.
        """

        if unit == "METER":
            return value * 1000.0

        return value

    # --------------------------------------------------------

    @staticmethod
    def get_dimensions_mm(face):
        """
        Return object dimensions in millimeters.

        Returns:
            [x, y, z]
        """

        dimensions = [
            face.dimensions.x,
            face.dimensions.y,
            face.dimensions.z,
        ]

        unit = GeometryAnalyzer.detect_unit(dimensions)

        dimensions_mm = [
            GeometryAnalyzer.convert_to_mm(d, unit)
            for d in dimensions
        ]

        if DEBUG:
            print(
                f"{face.name:12}"
                f" X={dimensions_mm[0]:.1f}"
                f" Y={dimensions_mm[1]:.1f}"
                f" Z={dimensions_mm[2]:.1f}"
            )

        return dimensions_mm

    # --------------------------------------------------------

    @staticmethod
    def get_small_dimension(face):
        """
        Ignore zero thickness and return the smaller
        of the remaining two dimensions.
        """

        dimensions = GeometryAnalyzer.get_dimensions_mm(face)

        dimensions = [
            d
            for d in dimensions
            if d > ZERO_TOLERANCE
        ]

        if len(dimensions) < 2:
            return 0.0

        dimensions.sort()

        small_dimension = dimensions[0]

        if DEBUG:
            print(
                f"      Small Dimension = {small_dimension:.1f} mm"
            )

        return small_dimension


    # --------------------------------------------------------
    # Edge Detection
    # --------------------------------------------------------

    @staticmethod
    def is_edge_dimension(value):
        """
        Returns True if the dimension matches the
        expected edge band thickness.
        """

        return EDGE_MIN <= value <= EDGE_MAX

    # --------------------------------------------------------
    # Face Classification
    # --------------------------------------------------------

    @staticmethod
    def classify_face(face):
        """
        Classify a face as EDGE or SURFACE.
        """

        small_dimension = GeometryAnalyzer.get_small_dimension(face)

        is_edge = GeometryAnalyzer.is_edge_dimension(small_dimension)

        if DEBUG:
            if is_edge:
                print("   -> EDGE")
            else:
                print("   -> SURFACE")

        return is_edge

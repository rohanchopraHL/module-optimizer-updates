"""
============================================================
Wardrobe Internals

UV Checker

Responsibilities
----------------
- Box-map unwrap every mesh in the module (Magic UV's
  UVW Box Map, vendored - see vendor/magic_uv_uvw/NOTICE.md)
- Create / reuse the bundled "Checker" material
- Assign it to every mesh so all faces show the checker
============================================================
"""

import os

import bpy

from ..config import (
    UNWRAP_BOX_SIZE,
    CHECKER_MATERIAL_NAME,
)

from ..vendor.magic_uv_uvw.op.uvw import MUV_OT_UVW_BoxMap


# =========================================================
# Box Map Registration
#
# Registered separately from ops/__init__.py's MO2WI_OT_*
# classes, since this operator belongs to Magic UV (bl_idname
# "uv.muv_uvw_box_map") and must not be double-registered if
# a real Magic UV install is also active.
# =========================================================

_registered_box_map = False


def register_box_map():

    global _registered_box_map

    if hasattr(bpy.types, "MUV_OT_UVW_BoxMap"):
        return

    bpy.utils.register_class(MUV_OT_UVW_BoxMap)

    _registered_box_map = True


def unregister_box_map():

    global _registered_box_map

    if not _registered_box_map:
        return

    _registered_box_map = False

    # Magic UV / HL Modules Optimizer share this bl_idname and may
    # have already unregistered it - don't let that abort the rest of
    # this add-on's unregister (it would break F3 > Reload Scripts).
    try:
        bpy.utils.unregister_class(MUV_OT_UVW_BoxMap)
    except RuntimeError:
        pass


# =========================================================
# Checker Image Location
# =========================================================

ADDON_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

CHECKER_IMAGE_PATH = os.path.join(
    ADDON_DIR,
    "assets",
    "textures",
    "checker.jpg",
)


# =========================================================
# Find Mesh Objects
# =========================================================

def find_mesh_objects(main_empty):
    """
    Every MESH descendant of the module root.
    """

    return [
        obj
        for obj in main_empty.children_recursive
        if obj.type == 'MESH'
    ]


# =========================================================
# Box Map Unwrap
# =========================================================

def box_map_unwrap(context, meshes):
    """
    Run Magic UV's Box Map on every mesh, one at a time,
    with Size = UNWRAP_BOX_SIZE and every other setting left
    at the operator's own default.
    """

    view_layer = context.view_layer
    view_layer_objects = view_layer.objects

    previous_active = view_layer.objects.active
    previous_selected = list(context.selected_objects)
    previous_mode = context.mode

    unwrapped = 0
    missing_operator = False

    try:

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        for obj in meshes:

            if obj.name not in view_layer_objects:
                continue

            bpy.ops.object.select_all(action='DESELECT')

            obj.select_set(True)
            view_layer.objects.active = obj

            bpy.ops.object.mode_set(mode='EDIT')

            bpy.ops.mesh.select_all(action='SELECT')

            try:

                bpy.ops.uv.muv_uvw_box_map(
                    size=UNWRAP_BOX_SIZE
                )

            except AttributeError:

                missing_operator = True

                bpy.ops.object.mode_set(mode='OBJECT')

                break

            bpy.ops.object.mode_set(mode='OBJECT')

            unwrapped += 1

    finally:

        bpy.ops.object.select_all(action='DESELECT')

        for obj in previous_selected:

            try:
                name = obj.name
            except ReferenceError:
                continue

            if name in bpy.data.objects:
                bpy.data.objects[name].select_set(True)

        if previous_active:

            try:
                active_name = previous_active.name
            except ReferenceError:
                active_name = None

            if active_name and active_name in bpy.data.objects:
                view_layer.objects.active = bpy.data.objects[active_name]

        if previous_mode == 'EDIT_MESH' and context.mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='EDIT')

    if missing_operator:
        return None

    return unwrapped


# =========================================================
# Checker Material
# =========================================================

def get_checker_material():
    """
    Return the bundled Checker material, creating it (with
    an Image Texture node wired to Base Color) if needed.
    """

    material = bpy.data.materials.get(CHECKER_MATERIAL_NAME)

    if material is not None:
        return material

    if not os.path.isfile(CHECKER_IMAGE_PATH):
        return None

    image = bpy.data.images.load(
        CHECKER_IMAGE_PATH,
        check_existing=True,
    )

    material = bpy.data.materials.new(CHECKER_MATERIAL_NAME)
    material.use_nodes = True

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    bsdf = nodes.get("Principled BSDF")

    image_node = nodes.new("ShaderNodeTexImage")
    image_node.image = image
    image_node.location = (-300, 300)

    if bsdf is not None:

        links.new(
            image_node.outputs["Color"],
            bsdf.inputs["Base Color"],
        )

    return material


# =========================================================
# Assign Checker Material
# =========================================================

def assign_checker_material(meshes, material):
    """
    Replace every mesh's material slots with just Checker,
    so every face uses it regardless of material index.
    """

    assigned = 0

    for obj in meshes:

        obj.data.materials.clear()
        obj.data.materials.append(material)

        assigned += 1

    return assigned

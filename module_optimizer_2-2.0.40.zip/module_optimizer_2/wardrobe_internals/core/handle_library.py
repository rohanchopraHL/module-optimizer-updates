"""
============================================================
Wardrobe Internals

Handle Library

Scans the bundled handle asset folder for .fbx files and
exposes them as EnumProperty items for the Handle Library
UI. Drop additional .fbx handles into this folder and they
show up in the dropdown automatically.
============================================================
"""

import os


# =========================================================
# Library Location
# =========================================================

ADDON_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

HANDLE_LIBRARY_DIR = os.path.join(
    ADDON_DIR,
    "assets",
    "handles",
)


# =========================================================
# List Handle Assets
# =========================================================

def list_handle_assets():
    """
    Sorted list of .fbx filenames found in the
    handle library folder.
    """

    if not os.path.isdir(HANDLE_LIBRARY_DIR):
        return []

    return sorted(
        filename
        for filename in os.listdir(HANDLE_LIBRARY_DIR)
        if filename.lower().endswith(".fbx")
    )


# =========================================================
# Resolve Selected Asset Path
# =========================================================

def get_handle_filepath(filename):
    """
    Resolve a handle library filename to its full path.
    """

    return os.path.join(HANDLE_LIBRARY_DIR, filename)


# =========================================================
# Enum Items Callback
# =========================================================

# Blender requires the strings returned by a dynamic
# EnumProperty items callback to stay alive - caching the
# list on the module avoids them being garbage collected.
_enum_items_cache = []


def get_handle_enum_items(self, context):
    """
    Build EnumProperty items from the handle library folder.
    """

    global _enum_items_cache

    filenames = list_handle_assets()

    if not filenames:

        _enum_items_cache = [
            (
                "NONE",
                "No Handles Found",
                "Add .fbx files to wardrobe_internals/assets/handles",
            )
        ]

        return _enum_items_cache

    _enum_items_cache = [
        ("NONE", "Select", "Choose a handle from the library"),
    ] + [
        (
            filename,
            os.path.splitext(filename)[0],
            get_handle_filepath(filename),
        )
        for filename in filenames
    ]

    return _enum_items_cache

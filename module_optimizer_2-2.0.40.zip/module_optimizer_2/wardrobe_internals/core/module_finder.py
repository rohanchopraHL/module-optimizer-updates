import bpy

from ..config import PART_PREFIX


class ModuleFinder:

    @staticmethod
    def find_parts(module):

        parts = []

        if module is None:
            return parts

        for child in module.children:

            if child.name.startswith(PART_PREFIX):
                parts.append(child)

        return parts

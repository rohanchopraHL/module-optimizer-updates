"""
============================================================
Wardrobe Internals

Hanger Rod

Placement math for the Hanger Rod - unlike a Handle, it isn't
dropped "on a face": no Place On needed at all. Its length is
sized against the module's own widest face (the greatest X
extent among its meshes, found automatically - not tied to any
particular naming like "Fixed Shelf"; Full Rod matches it
exactly, Half Rod is half of it, flush with the picked side),
and Height / Full-or-Half / Left-or-Right all come from one
popup dialog (ops/hanger_rod.py) instead of a Left/Center/Right
pick.
============================================================
"""

import os

from mathutils import Vector

from ..config import (
    HANGER_ROD_ASSET_NAME,
    HANGER_ROD_TOP_OFFSET_MM,
    HANGER_ROD_DROP_MM,
    HANGER_ROD_MID_DROP_MM,
    HANGER_ROD_HALF_GAP_MM,
    HANDLE_SUFFIX,
    HANGER_ROD_SUFFIX,
)

from .nudge import resolve_world_offset


# =========================================================
# Is This Asset The Hanger Rod?
# =========================================================

def is_hanger_rod(asset_filename):
    """
    True if asset_filename (e.g. "Hanger Rod.fbx") is the
    bundled Hanger Rod asset, matched by filename stem - same
    check ops/handle_library.py's ASSET_SUFFIX_OVERRIDES uses
    for naming.
    """

    stem = os.path.splitext(asset_filename)[0]

    return stem == HANGER_ROD_ASSET_NAME


# =========================================================
# Find Widest Face
# =========================================================

# Placed hardware (Handles, a previous Hanger Rod) shouldn't
# count as a "face" to size against - only structural panels.
_HARDWARE_MARKERS = (
    f"_{HANDLE_SUFFIX}_",
    f"_{HANGER_ROD_SUFFIX}_",
)


def find_widest_face(root):
    """
    The module's own mesh with the greatest X extent (world
    bounding box width) under root - the Hanger Rod sizes
    against whichever face is widest, not a specifically-named
    one. Returns None if root has no (non-hardware) mesh
    geometry at all.
    """

    widest = None
    widest_width = -1.0

    for obj in root.children_recursive:

        if obj.type != 'MESH' or not obj.bound_box:
            continue

        if any(marker in obj.name for marker in _HARDWARE_MARKERS):
            continue

        corners = [
            obj.matrix_world @ Vector(corner)
            for corner in obj.bound_box
        ]

        xs = [c.x for c in corners]

        width = max(xs) - min(xs)

        if width > widest_width:
            widest_width = width
            widest = obj

    return widest


# =========================================================
# Face Bounds
# =========================================================

def compute_face_bounds(face):
    """
    World-space (min_x, max_x, center_y) of face's bounding
    box - the reference width/depth the rod sizes against.
    """

    corners = [
        face.matrix_world @ Vector(corner)
        for corner in face.bound_box
    ]

    xs = [c.x for c in corners]
    ys = [c.y for c in corners]

    min_x, max_x = min(xs), max(xs)
    center_y = (min(ys) + max(ys)) / 2.0

    return min_x, max_x, center_y


# =========================================================
# Rod Length + Location
# =========================================================

def compute_rod_placement(face, height_mm, rod_type, side, z_location):
    """
    Returns (length, location) for the Hanger Rod, both in
    world units, sized against `face` (the module's widest
    face - see find_widest_face()):

    - length: Full Rod matches face's own width exactly. Half
      Rod is (face width / 2) - HANGER_ROD_HALF_GAP_MM (clears
      a center support), flush with the picked side (its outer
      edge lines up with face's own edge on that side).
    - location: world-space Vector for the rod's own origin,
      which sits at the rod's TOP edge, centered on its own
      length (see the bundled asset's geometry) - X/Y center
      the rod on its target span and face's own depth, Z comes
      from height_mm via HANGER_ROD_TOP_OFFSET_MM and the
      `z_location` drop ('TOP' -> HANGER_ROD_DROP_MM,
      'MID' -> HANGER_ROD_MID_DROP_MM).
    """

    min_x, max_x, center_y = compute_face_bounds(face)

    width = max_x - min_x

    if rod_type == 'HALF':

        gap = resolve_world_offset(face, HANGER_ROD_HALF_GAP_MM)

        length = width / 2.0 - gap

        x = (
            min_x + length / 2.0
            if side == 'LEFT'
            else max_x - length / 2.0
        )

    else:

        length = width
        x = (min_x + max_x) / 2.0

    drop_mm = (
        HANGER_ROD_MID_DROP_MM if z_location == 'MID'
        else HANGER_ROD_DROP_MM
    )

    z_mm = height_mm - HANGER_ROD_TOP_OFFSET_MM - drop_mm
    z = resolve_world_offset(face, z_mm)

    return length, Vector((x, center_y, z))

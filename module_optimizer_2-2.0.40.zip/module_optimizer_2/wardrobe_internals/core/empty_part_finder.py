import bpy

from ..config import PART_PREFIX


class EmptyPartFinder:
    """
    Finds empty Part.xxx objects.

    A Part is considered EMPTY when:
    - It is an EMPTY object.
    - It has no children.
    """

    @staticmethod
    def find_empty_parts(module_root):
        empty_parts = []

        if module_root is None:
            return empty_parts

        for obj in module_root.children:

            # Only Part.xxx objects
            if not obj.name.startswith(PART_PREFIX):
                continue

            # Must be an Empty object
            if obj.type != 'EMPTY':
                continue

            # No children = Empty Part
            if len(obj.children) == 0:
                empty_parts.append(obj)

        return empty_parts

    @staticmethod
    def delete_empty_parts(empty_parts):
        deleted = 0

        for obj in empty_parts:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
                deleted += 1

        return deleted

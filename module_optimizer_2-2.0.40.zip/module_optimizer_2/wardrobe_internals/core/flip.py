"""
============================================================
Wardrobe Internals

Flip

Reverses face winding (equivalent to Edit Mode's Mesh >
Normals > Flip) on every mesh under the module root, after
Flip's mirror has been baked into vertex data by
core/freeze.freeze_hierarchy().

Needed because baking a negative-determinant transform (the
Scale -1/-1/-1 Flip applies) straight into vertex coordinates
via Mesh.transform() does NOT auto-correct face winding the
way Object > Apply > Transform does - so every face ends up
facing inward unless corrected here.
============================================================
"""

import bmesh


# =========================================================
# Flip Normals On The Whole Hierarchy
# =========================================================

def flip_normals(main_empty):
    """
    Reverse every face's winding on every mesh under
    main_empty (main_empty included, in case it somehow has
    mesh data). Returns the number of meshes corrected.
    """

    all_objects = [main_empty] + list(main_empty.children_recursive)

    meshes = [obj for obj in all_objects if obj.type == 'MESH']

    for obj in meshes:
        flip_mesh_normals(obj)

    return len(meshes)


def flip_mesh_normals(obj):
    """Reverse every face's winding on one mesh object."""

    data = obj.data

    bm = bmesh.new()
    bm.from_mesh(data)

    bmesh.ops.reverse_faces(bm, faces=bm.faces)

    bm.to_mesh(data)
    bm.free()

    data.update()

"""
============================================================
Wardrobe Internals

CleanUp Module - strip carcass, keep internals

For the Wardrobe Internals workflow, CleanUp Module keeps only
the module's internal components. It deletes the outer carcass
panels - detected purely by position:

- Top panel    : the Part whose mesh sits highest (+Z)
- Bottom panel : the lowest full-width Part
- Left panel   : the Part furthest at the -X end
- Right panel  : the Part furthest at the +X end
- Back panel   : the thin Part furthest at the +Y end (rear)
- Skirting     : a short, shallow Part sitting below the bottom
                 panel (deleted only when present)

Every remaining internal Part then has all of its Face meshes
joined into one single mesh, which is parented directly under
the module root - the Part sub-groups are deleted, so every
internal face ends up inside the main group only. No EdgeBand,
no Front/Back classification, since internals don't need that
naming.

Detection is skipped (leaving every Part in place) when the
module has fewer than MIN_PARTS_FOR_PANEL_STRIP Parts or its
root already carries the INTERNALS_STRIPPED_FLAG, so a second
CleanUp pass never eats the internals.
============================================================
"""

import bpy

from mathutils import Matrix, Vector

from ..config import (
    BOTTOM_PANEL_MIN_WIDTH_MM,
    BACK_PANEL_MAX_DEPTH_RATIO,
    SKIRTING_MAX_DEPTH_RATIO,
    SKIRTING_MAX_HEIGHT_MM,
    MIN_PARTS_FOR_PANEL_STRIP,
    INTERNALS_STRIPPED_FLAG,
)

from .module_finder import ModuleFinder
from .geometry_analyzer import GeometryAnalyzer
from .common import join_objects


# =========================================================
# Part Extents (Real Millimeters)
# =========================================================

def compute_part_extents(part):
    """
    World-space size and center of a Part's mesh descendants,
    converted to real millimeters with one shared meter/mm
    auto-detection based on the largest raw dimension (raw
    Blender values aren't reliably in mm - see
    GeometryAnalyzer.detect_unit).

    Returns a dict with width (X), depth (Y), height (Z) and
    center cx / cy / cz, or None if the Part has no mesh
    geometry.
    """

    mins = [None, None, None]
    maxs = [None, None, None]

    for obj in part.children_recursive:

        if obj.type != 'MESH':
            continue

        for corner in obj.bound_box:

            world = obj.matrix_world @ Vector(corner)

            for axis, value in enumerate((world.x, world.y, world.z)):

                if mins[axis] is None or value < mins[axis]:
                    mins[axis] = value

                if maxs[axis] is None or value > maxs[axis]:
                    maxs[axis] = value

    if mins[0] is None:
        return None

    raw = [maxs[axis] - mins[axis] for axis in range(3)]

    unit = GeometryAnalyzer.detect_unit(raw)

    extent = [GeometryAnalyzer.convert_to_mm(r, unit) for r in raw]

    center = [
        GeometryAnalyzer.convert_to_mm((mins[axis] + maxs[axis]) / 2.0, unit)
        for axis in range(3)
    ]

    return {
        "width": extent[0],
        "depth": extent[1],
        "height": extent[2],
        "cx": center[0],
        "cy": center[1],
        "cz": center[2],
    }


# =========================================================
# Carcass Panel Detection
# =========================================================

def find_carcass_panels(parts):
    """
    Position-based detection of the module's outer carcass
    panels. Returns a dict mapping any of the roles 'top',
    'bottom', 'left', 'right', 'back', 'skirting' to the Part
    object that fills it (roles with no match are omitted).
    """

    metrics = []

    for part in parts:

        extents = compute_part_extents(part)

        if extents is None:
            continue

        metrics.append((part, extents))

    if not metrics:
        return {}

    module_depth = max(extents["depth"] for _, extents in metrics)

    picks = {}

    # -----------------------------------------------------
    # Left / Right : the two X extremes
    # -----------------------------------------------------

    by_x = sorted(metrics, key=lambda item: item[1]["cx"])

    picks["left"] = by_x[0][0]
    picks["right"] = by_x[-1][0]

    # -----------------------------------------------------
    # Top : the highest Z center
    # -----------------------------------------------------

    picks["top"] = max(metrics, key=lambda item: item[1]["cz"])[0]

    # -----------------------------------------------------
    # Back : the thin Part at the +Y (rear) extreme
    # -----------------------------------------------------
    # Guarded by a thinness check so a module with no back
    # panel keeps its rearmost internal Part instead.

    back_part, back_extents = max(metrics, key=lambda item: item[1]["cy"])

    if back_extents["depth"] < BACK_PANEL_MAX_DEPTH_RATIO * module_depth:
        picks["back"] = back_part

    # -----------------------------------------------------
    # Bottom / Skirting : the lowest full-width Part(s)
    # -----------------------------------------------------
    # A skirting/kickboard is full width too, but sits below
    # the bottom panel and is a shallow, upright board rather
    # than a full-depth horizontal one.

    wide = [
        item for item in metrics
        if item[1]["width"] >= BOTTOM_PANEL_MIN_WIDTH_MM
    ]

    by_z = sorted(wide or metrics, key=lambda item: item[1]["cz"])

    if by_z:

        lowest_part, lowest_extents = by_z[0]

        is_skirting = (
            len(by_z) > 1
            and lowest_extents["depth"] < SKIRTING_MAX_DEPTH_RATIO * module_depth
            and lowest_extents["height"] <= SKIRTING_MAX_HEIGHT_MM
        )

        if is_skirting:
            picks["skirting"] = lowest_part
            picks["bottom"] = by_z[1][0]
        else:
            picks["bottom"] = lowest_part

    return picks


# =========================================================
# Delete A Part (And Everything Under It)
# =========================================================

def delete_part(part):
    """
    Remove a Part Empty and every object beneath it.
    """

    for obj in reversed(list(part.children_recursive)):

        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)

    if part.name in bpy.data.objects:
        bpy.data.objects.remove(part, do_unlink=True)


# =========================================================
# Combine One Part's Faces And Flatten Under The Root
# =========================================================

def combine_and_flatten_part(context, main_empty, part):
    """
    Join every mesh under `part` into one, parent that single
    mesh directly under the module root (keeping its world
    position), and delete `part` and any Empty left under it -
    so every internal face ends up directly inside the main
    group, with no Part sub-groups.

    Returns the combined mesh, or None if `part` had no mesh
    geometry (in which case `part` is still deleted).
    """

    meshes = [
        obj for obj in part.children_recursive
        if obj.type == 'MESH'
    ]

    survivor = join_objects(context, meshes) if meshes else None

    if survivor is not None:

        world = survivor.matrix_world.copy()

        survivor.parent = main_empty
        survivor.matrix_parent_inverse = Matrix.Identity(4)
        survivor.matrix_world = world

    for obj in reversed(list(part.children_recursive)):

        if obj is survivor:
            continue

        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)

    if part is not survivor and part.name in bpy.data.objects:
        bpy.data.objects.remove(part, do_unlink=True)

    return survivor


# =========================================================
# Strip To Internals
# =========================================================

def strip_to_internals(context, main_empty):
    """
    Delete the module's outer carcass panels (top, bottom,
    left, right, back) and skirting, then join every remaining
    internal Part's faces into one mesh and move it directly
    under the module root - no Part sub-groups are kept.

    Returns (deleted_panels, combined_parts).
    """

    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    parts = ModuleFinder.find_parts(main_empty)

    deleted_panels = 0

    already_stripped = bool(main_empty.get(INTERNALS_STRIPPED_FLAG))

    if len(parts) >= MIN_PARTS_FOR_PANEL_STRIP and not already_stripped:

        picks = find_carcass_panels(parts)

        to_delete = {
            part for part in picks.values() if part is not None
        }

        # Never delete every Part - if the picks somehow cover
        # the whole module, leave it untouched rather than wipe it.
        if to_delete and len(to_delete) < len(parts):

            for part in to_delete:
                delete_part(part)

            deleted_panels = len(to_delete)
            main_empty[INTERNALS_STRIPPED_FLAG] = True

    # -----------------------------------------------------
    # Combine each remaining Part's faces, flatten under root
    # -----------------------------------------------------

    combined_parts = 0

    for part in ModuleFinder.find_parts(main_empty):

        if combine_and_flatten_part(context, main_empty, part) is not None:
            combined_parts += 1

    return deleted_panels, combined_parts

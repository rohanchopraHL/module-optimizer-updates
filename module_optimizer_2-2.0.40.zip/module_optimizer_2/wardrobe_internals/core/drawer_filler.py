"""
============================================================
Wardrobe Internals

Flip Drawer Filler

Mirrors a Drawer Filler's whole drawer row in X - the same
steps as doing it by hand:

1. Find the row: every Internal Drawer ("int-dwr", which also
   covers glass drawers and their "int-dwr_han" handles) and
   Handle ("_han_") at the filler's height, chained sideways
   from the filler (each within 30mm of the next, so drawers
   either side of an 18mm divider count as one row).
2. Then, depending on the drawers (not their handles):

   - All the same width -> SLIDE: the drawers and handles move
     across by the filler's width into its place, and the
     filler is mirrored onto the other end.
   - Different widths -> MIRROR: the filler, the drawers and
     their handles are mirrored in X about the row's centre.
     The filler goes to the other end, the drawers swap sides
     with it (a narrower drawer that sat next to the filler is
     next to it again), and each drawer's own box is mirrored
     under its front.

   Normals are corrected on everything mirrored, like Flip
   Module.

Anything that isn't part of the row (dividers, shelves, other
handles) stays put. The row keeps its exact span; running it
again flips everything back.
============================================================
"""

from .depth_resizer import world_points, detect_layout
from .flip import flip_mesh_normals


FILLER_TAG = "dwr-flr"

DRAWER_TAGS = ("int-dwr", "_han_")

# Bridges an 18mm divider panel (plus clearance) between drawers.
TOUCH_TOLERANCE_MM = 30.0

# Drawers within this of each other count as "the same width".
SAME_WIDTH_TOLERANCE_MM = 1.0

HANDLE_TAG = "_han_"


# =========================================================
# Helpers
# =========================================================

def is_filler(obj):

    return obj.type == 'MESH' and FILLER_TAG in obj.name


def is_drawer_part(obj):

    return (
        obj.type == 'MESH'
        and not is_filler(obj)
        and any(tag in obj.name for tag in DRAWER_TAGS)
    )


def world_bounds(obj):
    """((min x, y, z), (max x, y, z)) in world space."""

    pts = world_points(obj)

    return (
        tuple(min(p[i] for p in pts) for i in range(3)),
        tuple(max(p[i] for p in pts) for i in range(3)),
    )


# =========================================================
# Find The Drawer Row
# =========================================================

def drawer_row(filler, candidates, tolerance, height):
    """
    Drawer parts in the filler's row: overlapping its height
    (world axis index `height`), chained sideways from it.
    """

    (f_lo, f_hi) = world_bounds(filler)

    same_height = []

    for obj in candidates:

        lo, hi = world_bounds(obj)

        if lo[height] < f_hi[height] - tolerance and hi[height] > f_lo[height] + tolerance:
            same_height.append((obj, lo[0], hi[0]))

    row = []
    x_lo, x_hi = f_lo[0], f_hi[0]

    grown = True

    while grown:

        grown = False

        for item in list(same_height):

            obj, lo, hi = item

            if lo <= x_hi + tolerance and hi >= x_lo - tolerance:
                row.append(obj)
                same_height.remove(item)
                x_lo, x_hi = min(x_lo, lo), max(x_hi, hi)
                grown = True

    return row


# =========================================================
# Flip
# =========================================================

def mirror_x(obj, centre):
    """Mirror obj's geometry in world X about `centre`."""

    inverse = obj.matrix_world.inverted()

    for vertex, world in zip(obj.data.vertices, world_points(obj)):
        world.x = 2.0 * centre - world.x
        vertex.co = inverse @ world

    obj.data.update()

    flip_mesh_normals(obj)


def drawers_same_width(row, tolerance):
    """True if every drawer (handles left out) is the same width."""

    widths = [
        hi[0] - lo[0]
        for lo, hi in (world_bounds(o) for o in row if HANDLE_TAG not in o.name)
    ]

    return not widths or max(widths) - min(widths) <= tolerance


def flip_drawer_filler(filler, candidates, module_meshes):
    """
    Flip filler to the other end of its drawer row - SLIDE when
    the drawers are all the same width, MIRROR the row when they
    differ (see the module docstring). Returns a dict: mode
    ('SLIDE' / 'MIRROR'), side ('LEFT' / 'RIGHT', where the
    filler ended up), width_mm (filler), moved (drawer parts).
    Raises ValueError if no drawer sits next to it.

    module_meshes (every mesh in the module) decide units and
    which axis is height - Z in the scene, Y in a re-imported
    .dae - the same detection the Depth Resizer uses.
    """

    depth_axis, _, u = detect_layout(
        {obj: world_points(obj) for obj in module_meshes},
        "AUTO",
    )

    height = 2 if depth_axis == 1 else 1

    tolerance = TOUCH_TOLERANCE_MM * u

    row = drawer_row(filler, candidates, tolerance, height)

    if not row:
        raise ValueError(f"No drawer found next to {filler.name}")

    (f_lo, f_hi) = world_bounds(filler)

    parts = [filler] + row

    row_lo = min(world_bounds(o)[0][0] for o in parts)
    row_hi = max(world_bounds(o)[1][0] for o in parts)

    centre = (row_lo + row_hi) / 2.0

    filler_on_right = (f_lo[0] + f_hi[0]) / 2.0 > centre

    width = f_hi[0] - f_lo[0]

    if drawers_same_width(row, SAME_WIDTH_TOLERANCE_MM * u):

        mode = 'SLIDE'

        # Drawers / handles: slide into the filler's old space.
        shift = width if filler_on_right else -width

        for obj in unique_meshes(row):
            translate_x(obj, shift)

        # Filler: mirror in X onto the other end of the row - its
        # outer edge lands on that end.
        if filler_on_right:
            mirror_x(filler, (row_lo + f_hi[0]) / 2.0)
        else:
            mirror_x(filler, (row_hi + f_lo[0]) / 2.0)

    else:

        mode = 'MIRROR'

        for obj in unique_meshes(parts):
            mirror_x(obj, centre)

    return {
        "mode": mode,
        "side": "LEFT" if filler_on_right else "RIGHT",
        "width_mm": width / u,
        "moved": len(row),
    }


def unique_meshes(objects):
    """Objects sharing one mesh are only moved once."""

    seen = set()

    for obj in objects:

        if obj.data in seen:
            continue

        seen.add(obj.data)

        yield obj


def translate_x(obj, shift):
    """Move obj's geometry in world X (its transform is untouched)."""

    inverse = obj.matrix_world.inverted()

    for vertex, world in zip(obj.data.vertices, world_points(obj)):
        world.x += shift
        vertex.co = inverse @ world

    obj.data.update()

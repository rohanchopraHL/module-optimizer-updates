"""
============================================================
Wardrobe Internals

Depth Resizer

Back-resizes a module's internals to a new shelf / floor
depth (ported from the standalone "Internal Depth Resizer"
script):

- Every vertex on the BACK half of the module (past the
  depth midpoint) slides toward the front by the difference
  between the current depth and the target depth - so panel
  thickness, the front edge and anything sitting at the front
  are untouched. Objects matching the "Never Scale" list don't
  move at all.
- The module is then re-centred on X and on the depth axis
  (height is never touched).
- UVs are re-projected per triangle so the texture keeps its
  scale instead of stretching with the geometry.
- Optionally rewrites "-<depth>-DC" in the module / object
  names to the new cabinet depth.

The current depth is measured each time, so resizing is
idempotent - running 422 twice is a no-op, and 422 -> 372 ->
327 can be chained. Units (m / mm) and the depth axis (Y for
an in-scene module, Z for a re-imported .dae) are detected
from the geometry.
============================================================
"""

import re

from mathutils import Matrix, Vector

from .geometry_analyzer import GeometryAnalyzer


# "-450-DC" at the end of the module name, or just before an
# appended width ("-450-DC-900W", see core/width_rescale.py).
DEPTH_NAME_PATTERN = re.compile(r"-\d+-DC(?=(?:-\d+W)?$)")


# =========================================================
# Module Meshes
# =========================================================

def module_meshes(root, selected_only=False, selected=()):
    """
    Every mesh under root (or only the selected ones under it).
    Meshes sharing one data-block are taken once, so shared
    geometry is never moved twice.
    """

    selected = set(selected)

    meshes = []
    seen_data = set()

    for obj in root.children_recursive:

        if obj.type != 'MESH' or obj.data is None:
            continue

        if selected_only and obj not in selected:
            continue

        if obj.data in seen_data:
            continue

        seen_data.add(obj.data)
        meshes.append(obj)

    return meshes


def parse_exclude(text):

    return [
        token.strip()
        for token in text.split(",")
        if token.strip()
    ]


def is_excluded(obj, exclude):

    return any(token in obj.name for token in exclude)


# =========================================================
# Layout Detection
# =========================================================

def world_points(obj):

    matrix = obj.matrix_world

    return [matrix @ v.co for v in obj.data.vertices]


def detect_layout(points_by_obj, axis_choice="AUTO"):
    """
    Return (axis_index, back_sign, units_per_mm).

    axis_index : 1 (Y) or 2 (Z)
    back_sign  : +1 if the back of the module is the + side
                 of that axis (Y layout), -1 if it's the -
                 side (re-imported .dae, Z layout)
    """

    all_points = [p for pts in points_by_obj.values() for p in pts]

    extent = [
        max(p[i] for p in all_points) - min(p[i] for p in all_points)
        for i in range(3)
    ]

    if axis_choice == "Y":
        axis = 1
    elif axis_choice == "Z":
        axis = 2
    else:
        axis = 1 if extent[1] <= extent[2] else 2

    back_sign = 1.0 if axis == 1 else -1.0

    unit = GeometryAnalyzer.detect_unit(extent)

    units_per_mm = 0.001 if unit == "METER" else 1.0

    return axis, back_sign, units_per_mm


def current_depth(points_by_obj, exclude, axis, units_per_mm):
    """
    Deepest single (non-excluded) mesh along the depth axis,
    in mm - the shelves / floor span the full depth.
    """

    depth = 0.0

    for obj, pts in points_by_obj.items():

        if not pts or is_excluded(obj, exclude):
            continue

        values = [p[axis] for p in pts]

        depth = max(depth, (max(values) - min(values)) / units_per_mm)

    return depth


# =========================================================
# Resize
# =========================================================

def resize_depth(meshes, shelf_depth_mm, exclude, axis_choice="AUTO"):
    """
    Resize meshes so the deepest one is shelf_depth_mm deep.

    Returns a dict: moved_mm (how far the back moved, + means
    shallower), from_mm, axis ('Y' / 'Z'), skipped_tris.
    """

    old = {obj: world_points(obj) for obj in meshes}

    axis, back_sign, u = detect_layout(old, axis_choice)

    from_mm = current_depth(old, exclude, axis, u)

    delta = (from_mm - shelf_depth_mm) * u

    # Back half = past the midpoint of the scalable geometry.
    scalable = [
        p[axis]
        for obj, pts in old.items()
        if not is_excluded(obj, exclude)
        for p in pts
    ]

    mid = (min(scalable) + max(scalable)) / 2.0 if scalable else 0.0

    new = {}

    for obj, pts in old.items():

        moved = [p.copy() for p in pts]

        if not is_excluded(obj, exclude):

            for p in moved:

                if (p[axis] - mid) * back_sign > 0.0:
                    p[axis] -= back_sign * delta

        new[obj] = moved

    # Re-centre on X and the depth axis (never height).
    all_new = [p for pts in new.values() for p in pts]

    if all_new:

        for i in (0, axis):

            shift = -(
                min(p[i] for p in all_new) + max(p[i] for p in all_new)
            ) / 2.0

            for p in all_new:
                p[i] += shift

    skipped = 0

    for obj in meshes:
        skipped += write_mesh(obj, old[obj], new[obj], u)

    return {
        "moved_mm": delta / u,
        "from_mm": from_mm,
        "axis": "Y" if axis == 1 else "Z",
        "skipped_tris": skipped,
    }


def write_mesh(obj, old_pts, new_pts, units_per_mm):
    """
    Re-project the active UV layer for the new vertex
    positions (each triangle's UV mapping is extended
    linearly, so the texture density is kept), then write the
    new positions back. Returns the zero-area tris skipped.
    """

    mesh = obj.data

    skipped = 0

    uv_layer = mesh.uv_layers.active

    if uv_layer is not None:

        mesh.calc_loop_triangles()

        uv_data = uv_layer.data

        result = {}

        min_area = 1e-12 * units_per_mm * units_per_mm

        for tri in mesh.loop_triangles:

            vi, li = tri.vertices, tri.loops

            p0 = old_pts[vi[0]]
            e1 = old_pts[vi[1]] - p0
            e2 = old_pts[vi[2]] - p0

            normal = e1.cross(e2)

            if normal.length < min_area:
                skipped += 1
                continue

            normal = normal.normalized() * (e1.length * e2.length) ** 0.5

            basis_inv = Matrix((
                (e1.x, e2.x, normal.x),
                (e1.y, e2.y, normal.y),
                (e1.z, e2.z, normal.z),
            )).inverted()

            uv0 = uv_data[li[0]].uv.copy()
            du1 = uv_data[li[1]].uv - uv0
            du2 = uv_data[li[2]].uv - uv0

            for k in range(3):

                x = basis_inv @ (new_pts[vi[k]] - p0)

                result[li[k]] = uv0 + du1 * x.x + du2 * x.y

        for loop_index, uv in result.items():
            uv_data[loop_index].uv = uv

    inverse = obj.matrix_world.inverted()

    for vertex, world in zip(mesh.vertices, new_pts):
        vertex.co = inverse @ world

    mesh.update()

    return skipped


# =========================================================
# Rename
# =========================================================

def depth_name(name, cabinet_depth):
    """
    "HW..-450-DC_fxd-shlf_01" -> "HW..-400-DC_fxd-shlf_01".
    Only the module-name part (before the first "_") changes.
    """

    prefix, separator, rest = name.partition("_")

    prefix = DEPTH_NAME_PATTERN.sub(f"-{cabinet_depth}-DC", prefix)

    return prefix + separator + rest


def rename_for_depth(objects, cabinet_depth):

    renamed = 0

    for obj in objects:

        new_name = depth_name(obj.name, cabinet_depth)

        if new_name != obj.name:
            obj.name = new_name
            renamed += 1

    return renamed


# =========================================================
# Snapshot / Restore
# =========================================================

def take_snapshot(root, meshes):
    """
    Remember vertex positions, active UVs and names so a batch
    run can put the module back exactly as it was.
    """

    snapshot = {"names": {}, "meshes": []}

    for obj in [root] + list(root.children_recursive):
        snapshot["names"][obj] = obj.name

    for obj in meshes:

        mesh = obj.data

        coords = [0.0] * (len(mesh.vertices) * 3)
        mesh.vertices.foreach_get("co", coords)

        uvs = None
        uv_layer = mesh.uv_layers.active

        if uv_layer is not None:
            uvs = [0.0] * (len(uv_layer.data) * 2)
            uv_layer.data.foreach_get("uv", uvs)

        snapshot["meshes"].append((obj, coords, uvs))

    return snapshot


def restore_snapshot(snapshot):

    for obj, coords, uvs in snapshot["meshes"]:

        mesh = obj.data

        mesh.vertices.foreach_set("co", coords)

        uv_layer = mesh.uv_layers.active

        if uvs is not None and uv_layer is not None:
            uv_layer.data.foreach_set("uv", uvs)

        mesh.update()

    for obj, name in snapshot["names"].items():

        if obj.name != name:
            obj.name = name

"""
============================================================
Wardrobe Internals

Panel Conventions

Shared logic behind the Panel Conventions buttons (Fixed
Shelf, Removable Shelf, Drawer Filler, Internal Drawer,
Vertical Panel).

Works with either input a module can be in:
- New Module (still one combined mesh): select faces in Edit
  Mode, Face select - the selection is separated out into its
  own named object(s).
- Existing Module (panels already their own objects, e.g.
  "Face.030"): select one or more whole objects in Object Mode
  - each is renamed in place (or joined, for Internal Drawer),
  no Edit Mode needed.

Either way the result is parented directly under the module
root.
============================================================
"""

import bpy
import bmesh

from mathutils import Vector

from .hierarchy import find_root_empty, find_topmost_ancestor


# =========================================================
# Normalize To A List
# =========================================================

def _as_list(objects):

    if isinstance(objects, bpy.types.Object):
        return [objects]

    return list(objects)


# =========================================================
# Resolve Module Name
# =========================================================

def resolve_module_name(context, objects):
    """
    Module Name field first (Step 2 workflow), falling back to
    whichever candidate object actually has a usable parent
    chain - root Empty first, then plain topmost ancestor - same
    fallback order Handle Library / hl_modules_optimizer's Edit
    Convention use. `objects` is a single object or a list (an
    Existing Module selection can span several already-separate
    Face objects).
    """

    module_name = context.scene.mo2wi.module_name.strip()

    if module_name:
        return module_name

    objects = _as_list(objects)

    for obj in objects:

        root = find_root_empty(obj)

        if root is not None:
            return root.name

    for obj in objects:

        top = find_topmost_ancestor(obj)

        if top is not None and top is not obj:
            return top.name

    return ""


# =========================================================
# Resolve Module Root
# =========================================================

def resolve_root(objects):
    """
    First candidate object's root Empty - see resolve_module_name().
    """

    for obj in _as_list(objects):

        root = find_root_empty(obj)

        if root is not None:
            return root

    return None


# =========================================================
# Has Face Selection
# =========================================================

def has_selected_faces(obj):
    """
    True if obj (in Edit Mode) currently has at least one
    face selected.
    """

    bm = bmesh.from_edit_mesh(obj.data)

    return any(face.select for face in bm.faces)


# =========================================================
# Separate Selected Faces
# =========================================================

def separate_selected_faces(obj):
    """
    Separate obj's current face selection out to its own new
    object and drop back to Object Mode. Returns that new
    object, or None if nothing was selected.
    """

    before = set(bpy.data.objects)

    bpy.ops.mesh.separate(type='SELECTED')

    bpy.ops.object.mode_set(mode='OBJECT')

    new_objects = list(set(bpy.data.objects) - before)

    return new_objects[0] if new_objects else None


# =========================================================
# Split Into Islands
# =========================================================

def split_into_islands(context, obj):
    """
    Split obj into one object per connected piece of geometry.

    obj is expected to contain ONLY the faces separated out by
    separate_selected_faces() above, so a LOOSE-parts separate
    here only ever splits that selection - it can't reach back
    into the rest of the module.
    """

    bpy.ops.object.select_all(action='DESELECT')

    obj.select_set(True)
    context.view_layer.objects.active = obj

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    before = set(bpy.data.objects)

    bpy.ops.mesh.separate(type='LOOSE')

    bpy.ops.object.mode_set(mode='OBJECT')

    new_objects = list(set(bpy.data.objects) - before)

    return [obj] + new_objects


# =========================================================
# Island Sort Key
# =========================================================

def island_sort_key(obj):
    """
    Left-to-right (X), then top-to-bottom (Z), then Y - so
    numbering hands out in a predictable reading order when
    several islands are separated in one go.
    """

    if obj.type == 'MESH' and obj.bound_box:

        corners = [
            obj.matrix_world @ Vector(corner)
            for corner in obj.bound_box
        ]

        center = sum(corners, Vector()) / len(corners)

    else:

        center = obj.matrix_world.translation

    return (round(center.x, 3), round(-center.z, 3), round(center.y, 3))

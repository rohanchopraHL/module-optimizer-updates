"""
============================================================
Wardrobe Internals

Nudge

Shared logic behind the Nudge Up button - moves the current
selection straight up (world +Z) by a fixed distance, in
whichever units the module is actually built in (same
meter-vs-millimeter detection GeometryAnalyzer already uses
elsewhere - see core/geometry_analyzer.py).

Works with either input a module can be in, same as Panel
Conventions:
- New Module (still one combined mesh): select faces in Edit
  Mode, Face select - only those faces' vertices move.
- Existing Module (panels already their own objects): select
  one or more whole objects in Object Mode - each object moves.
============================================================
"""

import bmesh

from .geometry_analyzer import GeometryAnalyzer


# =========================================================
# Resolve World Offset
# =========================================================

def resolve_world_offset(objects, value_mm):
    """
    Convert value_mm to native Blender units, detected from the
    combined dimensions of `objects` (a single object or a list) -
    same "largest dimension < 10 -> meters" heuristic
    GeometryAnalyzer.detect_unit() uses everywhere else.
    """

    if hasattr(objects, "dimensions"):
        objects = [objects]

    dimensions = []

    for obj in objects:

        if obj.type == 'MESH':

            dimensions.extend([
                obj.dimensions.x,
                obj.dimensions.y,
                obj.dimensions.z,
            ])

    unit = GeometryAnalyzer.detect_unit(dimensions)

    if unit == "METER":
        return value_mm / 1000.0

    return value_mm


# =========================================================
# Nudge Edit-Mode Face Selection
# =========================================================

def nudge_edit_faces(obj, offset):
    """
    Move obj's currently-selected faces (Edit Mode) up by
    `offset` in world +Z - works regardless of obj's own
    rotation/scale, since each vertex is converted to world
    space, offset, then converted back.

    Returns the number of vertices moved.
    """

    bm = bmesh.from_edit_mesh(obj.data)

    verts = {
        vert
        for face in bm.faces if face.select
        for vert in face.verts
    }

    if not verts:
        return 0

    world = obj.matrix_world
    world_inverse = world.inverted()

    for vert in verts:

        world_co = world @ vert.co
        world_co.z += offset

        vert.co = world_inverse @ world_co

    bmesh.update_edit_mesh(obj.data)

    return len(verts)


# =========================================================
# Nudge Object-Mode Selection
# =========================================================

def nudge_objects(objects, offset):
    """
    Move each of `objects` up by `offset` in world +Z, however
    it's parented/rotated - each object's world matrix is
    offset directly rather than assuming its `location` axis
    lines up with world Z.

    Returns the number of objects moved.
    """

    moved = 0

    for obj in objects:

        world = obj.matrix_world.copy()
        world.translation.z += offset

        obj.matrix_world = world

        moved += 1

    return moved

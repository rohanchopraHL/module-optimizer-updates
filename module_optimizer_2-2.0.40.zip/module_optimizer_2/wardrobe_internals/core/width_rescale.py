"""
============================================================
Wardrobe Internals

Width Rescale

Rescales a module's internals to a new overall width (X),
spreading the change EQUALLY over its bays:

- Bays are the gaps between vertical panels. A vertical panel
  is any loose part of a mesh that is thin in X (<= 30mm) and
  at least 300mm tall - so a Vertical Panel object or one still
  inside a combined mesh both count, while drawer sides
  (thin but short) don't. Panels keep their thickness and just
  slide.
- In each bay, vertices on its right half move left by the
  bay's share (same idea as the Depth Resizer's back half), so
  shelves / floors / hanger rods get narrower while anything
  thinner than half a bay keeps its size.
- Objects matching "Never Scale" (default: handles) keep their
  size and slide with the bay they sit in, keeping their
  relative position in it (a centred handle stays centred).
- The module is re-centred on X (height and depth untouched),
  and UVs are re-projected like the Depth Resizer.
- Optionally appends the cabinet width to the module / object
  names: "...-450-DC" -> "...-450-DC-900W" (replaced, not
  stacked, on later runs).

The current width is measured each time, so it's idempotent.
============================================================
"""

import re

from .depth_resizer import (
    is_excluded,
    world_points,
    detect_layout,
    write_mesh,
)


WIDTH_NAME_PATTERN = re.compile(r"-\d+W$")

RIGID_MAX_THICKNESS_MM = 30.0
RIGID_MIN_HEIGHT_MM = 300.0


# =========================================================
# Vertical Panels
# =========================================================

def loose_parts(mesh):
    """Vertex-index lists, one per connected part."""

    parent = list(range(len(mesh.vertices)))

    def find(i):

        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]

        return i

    for edge in mesh.edges:

        a, b = find(edge.vertices[0]), find(edge.vertices[1])

        if a != b:
            parent[a] = b

    parts = {}

    for i in range(len(mesh.vertices)):
        parts.setdefault(find(i), []).append(i)

    return list(parts.values())


def vertical_panel_spans(points_by_obj, exclude, height_axis, units_per_mm):
    """
    Merged X spans (min, max) of every vertical panel found.
    """

    max_thickness = RIGID_MAX_THICKNESS_MM * units_per_mm
    min_height = RIGID_MIN_HEIGHT_MM * units_per_mm

    spans = []

    for obj, pts in points_by_obj.items():

        if not pts or is_excluded(obj, exclude):
            continue

        for part in loose_parts(obj.data):

            xs = [pts[i].x for i in part]
            hs = [pts[i][height_axis] for i in part]

            if (max(xs) - min(xs) <= max_thickness
                    and max(hs) - min(hs) >= min_height):
                spans.append((min(xs), max(xs)))

    spans.sort()

    merged = []

    for lo, hi in spans:

        if merged and lo <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], hi))
        else:
            merged.append((lo, hi))

    return merged


# =========================================================
# X Mapping
# =========================================================

def build_segments(x_min, x_max, panels, eps):
    """
    Split [x_min, x_max] into ('BAY', lo, hi) and
    ('PANEL', lo, hi) segments, left to right.
    """

    segments = []
    cursor = x_min

    for lo, hi in panels:

        lo, hi = max(lo, x_min), min(hi, x_max)

        if hi <= lo:
            continue

        if lo - cursor > eps:
            segments.append(('BAY', cursor, lo))

        segments.append(('PANEL', lo, hi))
        cursor = hi

    if x_max - cursor > eps:
        segments.append(('BAY', cursor, x_max))

    return segments


def make_shift(segments, bay_shrink, eps):
    """
    Return shift(x): how far a point at x moves left.
    """

    def shift(x):

        moved = 0.0

        for kind, lo, hi in segments:

            if kind == 'PANEL':

                if lo - eps <= x <= hi + eps:
                    return moved

                continue

            if x < lo - eps:
                return moved

            if x <= hi + eps:

                if x > (lo + hi) / 2.0:
                    return moved + bay_shrink

                return moved

            moved += bay_shrink

        return moved

    return shift


def make_slide(segments, bay_shrink, shift):
    """
    Return slide(x) for a Never Scale object's centre: inside a
    bay it keeps its relative position (a centred handle stays
    centred), elsewhere it follows shift(x).
    """

    def slide(x):

        moved = 0.0

        for kind, lo, hi in segments:

            if kind == 'BAY':

                if lo <= x <= hi:
                    t = (x - lo) / (hi - lo)
                    new_x = lo - moved + t * (hi - lo - bay_shrink)
                    return x - new_x

                moved += bay_shrink

        return shift(x)

    return slide


# =========================================================
# Rescale
# =========================================================

def rescale_width(meshes, width_mm, exclude):
    """
    Rescale meshes so the (non-excluded) internals are
    width_mm wide overall.

    Returns a dict: from_mm, moved_mm, bays_before /
    bays_after (mm), skipped_tris. Raises ValueError if a bay
    would end up 0mm or narrower.
    """

    old = {obj: world_points(obj) for obj in meshes}

    depth_axis, _, u = detect_layout(old, "AUTO")

    height_axis = 2 if depth_axis == 1 else 1

    scalable_x = [
        p.x
        for obj, pts in old.items()
        if not is_excluded(obj, exclude)
        for p in pts
    ]

    if not scalable_x:
        raise ValueError("Nothing to rescale (everything is in Never Scale)")

    x_min, x_max = min(scalable_x), max(scalable_x)

    from_mm = (x_max - x_min) / u

    eps = 0.5 * u

    panels = vertical_panel_spans(old, exclude, height_axis, u)

    segments = build_segments(x_min, x_max, panels, eps)

    bays = [hi - lo for kind, lo, hi in segments if kind == 'BAY']

    if not bays:
        raise ValueError("No bay found between the vertical panels")

    delta = (from_mm - width_mm) * u

    bay_shrink = delta / len(bays)

    bays_after = [b - bay_shrink for b in bays]

    if min(bays_after) <= eps:
        raise ValueError(
            f"{width_mm:.0f}mm is too narrow for {len(bays)} bay(s)"
        )

    shift = make_shift(segments, bay_shrink, eps)

    slide = make_slide(segments, bay_shrink, shift)

    new = {}

    for obj, pts in old.items():

        if is_excluded(obj, exclude):

            # Keep its size, slide with the bay it sits in.
            xs = [p.x for p in pts]
            moved = slide((min(xs) + max(xs)) / 2.0) if xs else 0.0

            new[obj] = [p.copy() for p in pts]

            for p in new[obj]:
                p.x -= moved

            continue

        moved_pts = [p.copy() for p in pts]

        for p in moved_pts:
            p.x -= shift(p.x)

        new[obj] = moved_pts

    # Re-centre on X only.
    all_new = [p for pts in new.values() for p in pts]

    centre = (min(p.x for p in all_new) + max(p.x for p in all_new)) / 2.0

    for p in all_new:
        p.x -= centre

    skipped = 0

    for obj in meshes:
        skipped += write_mesh(obj, old[obj], new[obj], u)

    return {
        "from_mm": from_mm,
        "moved_mm": delta / u,
        "bays_before": [b / u for b in bays],
        "bays_after": [b / u for b in bays_after],
        "skipped_tris": skipped,
    }


# =========================================================
# Rename
# =========================================================

def width_name(name, cabinet_width):
    """
    "HW..-450-DC_fxd-shlf_01" -> "HW..-450-DC-900W_fxd-shlf_01".
    Only the module-name part (before the first "_") changes;
    an earlier "-<n>W" is replaced, not stacked.
    """

    prefix, separator, rest = name.partition("_")

    prefix = WIDTH_NAME_PATTERN.sub("", prefix) + f"-{cabinet_width}W"

    return prefix + separator + rest


def rename_for_width(objects, cabinet_width, module_name):
    """
    Rename only objects carrying the module's name (the root and
    its Panel Convention / Handle children), like Apply Module
    Name - so unrelated names such as "Face.030" are left alone.
    """

    base = WIDTH_NAME_PATTERN.sub("", module_name)

    renamed = 0

    for obj in objects:

        prefix = obj.name.partition("_")[0]

        if WIDTH_NAME_PATTERN.sub("", prefix) != base:
            continue

        new_name = width_name(obj.name, cabinet_width)

        if new_name != obj.name:
            obj.name = new_name
            renamed += 1

    return renamed

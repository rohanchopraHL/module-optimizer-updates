bl_info = {
    "name": "Module Optimizer 2.0",
    "author": "Rohan Chopra",
    "version": (2, 0, 40),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Module Optimizer 2.0",
    "description": "Furniture module cleanup, EdgeBand generation, Carcass/Shutter "
    "naming conventions, handles, skirting, UV checker and Collada export.",
    "category": "Object",
}

import bpy

from bpy.props import PointerProperty

from .properties import MO2_Properties
from . import operators, ui, updates

# Category "Wardrobe Internals": the former Wardrobe Internals add-on,
# its own operators (mo2wi.*) and settings (scene.mo2wi).
from . import wardrobe_internals


classes = (MO2_Properties,) + operators.classes + ui.classes


def register():

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.mo2 = PointerProperty(type=MO2_Properties)

    wardrobe_internals.register()

    updates.register()


def unregister():

    updates.unregister()

    wardrobe_internals.unregister()

    del bpy.types.Scene.mo2

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

"""
Wardrobes conventions. Each button finds its panels by name inside the
module and names them directly in the main group (the module root).

Top / Bottom / Back / Side Panels ask With or Without OSL/BSL:

    Without   each whole panel        <module>_tp-pnl_01, _02 ...
    With      Front, Back, EdgeBand   <module>_tp-pnl_OSL_01, _BSL_01,
                                      _OSL_02, then _OSL_03, _BSL_02 ...

    Top Panel, Top Panel 1, 2 ...         tp-pnl
    Bottom Panel, Bottom Panel 1, 2 ...   bt-pnl
    Back Panel, Back Panel 1, 2 ...       bk-pnl
    Side Panel Left / Right               sd-pnl (left first; Without:
                                          sd-pnl_01 left, _02 right)

Vertical Panel (no popup): Centre Vertical Panel 1, 2 ... -> vt-pnl_NN.

Numbered panels keep their order (1, 2, 3 ...); new numbers continue
after ones already in the module. Converted panels are tagged, so
clicking again with the other option converts the same panels.
"""

import re

import bpy

from ..config import (
    TOP_PANEL_FACE,
    BOTTOM_PANEL_FACE,
    BACK_PANEL_FACE,
    VERTICAL_PANEL_FACE,
    SIDE_PANEL,
    OSL,
    BSL,
)

from .common import (
    MOError,
    require_root,
    ensure_module_name,
    make_name,
    next_index,
    join_objects,
    parent_to,
    refresh,
)

from .geometry import resolve_panel, reclassify


# "Top Panel", "Top Panel 2", "top_panel_3", "Top Panel 1.001" ...
def _numbered(words):

    return re.compile(rf"^\s*{words}(?:[\s_\-]*(\d+))?(?:\.\d+)?\s*$", re.I)


NUMBERED_PANELS = {
    "TOP_PANEL": (_numbered(r"top[\s_\-]*panel"), TOP_PANEL_FACE, "Top Panel"),
    "BOTTOM_PANEL": (_numbered(r"bottom[\s_\-]*panel"), BOTTOM_PANEL_FACE, "Bottom Panel"),
    "BACK_PANEL": (_numbered(r"back[\s_\-]*panel"), BACK_PANEL_FACE, "Back Panel"),
    "VERTICAL_PANEL": (_numbered(r"cent(?:re|er)[\s_\-]*vertical[\s_\-]*panel"), VERTICAL_PANEL_FACE, "Centre Vertical Panel"),
}

SIDE_PANELS = re.compile(r"^\s*side[\s_\-]*panel[\s_\-]*(left|right)(?:\.\d+)?\s*$", re.I)

# Buttons that ask With / Without OSL/BSL.
OSL_BSL_TOOLS = {"TOP_PANEL", "BOTTOM_PANEL", "BACK_PANEL", "SIDE_PANELS"}

# Custom properties on converted objects: which button, which panel.
ROLE_TAG = "mo2_wardrobe"
PANEL_TAG = "mo2_wardrobe_panel"


def _meshes(root):

    return [obj for obj in root.children_recursive if obj.type == 'MESH']


def _previous(root, tool):
    """[[objects of panel 1], [panel 2], ...] an earlier click converted."""

    panels = {}

    for obj in _meshes(root):
        if obj.get(ROLE_TAG) == tool:
            panels.setdefault(obj.get(PANEL_TAG, 0), []).append(obj)

    return [panels[key] for key in sorted(panels)]


def _found_numbered(root, pattern):
    """Raw meshes matching pattern, ordered by the number in their name."""

    found = []

    for obj in _meshes(root):
        match = pattern.match(obj.name)
        if match and ROLE_TAG not in obj:
            found.append((int(match.group(1) or 0), obj.name, obj))

    return [[obj] for _number, _name, obj in sorted(found, key=lambda item: item[:2])]


def _found_sides(root):
    """[[left], [right]] raw Side Panel meshes, or [] if either is missing."""

    sides = {}

    for obj in _meshes(root):
        match = SIDE_PANELS.match(obj.name)
        if match and ROLE_TAG not in obj:
            sides.setdefault(match.group(1).lower(), obj)

    missing = [side.title() for side in ("left", "right") if side not in sides]

    if missing and sides:
        raise MOError("No 'Side Panel " + " / ".join(missing) + "' found in the module.")

    return [[sides["left"]], [sides["right"]]] if not missing else []


def _convert(context, props, root, tool, suffix, panels, raw, with_osl, fixed_numbers=False):
    """
    Name each panel (a list of objects) for the chosen option, in the
    main group, and tag it. raw: how many panels at the end of the list
    are fresh imports (split with resolve_panel); the rest were
    converted before (any shape, reclassified).
    """

    module = props.module_name

    for objects in panels:
        for obj in objects:
            obj.name = "mo2_renaming"

    named = []

    for number, objects in enumerate(panels, start=1):

        fresh = number > len(panels) - raw

        if with_osl:

            if fresh:
                front, back, edgeband = resolve_panel(context, objects, root)
            else:
                front, back, edgeband = reclassify(context, objects, root)

            parts = []

            for obj, role in ((front, OSL), (back, BSL), (edgeband, OSL)):
                if obj is not None:
                    obj.name = make_name(module, f"{suffix}_{role}", next_index(module, f"{suffix}_{role}"))
                    parts.append(obj)

        else:

            whole = join_objects(context, objects)
            index = number if fixed_numbers else next_index(module, suffix)
            whole.name = make_name(module, suffix, index)
            parts = [whole]

        for obj in parts:
            obj[ROLE_TAG] = tool
            obj[PANEL_TAG] = number

        parent_to(root, parts)

        named.append(parts[0].name)

    bpy.ops.object.select_all(action='DESELECT')

    refresh(context)

    return named


def apply_panels(context, props, tool, with_osl=False):
    """Top / Bottom / Back Panel, Side Panels or Vertical Panel."""

    root = require_root(context)
    ensure_module_name(props, root)

    previous = _previous(root, tool)

    if tool == "SIDE_PANELS":

        fresh = _found_sides(root) if not previous else []
        panels = previous or fresh

        if not panels:
            raise MOError("No 'Side Panel Left / Right' found in the module.")

        named = _convert(context, props, root, tool, SIDE_PANEL, panels, len(fresh), with_osl, fixed_numbers=True)

        option = "With OSL/BSL" if with_osl else "Without OSL/BSL"

        return f"Side panels ({option}): " + ", ".join(named) + " (left first)."

    pattern, suffix, label = NUMBERED_PANELS[tool]

    fresh = _found_numbered(root, pattern)
    panels = previous + fresh

    if not panels:
        raise MOError(f"No '{label}' found in the module.")

    named = _convert(context, props, root, tool, suffix, panels, len(fresh), with_osl)

    option = "" if tool not in OSL_BSL_TOOLS else (" (With OSL/BSL)" if with_osl else " (Without OSL/BSL)")

    return f"{len(panels)} {label}(s){option}: " + ", ".join(named) + "."


def run(context, props, tool, with_osl=False):
    """Wardrobes button -> its function; None if that button isn't set up yet."""

    if tool in NUMBERED_PANELS or tool == "SIDE_PANELS":
        return apply_panels(context, props, tool, with_osl)

    return None

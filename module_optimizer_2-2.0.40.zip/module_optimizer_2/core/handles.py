"""
Handle Library: bundled .fbx handles (assets/handles - drop
more files in and they appear in the list), placed on a target
face and named '<module>_han_NN'.

Both orientations put the handle's centre at Height Position percent
of the face's height, measured from the bottom (50% = middle).
Horizontal: centred in X. Vertical: rotated upright, 40mm in from
the Left or Right side.
"""

import os

from math import radians

import bpy

from mathutils import Vector

from ..config import (
    HANDLE_SUFFIX,
    HANDLE_TAG,
    HANDLE_EDGE_MARGIN_MM,
    HANDLE_HEIGHT_PERCENT_DEFAULT,
    LOCK_SUFFIX,
    LOCK_FILE,
    LOCK_GAP_MM,
    SHUTTER_FRONT,
)

from .common import (
    MOError,
    make_name,
    next_index,
    join_objects,
    parent_to,
    topmost,
    world_corners,
    mm_to_native,
    select_only,
    ensure_object_mode,
    is_handle,
)

from .shutter import spatial_order


# =========================================================
# Library
# =========================================================

HANDLE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets",
    "handles",
)

LOCK_PATH = os.path.join(os.path.dirname(HANDLE_DIR), "locks", LOCK_FILE)

# A selected Shutter group puts its handle on this child: '<module>_sh-ft_NN'.
FRONT_TAG = f"_{SHUTTER_FRONT}_"


def list_handles():

    if not os.path.isdir(HANDLE_DIR):
        return []

    return sorted(f for f in os.listdir(HANDLE_DIR) if f.lower().endswith(".fbx"))


# Blender needs dynamic enum strings kept alive.
_enum_cache = []


def handle_enum_items(self, context):

    global _enum_cache

    files = list_handles()

    if not files:
        _enum_cache = [("NONE", "No Handles Found", f"Add .fbx files to {HANDLE_DIR}")]
    else:
        _enum_cache = [("NONE", "Select", "Choose a handle")] + [
            (f, os.path.splitext(f)[0], os.path.join(HANDLE_DIR, f)) for f in files
        ]

    return _enum_cache


# =========================================================
# Placement
# =========================================================

def _target_frame(target):
    """(min_x, max_x, mid_y, min_z, max_z) of the target in world space."""

    corners = world_corners(target)

    xs = [c.x for c in corners]
    ys = [c.y for c in corners]
    zs = [c.z for c in corners]

    return min(xs), max(xs), sum(ys) / len(ys), min(zs), max(zs)


def placement_point(target, orientation, side, height_percent=HANDLE_HEIGHT_PERCENT_DEFAULT):
    """
    Handle centre at height_percent of the face's height, measured
    from its bottom. Horizontal: centred in X. Vertical: 40mm in from
    the LEFT / RIGHT side.
    """

    if target.type != 'MESH':
        return target.matrix_world.translation.copy()

    min_x, max_x, mid_y, min_z, max_z = _target_frame(target)

    z = min_z + (max_z - min_z) * max(0.0, min(height_percent, 100.0)) / 100.0

    if orientation != 'VERTICAL':
        return Vector(((min_x + max_x) / 2.0, mid_y, z))

    margin_x = mm_to_native(list(target.dimensions), HANDLE_EDGE_MARGIN_MM)

    x = max_x - margin_x if side == 'RIGHT' else min_x + margin_x

    return Vector((x, mid_y, z))


def _module_name_for(props, target):

    name = props.module_name.strip()

    if name:
        return name

    top = topmost(target)

    if top is not None and top is not target:
        return top.name

    return ""


# =========================================================
# Add Handle
# =========================================================

def selected_targets(context):
    """
    Selected meshes a handle could go on (handles themselves excluded),
    left to right, top to bottom. A selected group (e.g. a Shutter group
    sh_NN) counts as its front face, the child mesh named '..._sh-ft_NN'.
    """

    meshes = []

    for obj in context.selected_objects:

        if obj.type == 'MESH':
            candidates = [obj]
        elif obj.type == 'EMPTY':
            candidates = [child for child in obj.children if child.type == 'MESH' and FRONT_TAG in child.name]
        else:
            candidates = []

        for mesh in candidates:
            if not is_handle(mesh) and mesh not in meshes:
                meshes.append(mesh)

    return spatial_order(meshes)


def handle_targets(context, props):
    """
    Every selected shutter when two or more are selected, else the picked
    Object, else the one selected shutter.
    """

    selected = selected_targets(context)

    if len(selected) >= 2:
        return selected

    if props.handle_target is not None:
        return [props.handle_target]

    return selected


def _import_handle(context, filepath):
    """Import the .fbx once; returns its single root object."""

    before = set(bpy.data.objects)

    bpy.ops.import_scene.fbx(filepath=filepath)

    imported = [obj for obj in bpy.data.objects if obj not in before]

    if not imported:
        raise MOError("Handle import produced no objects.")

    roots = [obj for obj in imported if obj.parent not in imported]

    if len(roots) == 1:
        return roots[0]

    meshes = [obj for obj in imported if obj.type == 'MESH']

    return join_objects(context, meshes) if meshes else roots[0]


def _place_lock(context, handle, target):
    """
    Lock centred under the handle (same X and depth), with LOCK_GAP_MM of
    empty space between the handle's bottom and the lock's top.
    """

    context.view_layer.update()

    corners = world_corners(handle)
    handle_bottom = min(c.z for c in corners)
    handle_x = (min(c.x for c in corners) + max(c.x for c in corners)) / 2.0

    lock = _import_handle(context, LOCK_PATH)

    # The .fbx carries a '<module>_lck_01' name of its own - keep it out
    # of the numbering.
    lock.name = "mo2_lock"

    context.view_layer.update()

    # Offsets of the lock's shape from its origin (the model isn't exactly centred).
    lock_corners = world_corners(lock)
    origin = lock.matrix_world.translation
    lock_top = max(c.z for c in lock_corners) - origin.z
    lock_mid_x = (min(c.x for c in lock_corners) + max(c.x for c in lock_corners)) / 2.0 - origin.x

    gap = mm_to_native(list(target.dimensions), LOCK_GAP_MM)

    lock.location = Vector((
        handle_x - lock_mid_x,
        handle.matrix_world.translation.y,
        handle_bottom - gap - lock_top,
    ))

    return lock


def add_handle(context, props):
    """
    One handle on the picked Object - or, with two or more meshes
    selected, one on each, all with the same orientation, side and
    Height Position.
    """

    targets = handle_targets(context, props)

    if not targets:
        raise MOError(
            "Pick the face the handle goes on, or select the shutters (meshes or sh_NN groups) that get one."
        )

    if props.handle_asset in ("", "NONE"):
        raise MOError("Please select a Handle.")

    filepath = os.path.join(HANDLE_DIR, props.handle_asset)

    if not os.path.isfile(filepath):
        raise MOError(f"Handle file not found: {filepath}")

    modules = [_module_name_for(props, target) for target in targets]

    if not all(modules):
        raise MOError("Please enter a Module Name.")

    vertical = props.handle_orientation == 'VERTICAL'

    # Locks: Wardrobes only, one shutter at a time (never with Add Handle to Selected).
    with_lock = props.category == 'WARDROBES' and props.handle_lock == 'WITH' and len(targets) == 1

    if with_lock and not os.path.isfile(LOCK_PATH):
        raise MOError(f"Lock file not found: {LOCK_PATH}")

    ensure_object_mode(context)

    placed = []
    locks = []

    for target, module in zip(targets, modules):

        handle = _import_handle(context, filepath)

        if vertical:
            handle.rotation_mode = 'XYZ'
            handle.rotation_euler.y += radians(90)

        handle.location = placement_point(target, props.handle_orientation, props.handle_side, props.handle_height_percent)

        module_root = topmost(target)

        parent_to(module_root if module_root.type == 'EMPTY' else target, [handle])

        handle.name = make_name(module, HANDLE_SUFFIX, next_index(module, HANDLE_SUFFIX))
        handle[HANDLE_TAG] = True

        placed.append(handle)

        if with_lock:

            lock = _place_lock(context, handle, target)

            parent_to(module_root if module_root.type == 'EMPTY' else target, [lock])

            lock.name = make_name(module, LOCK_SUFFIX, next_index(module, LOCK_SUFFIX))
            lock[HANDLE_TAG] = True     # ignored by skirting / bounds, like handles

            locks.append(lock)

    select_only(context, placed + locks)

    props.handle_target = None
    props.handle_asset = "NONE"

    lock_note = f" with {len(locks)} lock(s)" if locks else ""

    if len(placed) == 1:
        return f"Placed handle '{placed[0].name}'{lock_note}."

    return f"Placed {len(placed)} handles{lock_note}: " + ", ".join(
        f"{handle.name} on {target.name}" for handle, target in zip(placed, targets)
    ) + "."

"""
Skirting: a new toe-kick box from the floor up to the chosen height,
18 or 20mm deep, in one of two positions:

    INLINE  spanning the module's full width (LP to RP), standing just
            in front of the side panels' front-bottom edge
    INSET   inside the module: front face flush with the front edge,
            between the inner faces of the left and right side panels

    <module>_skr_sh_NN      group (under the module root)
    <module>_skr_sh-ft_NN   Front + Back joined
    <module>_skr_sh-eb_NN   the 4 edge faces joined
"""

import bpy

from ..config import (
    SKIRTING_GROUP,
    SKIRTING_FRONT,
    SKIRTING_EDGEBAND,
    SKIRTING_SIDE_PANEL_MAX_MM,
    SKIRTING_SIDE_PANEL_DEFAULT_MM,
)

from .common import (
    MOError,
    require_root,
    ensure_module_name,
    make_name,
    next_index,
    join_objects,
    parent_to,
    structural_meshes,
    bounds_of,
    mm_to_native,
    native_to_mm,
    refresh,
)

from .geometry import make_box_faces


def _front_bottom_y(meshes, target_x, tolerance):
    """
    Y of the real vertex at world X == target_x that is lowest,
    then frontmost - read off geometry, not off whichever object
    happens to own the X extreme.
    """

    candidates = []

    for obj in meshes:

        bounds = bounds_of([obj])

        if bounds is None:
            continue

        if not (bounds[0].x - tolerance <= target_x <= bounds[1].x + tolerance):
            continue

        matrix = obj.matrix_world

        for vertex in obj.data.vertices:

            world = matrix @ vertex.co

            if abs(world.x - target_x) <= tolerance:
                candidates.append(world)

    if not candidates:
        return None

    floor = min(point.z for point in candidates)

    return min(point.y for point in candidates if point.z - floor <= tolerance)


def _module_meshes(root):
    """Structural meshes without earlier skirting (it sits outside the carcass)."""

    return [obj for obj in structural_meshes(root) if f"_{SKIRTING_GROUP}" not in obj.name]


def module_bounds(root):
    """(lo, hi) of the module without handles or skirting, lo.y = front line."""

    meshes = _module_meshes(root)

    bounds = bounds_of(meshes)

    if bounds is None:
        return None

    lo, hi = bounds

    tolerance = max((hi.x - lo.x) * 1e-4, 1e-6)

    fronts = [
        y for y in (
            _front_bottom_y(meshes, lo.x, tolerance),
            _front_bottom_y(meshes, hi.x, tolerance),
        )
        if y is not None
    ]

    if fronts:
        lo.y = min(fronts)

    return lo, hi


def side_panel_inner_x(root, lo, hi, size):
    """
    (left inner X, right inner X, found both): the inner faces of the
    thin panels touching the module's left and right edges. A side
    with no such panel falls back to a standard panel thickness.
    """

    tolerance = mm_to_native(size, 0.5)
    thin = mm_to_native(size, SKIRTING_SIDE_PANEL_MAX_MM)
    default = mm_to_native(size, SKIRTING_SIDE_PANEL_DEFAULT_MM)

    left, right = [], []

    for obj in _module_meshes(root):

        bounds = bounds_of([obj])

        if bounds is None or bounds[1].x - bounds[0].x > thin:
            continue

        if abs(bounds[0].x - lo.x) <= tolerance:
            left.append(bounds[1].x)

        if abs(bounds[1].x - hi.x) <= tolerance:
            right.append(bounds[0].x)

    inner_left = max(left) if left else lo.x + default
    inner_right = min(right) if right else hi.x - default

    return inner_left, inner_right, bool(left and right)


def add_skirting(context, props, height_mm, depth_mm=18.0, position='INLINE'):

    root = require_root(context)
    module = ensure_module_name(props, root)

    bounds = module_bounds(root)

    if bounds is None:
        raise MOError("No mesh geometry found in module.")

    lo, hi = bounds

    size = list(hi - lo)

    depth = mm_to_native(size, depth_mm)
    height = mm_to_native(size, height_mm)

    if position == 'INSET':
        x0, x1, found = side_panel_inner_x(root, lo, hi, size)
        y0, y1 = lo.y, lo.y + depth
    else:
        x0, x1, found = lo.x, hi.x, True
        y0, y1 = lo.y - depth, lo.y

    if x1 <= x0:
        raise MOError("The module is too narrow for an inset skirting.")

    collection = root.users_collection[0] if root.users_collection else context.collection

    faces = make_box_faces("Skirting", x0, x1, y0, y1, lo.z, lo.z + height, collection)

    front = join_objects(context, [faces["-Y"], faces["+Y"]])
    edgeband = join_objects(context, [faces["-X"], faces["+X"], faces["-Z"], faces["+Z"]])

    index = next_index(module, SKIRTING_GROUP)

    front.name = make_name(module, SKIRTING_FRONT, index)
    edgeband.name = make_name(module, SKIRTING_EDGEBAND, index)

    group = bpy.data.objects.new(make_name(module, SKIRTING_GROUP, index), None)
    collection.objects.link(group)

    parent_to(group, [front, edgeband])
    parent_to(root, [group])

    bpy.ops.object.select_all(action='DESELECT')

    refresh(context)

    def mm(value):
        return f"{native_to_mm(size, value):.0f}"

    label = "Inset" if position == 'INSET' else "Inline"

    message = (
        f"{label} skirting '{group.name}' built, {height_mm:g} x {depth_mm:g}mm, "
        f"X[{mm(x0)},{mm(x1)}] Y[{mm(y0)},{mm(y1)}] Z[{mm(lo.z)},{mm(lo.z + height)}] (mm)."
    )

    if not found:
        message += f" No side panel found at one edge - assumed {SKIRTING_SIDE_PANEL_DEFAULT_MM:.0f}mm."

    return message

"""
Operators - thin wrappers: each calls one core function and
reports its message, or its MOError as a warning.
"""

import bpy

from bpy.props import BoolProperty, EnumProperty, StringProperty

from bpy_extras.io_utils import ExportHelper

from .config import (
    VISIBLE_TOP,
    VISIBLE_BOTTOM,
    REMOVABLE_SHELF,
    FIXED_SHELF,
    WARDROBE_BUTTONS,
)

from .core.common import MOError, find_root, require_root

from .core import cleanup, shutter, carcass, skirting, handles, uv, export, wardrobe

from . import updates


WITH_WITHOUT = [
    ('WITH', "With OSL/BSL", "Keep Front / Back / EdgeBand separate, OSL/BSL named"),
    ('WITHOUT', "Without OSL/BSL", "Join Front / Back / EdgeBand into one plain-named object"),
]


# =========================================================
# Base Classes
# =========================================================

class _Action:
    """Runs self.run(context) and reports the result."""

    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        try:
            message = self.run(context)
        except MOError as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}

        self.report({'INFO'}, message)

        return {'FINISHED'}


class _Popup(_Action):
    """_Action that first asks for self.mode in a small dialog."""

    def invoke(self, context, event):

        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):

        self.layout.column().prop(self, "mode", expand=True)


class _PanelPopup(_Popup):
    """
    _Popup for the Top / Bottom / Side / Back Panel tools: picking
    Carcass in the dialog opens a second one (MO2_OT_PanelCarcass)
    asking With / Without OSL/BSL. Called without the dialog (scripts,
    tests), Carcass stays the whole panel as one car-in.
    """

    from_dialog: BoolProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):

        self.from_dialog = True

        return super().invoke(context, event)

    def execute(self, context):

        if self.mode == 'CARCASS' and self.from_dialog:
            # 'mo2.top_panel' on the class, 'MO2_OT_top_panel' at run time.
            panel = self.bl_idname.split(".")[-1].split("_OT_")[-1]
            bpy.ops.mo2.panel_carcass('INVOKE_DEFAULT', panel=panel)
            return {'CANCELLED'}

        return super().execute(context)


# =========================================================
# Module Cleanup / Module Name
# =========================================================

class MO2_OT_CleanupModule(_Action, bpy.types.Operator):
    """Scale to metres, apply transforms, tris to quads, strip materials, \
remove empty Parts, purge orphans, then build EdgeBands and Front/Back"""

    bl_idname = "mo2.cleanup_module"
    bl_label = "CleanUp Module"

    def run(self, context):

        return cleanup.cleanup_module(context, require_root(context))


class MO2_OT_DeleteEmptyGroups(_Action, bpy.types.Operator):
    """Delete every Empty in the scene that has no children"""

    bl_idname = "mo2.delete_empty_groups"
    bl_label = "Delete Empty Groups"

    def run(self, context):

        deleted = cleanup.delete_empty_groups(context.scene)

        return f"{deleted} empty group(s) deleted."


class MO2_OT_SetPivot(_Action, bpy.types.Operator):
    """Move the module so its bottom-centre sits at the origin, then freeze transforms"""

    bl_idname = "mo2.set_pivot"
    bl_label = "Set Pivot Point"

    def run(self, context):

        return cleanup.set_pivot_bottom_center(context, require_root(context))


class MO2_OT_ApplyModuleName(_Action, bpy.types.Operator):
    """Rename the module root and every object carrying its name"""

    bl_idname = "mo2.apply_module_name"
    bl_label = "Apply Module Name"

    def run(self, context):

        props = context.scene.mo2

        message = cleanup.rename_module(context, props, props.module_name_input)

        props.module_name_input = ""

        return message


# =========================================================
# Shutter
# =========================================================

SHUTTER_MODES = [
    ('COMBINE', "Combine Front and Back", "Join Front and Back into one object"),
    ('WITHOUT', "Without Combine", "Keep Front and Back separate"),
    ('ALL', "All Combine", "Keep the whole panel (Curved End Panels) as one Front object"),
]


class MO2_OT_Shutter(_Popup, bpy.types.Operator):
    """Convert the selected group(s) or faces to the Shutter convention"""

    bl_idname = "mo2.shutter"
    bl_label = "Shutter"

    mode: EnumProperty(name="Shutter", items=SHUTTER_MODES, options={'SKIP_SAVE'})

    def run(self, context):

        return shutter.apply_shutter(context, context.scene.mo2, self.mode)


class MO2_OT_WardrobeShutter(_Action, bpy.types.Operator):
    """Wardrobes Shutter (Without Combine, no popup): find 'Hinged Wardrobe Plain \
Left / Right 1, 2 ...' - or use the selection - each its own sh_NN group with sh-ft, sh-bk, sh-eb"""

    bl_idname = "mo2.wardrobe_shutter"
    bl_label = "Shutter"

    def run(self, context):

        return shutter.apply_shutter(
            context, context.scene.mo2, 'WITHOUT',
            shutter.WARDROBE_SHUTTERS, "Hinged Wardrobe Plain",
        )


# =========================================================
# Carcass
# =========================================================

class MO2_OT_TopPanel(_PanelPopup, bpy.types.Operator):
    """Top panel - found automatically (built if the module has none)"""

    bl_idname = "mo2.top_panel"
    bl_label = "Top Panel"

    mode: EnumProperty(name="Top Panel", items=carcass.TOP_PANEL_MODES, options={'SKIP_SAVE'})

    def run(self, context):

        return carcass.apply_top_panel(context, context.scene.mo2, self.mode)


class MO2_OT_SidesPanel(_PanelPopup, bpy.types.Operator):
    """Side Panel Left / Right - found by name (or the outermost Parts)"""

    bl_idname = "mo2.sides_panel"
    bl_label = "Side Panels"

    mode: EnumProperty(
        name="Side Panels",
        items=[
            ('VISIBLE', "car_vs-l/r_OSL/BSL (Visible Side)", "car_vs-l / car_vs-r naming in car_vs_01"),
            ('SIDE', "sd-pnl_OSL/BSL (Side Panel)", "sd-pnl_OSL/BSL naming, numbers continuing, in car_sd_01"),
            ('SIDE_WHOLE', "sd-pnl (Side Panel)", "Each whole panel as one sd-pnl_NN, in car_sd_01"),
            ('SHUTTER', "Shutter", "Each panel its own Shutter group, Front and Back combined"),
            ('CARCASS', "Carcass", "Carcass Internal (car-in) in car_01 - then choose With / Without OSL/BSL"),
        ],
        options={'SKIP_SAVE'},
    )

    def run(self, context):

        props = context.scene.mo2

        if self.mode == 'VISIBLE':
            return carcass.apply_visible_sides(context, props)

        if self.mode == 'SIDE':
            return carcass.apply_sides_panel(context, props)

        if self.mode == 'SIDE_WHOLE':
            return carcass.apply_sides_panel_whole(context, props)

        return carcass.apply_sides_as(context, props, self.mode)


class MO2_OT_CarcassInternals(_Popup, bpy.types.Operator):
    """Internal panel(s) - select Part group(s) or faces first"""

    bl_idname = "mo2.carcass_internals"
    bl_label = "Carcass Internals"

    mode: EnumProperty(name="Carcass Internals", items=WITH_WITHOUT, options={'SKIP_SAVE'})

    def run(self, context):

        return carcass.apply_carcass_internals(context, context.scene.mo2, self.mode == 'WITH')


class MO2_OT_BottomPanel(_PanelPopup, bpy.types.Operator):
    """Bottom panel - found by name ("Bottom Panel"), else select its Part group or faces"""

    bl_idname = "mo2.bottom_panel"
    bl_label = "Bottom Panel"

    mode: EnumProperty(name="Bottom Panel", items=carcass.BOTTOM_PANEL_MODES, options={'SKIP_SAVE'})

    def run(self, context):

        return carcass.apply_bottom_panel(context, context.scene.mo2, self.mode)


class MO2_OT_BackPanel(_PanelPopup, bpy.types.Operator):
    """Back panel(s) - every 'Back Panel…' found by name, else the selection"""

    bl_idname = "mo2.back_panel"
    bl_label = "Back Panel"

    mode: EnumProperty(name="Back Panel", items=carcass.BACK_PANEL_MODES, options={'SKIP_SAVE'})

    def run(self, context):

        return carcass.apply_back_panels(context, context.scene.mo2, self.mode)


WARDROBE_DESCRIPTIONS = {
    "TOP_PANEL": "Find 'Top Panel' / 'Top Panel 1, 2 ...' and name them tp-pnl in the main group",
    "BOTTOM_PANEL": "Find 'Bottom Panel' / 'Bottom Panel 1, 2 ...' and name them bt-pnl in the main group",
    "BACK_PANEL": "Find 'Back Panel' / 'Back Panel 1, 2 ...' and name them bk-pnl in the main group",
    "SIDE_PANELS": "Find 'Side Panel Left' / 'Right' and name them sd-pnl (left first) in the main group",
    "VERTICAL_PANEL": "Find 'Centre Vertical Panel' / 'Centre Vertical Panel 1, 2 ...' and name them vt-pnl_01, _02 ... in the main group",
}


class MO2_OT_WardrobeTool(_Action, bpy.types.Operator):
    """Wardrobes convention"""

    bl_idname = "mo2.wardrobe_tool"
    bl_label = "Wardrobe Tool"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    tool: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):

        return WARDROBE_DESCRIPTIONS.get(
            properties.tool, f"Wardrobes > {_wardrobe_label(properties.tool)} - not set up yet"
        )

    def run(self, context):

        message = wardrobe.run(context, context.scene.mo2, self.tool)

        return message or f"Wardrobes > {_wardrobe_label(self.tool)} isn't set up yet."


class MO2_OT_WardrobePanel(_Popup, bpy.types.Operator):
    """Wardrobes Top / Back / Side / Bottom Panel - asks With or Without OSL/BSL"""

    bl_idname = "mo2.wardrobe_panel"
    bl_label = "Wardrobe Panel"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    tool: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    mode: EnumProperty(name="Panel", items=WITH_WITHOUT, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):

        return WARDROBE_DESCRIPTIONS.get(properties.tool, "Wardrobes panel") + " - With or Without OSL/BSL"

    def invoke(self, context, event):

        return context.window_manager.invoke_props_dialog(self, title=_wardrobe_label(self.tool))

    def run(self, context):

        return wardrobe.run(context, context.scene.mo2, self.tool, self.mode == 'WITH')


def _wardrobe_label(key):

    return next((label for group in WARDROBE_BUTTONS for k, label in group if k == key), key)


# Panel tool -> its core function, for the Carcass follow-up dialog.
PANEL_CARCASS = {
    "top_panel": carcass.apply_top_panel,
    "bottom_panel": carcass.apply_bottom_panel,
    "sides_panel": carcass.apply_sides_as,
    "back_panel": carcass.apply_back_panels,
}


class MO2_OT_PanelCarcass(_Popup, bpy.types.Operator):
    """Carcass option of a panel tool: With or Without OSL/BSL"""

    bl_idname = "mo2.panel_carcass"
    bl_label = "Carcass Internals"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    mode: EnumProperty(name="Carcass Internals", items=WITH_WITHOUT, options={'SKIP_SAVE'})

    panel: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def run(self, context):

        apply = PANEL_CARCASS.get(self.panel)

        if apply is None:
            raise MOError(f"Unknown panel tool '{self.panel}'.")

        return apply(context, context.scene.mo2, 'CARCASS_OSL' if self.mode == 'WITH' else 'CARCASS')


class MO2_OT_VisibleSidePanels(_Popup, bpy.types.Operator):
    """Visible panels: L/R found automatically, Top/Bottom from the selection"""

    bl_idname = "mo2.visible_side_panels"
    bl_label = "Visible Side Panels"

    mode: EnumProperty(
        name="Visible Side Panels",
        items=[
            ('SIDES', "L/R Visible Side OSL/BSL", "Outer left / right panels, found automatically"),
            ('TOP', "Top Visible OSL/BSL", "Select a Part group or its faces first"),
            ('BOTTOM', "Bottom Visible OSL/BSL", "Select a Part group or its faces first"),
        ],
        options={'SKIP_SAVE'},
    )

    def run(self, context):

        props = context.scene.mo2

        if self.mode == 'SIDES':
            return carcass.apply_visible_sides(context, props)

        if self.mode == 'TOP':
            return carcass.apply_visible_top_bottom(context, props, VISIBLE_TOP, "Top")

        return carcass.apply_visible_top_bottom(context, props, VISIBLE_BOTTOM, "Bottom")


class MO2_OT_RemovableShelf(_Popup, bpy.types.Operator):
    """Removable shelves - found by name (else the selection)"""

    bl_idname = "mo2.removable_shelf"
    bl_label = "Removable Shelf"

    mode: EnumProperty(name="Removable Shelf", items=carcass.shelf_modes("Removable Shelf"), options={'SKIP_SAVE'})

    def run(self, context):

        return carcass.apply_shelves(context, context.scene.mo2, REMOVABLE_SHELF, "Removable Shelf", self.mode)


class MO2_OT_FixedShelf(_Popup, bpy.types.Operator):
    """Fixed shelves - found by name (else the selection)"""

    bl_idname = "mo2.fixed_shelf"
    bl_label = "Fixed Shelf"

    mode: EnumProperty(name="Fixed Shelf", items=carcass.shelf_modes("Fixed Shelf"), options={'SKIP_SAVE'})

    def run(self, context):

        return carcass.apply_shelves(context, context.scene.mo2, FIXED_SHELF, "Fixed Shelf", self.mode)


# =========================================================
# Handles / Skirting
# =========================================================

class MO2_OT_PickHandleTarget(_Action, bpy.types.Operator):
    """Use the active object as the face the handle goes on"""

    bl_idname = "mo2.pick_handle_target"
    bl_label = "Use Active Object"

    def run(self, context):

        obj = context.active_object

        if obj is None:
            raise MOError("Select the face the handle goes on.")

        context.scene.mo2.handle_target = obj

        return f"Handle will go on '{obj.name}'."


class MO2_OT_AddHandle(_Action, bpy.types.Operator):
    """Import the chosen handle and place it on the picked face - or on every selected mesh when two or more are selected"""

    bl_idname = "mo2.add_handle"
    bl_label = "Add Handle"

    def run(self, context):

        return handles.add_handle(context, context.scene.mo2)


class MO2_OT_AddSkirting(_Action, bpy.types.Operator):
    """Build a skirting box across the module's front, at floor level"""

    bl_idname = "mo2.add_skirting"
    bl_label = "Add Skirting"

    def run(self, context):

        props = context.scene.mo2

        return skirting.add_skirting(
            context, props,
            float(props.skirting_height),
            float(props.skirting_depth),
            props.skirting_position,
        )


# =========================================================
# UV / Export
# =========================================================

class MO2_OT_Unwrap(_Action, bpy.types.Operator):
    """Box-map every mesh in the module and apply the Checker material"""

    bl_idname = "mo2.unwrap"
    bl_label = "Unwrap"

    def run(self, context):

        return uv.unwrap_module(context)


class MO2_OT_ExportCollada(bpy.types.Operator, ExportHelper):
    """Export the module to Collada (.dae) at mm scale and save the .blend beside it"""

    bl_idname = "mo2.export_collada"
    bl_label = "Collada (.DAE) Export"
    bl_options = {'REGISTER'}

    filename_ext = ".dae"

    filter_glob: StringProperty(default="*.dae", options={'HIDDEN'})

    def invoke(self, context, event):

        root = find_root(context)

        if root is not None:
            self.filepath = root.name + self.filename_ext

        return super().invoke(context, event)

    def execute(self, context):

        try:
            message = export.export_module(context, self.filepath)
        except MOError as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}
        except Exception as error:
            self.report({'WARNING'}, f"Collada export failed: {error}")
            return {'CANCELLED'}

        self.report({'INFO'}, message)

        return {'FINISHED'}


# =========================================================
# Update Messages
# =========================================================

def _draw_notes(layout, sections):
    """Version headings with their notes, long lines wrapped."""

    import textwrap

    col = layout.column(align=True)

    for version, notes in sections:

        col.label(text=f"Version {version}")

        for note in notes:
            for number, line in enumerate(textwrap.wrap(note, 58, break_on_hyphens=False)):
                col.label(text=("- " if number == 0 else "   ") + line)

        col.separator()


class MO2_OT_WhatsNew(bpy.types.Operator):
    """What changed in this version - and Update now when a newer one is ready.
Opens by itself when a newer version reaches the team folder"""

    bl_idname = "mo2.whats_new"
    bl_label = "What's new"
    bl_options = {'INTERNAL'}

    # Newer version in the team folder when the popup opened, else empty.
    update_to: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):

        info = updates.update_info()
        self.update_to = info[0] if info else ""

        # Freshen the GitHub check for the next time the popup opens.
        updates.refresh_remote()

        return context.window_manager.invoke_props_dialog(
            self, width=420, title="What's new in Module Optimizer",
            confirm_text="Update now" if self.update_to else "OK",
        )

    def draw(self, context):

        layout = self.layout
        current = updates.installed_version()
        sections = [section for section in updates.bundled_changelog() if section[0] == current]

        layout.label(text=f"You have version {current}.")

        if sections:
            _draw_notes(layout, sections)
        else:
            layout.label(text="No notes for this version.")

        if not self.update_to:
            return

        layout.separator()
        layout.label(text=f"New version {self.update_to} is ready - click Update now.")

        info = updates.update_info()

        if info and info[1]:
            _draw_notes(layout, info[1])

    def execute(self, context):

        version = self.update_to

        if not version:
            return {'FINISHED'}

        # Installing reloads the add-on, which unregisters this operator:
        # read nothing from self past this point.
        report = self.report

        try:
            updates.install_update(version)
        except Exception as error:
            report({'WARNING'}, f"Update failed: {error}.")
            return {'CANCELLED'}

        try:
            report({'INFO'}, f"Module Optimizer updated to {version} - restart Blender to finish.")
        except ReferenceError:
            print(f"Module Optimizer updated to {version} - restart Blender to finish.")

        return {'FINISHED'}


classes = (
    MO2_OT_CleanupModule,
    MO2_OT_DeleteEmptyGroups,
    MO2_OT_SetPivot,
    MO2_OT_ApplyModuleName,
    MO2_OT_Shutter,
    MO2_OT_TopPanel,
    MO2_OT_SidesPanel,
    MO2_OT_CarcassInternals,
    MO2_OT_BottomPanel,
    MO2_OT_BackPanel,
    MO2_OT_PanelCarcass,
    MO2_OT_WardrobeTool,
    MO2_OT_WardrobeShutter,
    MO2_OT_WardrobePanel,
    MO2_OT_VisibleSidePanels,
    MO2_OT_RemovableShelf,
    MO2_OT_FixedShelf,
    MO2_OT_PickHandleTarget,
    MO2_OT_AddHandle,
    MO2_OT_AddSkirting,
    MO2_OT_Unwrap,
    MO2_OT_ExportCollada,
    MO2_OT_WhatsNew,
)

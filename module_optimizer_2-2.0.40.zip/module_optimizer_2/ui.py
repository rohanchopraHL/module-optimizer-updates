"""Sidebar panel: View3D > Sidebar > Module Optimizer 2.0. Text only, no icons."""

import bpy

from . import updates
from .config import CATEGORIES_WITHOUT_HANDLES_SKIRTING, WARDROBE_BUTTONS
from .core import handles, wardrobe
from .wardrobe_internals import ui as wardrobe_internals_ui


def _collapsible(layout, props, attr, title):
    """Box with an expand arrow; returns (box, is_open)."""

    box = layout.box()

    is_open = getattr(props, attr)

    row = box.row(align=True)
    row.prop(props, attr, text=title, icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=False)

    return box, is_open


def _checkbox_choice(layout, props, attr, title):
    """Titled sub-box listing an enum's options as one-of-many checkboxes."""

    sub = layout.box()
    sub.label(text=title)

    col = sub.column(align=True)
    current = getattr(props, attr)

    for item in props.bl_rna.properties[attr].enum_items:
        col.prop_enum(
            props, attr, item.identifier, text=item.name,
            icon='CHECKBOX_HLT' if item.identifier == current else 'CHECKBOX_DEHLT',
        )


def _cabinet_conventions(box):
    """Three framed groups: groups / panels / shelves."""

    col = box.box().column(align=True)
    col.operator("mo2.carcass_internals", text="Carcass")
    col.operator("mo2.shutter", text="Shutter")

    col = box.box().column(align=True)
    col.operator("mo2.top_panel")
    col.operator("mo2.back_panel")
    col.operator("mo2.sides_panel")
    col.operator("mo2.bottom_panel")
    # Visible Side Panels hidden for now (operator still registered);
    # re-add: col.operator("mo2.visible_side_panels")

    col = box.box().column(align=True)
    col.operator("mo2.removable_shelf")
    col.operator("mo2.fixed_shelf")


def _wardrobe_conventions(box):
    """Same three groups as Cabinets. Shutter has its own popup; the rest go through mo2.wardrobe_tool."""

    for group in WARDROBE_BUTTONS:
        col = box.box().column(align=True)
        for key, label in group:
            if key == "SHUTTER":
                col.operator("mo2.wardrobe_shutter", text=label)
            elif key in wardrobe.OSL_BSL_TOOLS:
                col.operator("mo2.wardrobe_panel", text=label).tool = key
            else:
                col.operator("mo2.wardrobe_tool", text=label).tool = key


def _handle_library(layout, props, context):

    box, is_open = _collapsible(layout, props, "handles_expanded", "Handle Library")

    if not is_open:
        return

    box.prop(props, "handle_asset", text="Handle")

    # Two or more selected meshes each get a handle - and no lock.
    multiple = len(handles.selected_targets(context)) >= 2

    row = box.row(align=True)
    row.prop(props, "handle_target", text="")
    row.operator("mo2.pick_handle_target", text="Pick")

    if props.handle_asset not in ("", "NONE"):

        box.row().prop(props, "handle_orientation", expand=True)

        if props.handle_orientation == 'VERTICAL':
            split = box.split(factor=0.4)
            split.label(text="Side")
            split.row(align=True).prop(props, "handle_side", expand=True)

        split = box.split(factor=0.4)
        split.label(text="Height Position")
        split.prop(props, "handle_height_percent", text="")

        if props.category == 'WARDROBES' and not multiple:
            _checkbox_choice(box, props, "handle_lock", "Lock")

    text = "Add Handle to Selected" if multiple else "Add Handle"

    box.operator("mo2.add_handle", text=text)


def _skirting(layout, props):

    box, is_open = _collapsible(layout, props, "skirting_expanded", "Skirting")

    if not is_open:
        return

    sub = box.box()
    sub.label(text="Size (mm)")

    for attr, title in (("skirting_height", "Height"), ("skirting_depth", "Depth")):
        split = sub.split(factor=0.4)
        split.label(text=title)
        split.prop(props, attr, text="")

    _checkbox_choice(box, props, "skirting_position", "Position")

    box.operator("mo2.add_skirting")


class MO2_PT_Main(bpy.types.Panel):

    bl_label = "Module Optimizer 2.0"
    bl_idname = "MO2_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Module Optimizer 2.0"

    def draw(self, context):

        layout = self.layout
        props = context.scene.mo2

        # -------------------------------------------------
        # Category - only Conventions differ between them
        # -------------------------------------------------

        layout.prop(props, "category", text="Category")

        if props.category == 'NONE':
            layout.box().label(text="Choose a Category to see its tools.")
            _version_row(layout)
            return

        if props.category == 'WARDROBE_INTERNALS':
            wardrobe_internals_ui.draw_panel(layout, context)
            _version_row(layout)
            return

        # -------------------------------------------------
        # Module Cleanup
        # -------------------------------------------------

        box = layout.box()
        box.label(text="Module Cleanup")

        col = box.column(align=True)
        col.operator("mo2.cleanup_module")
        col.operator("mo2.delete_empty_groups")
        col.operator("mo2.set_pivot")

        # -------------------------------------------------
        # Module Name
        # -------------------------------------------------

        box = layout.box()
        box.label(text="Module Name")

        if props.module_name:
            box.label(text=f"Current: {props.module_name}")

        box.prop(props, "module_name_input", text="")
        box.operator("mo2.apply_module_name")

        # -------------------------------------------------
        # Conventions
        # -------------------------------------------------

        box = layout.box()
        box.label(text="Conventions")

        if props.category == 'CABINETS':
            _cabinet_conventions(box)
        elif props.category == 'WARDROBES':
            _wardrobe_conventions(box)
        else:
            name = props.bl_rna.properties["category"].enum_items[props.category].name
            box.label(text=f"{name} conventions coming soon.")

        # -------------------------------------------------
        # Handle Library / Skirting (not every category)
        # -------------------------------------------------

        if props.category not in CATEGORIES_WITHOUT_HANDLES_SKIRTING:
            _handle_library(layout, props, context)
            _skirting(layout, props)

        # -------------------------------------------------
        # UV Checker / Export
        # -------------------------------------------------

        box = layout.box()
        box.label(text="UV Checker")
        box.operator("mo2.unwrap")

        box = layout.box()
        box.label(text="Export")
        box.operator("mo2.export_collada", text="Export")

        _version_row(layout)


def _version_row(layout):
    """Version / What's new - shown for every category, and before one is picked."""

    row = layout.box().row()
    row.label(text=f"Version {updates.installed_version()}")
    row.operator("mo2.whats_new", text="What's new")


classes = (MO2_PT_Main,)
